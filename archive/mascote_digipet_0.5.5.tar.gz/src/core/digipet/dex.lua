-- =============================================================================
--  Enciclopedia de dados das criaturas digitais (assets/digipets/creatures.json)
--  8 LINHAS (as especies do mascote: slime, robot, cat...) com 6 FORMAS cada:
--  tier 1 Inicial, 2 Intermediaria, 3 Avancada (main) ou Alternativa (alt),
--  4 Suprema, 5 Secreta. Cada forma: nome, elemento, raridade, habilidade,
--  descricao, historia, atributos base e "evolves" (destinos + requisitos).
--  Para adicionar uma criatura: entrada no creatures.json (tools/digipet_content.py)
--  + sprites (tools/bake_sprites.sh) + textos em i18n/en.lua e ru.lua.
-- =============================================================================
local L = require("lib.i18n").L
local Dex = {}
Dex.FILE = "assets/digipets/creatures.json"

Dex.TIER_NAMES = { L("Inicial"), L("Intermediária"), L("Avançada"), L("Suprema"), L("Secreta") }
Dex.ATTR_NAMES = { pow = L("Força"), def = L("Defesa"), spd = L("Velocidade"), wis = L("Sabedoria") }
Dex.ATTRS = { "pow", "def", "spd", "wis" }

local data

function Dex.load()
  if data then return data end
  local ok, txt = pcall(love.filesystem.read, Dex.FILE)
  local d
  if ok and txt then
    local okj, j = pcall(require("lib.json").decode, txt)
    if okj and type(j) == "table" and type(j.lines) == "table" then d = j end
  end
  d = d or { lines = {} }
  d.line_by_id, d.form_by_id = {}, {}
  for _, ln in ipairs(d.lines) do
    d.line_by_id[ln.id] = ln
    for i, f in ipairs(ln.forms) do
      f.line = ln.id
      f.index = i
      d.form_by_id[f.id] = f
    end
  end
  data = d
  return d
end

function Dex.lines() return Dex.load().lines end
function Dex.line(id) return Dex.load().line_by_id[id] end
function Dex.form(id) return Dex.load().form_by_id[id] end
--- primeira forma (Inicial) de uma linha
function Dex.first(line_id)
  local ln = Dex.line(line_id)
  return ln and ln.forms[1] or nil
end

--- quantas formas existem no total
function Dex.count()
  local n = 0
  for _, ln in ipairs(Dex.lines()) do n = n + #ln.forms end
  return n
end

return Dex
