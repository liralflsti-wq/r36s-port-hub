-- =============================================================================
--  Cuidados da criatura (bichinho virtual): energia, felicidade, saude,
--  atributos treinados e contadores de interacoes. Cada LINHA (especie) tem os
--  seus, guardados no mascot.json junto da evolucao (evo.mascots[id].care).
--  Queda lenta com o tempo, SEM morte e sem perder nivel:
--    energia    -1 a cada 30 min (minimo 10)
--    felicidade -1 a cada 25 min (minimo 10)
--    saude      -1 por hora so se energia < 25 ou felicidade < 20 (minimo 30);
--               sobe devagar quando os dois estao bons
--  Descansando, a energia sobe 1 por minuto (inclusive com o hub fechado).
--  Acoes (com efeito real nos atributos e na evolucao):
--    feed, play, train(attr), rest, pet, minigame(attr, ganhou)
--  Cada acao concede XP pelas regras do EvolutionManager (limite por dia).
-- =============================================================================
local L = require("lib.i18n").L
local I18N = require("lib.i18n")

local C = {}
C.STATS = { "energy", "happiness", "health" }
C.STAT_NAMES = { energy = L("Energia"), happiness = L("Felicidade"), health = L("Saúde") }
-- "Energia" e "Saude" ja existem no hub com sentido de bateria; para a
-- criatura o sentido e outro (en/ru diferentes): rotulos proprios
local CTX = {
  energy = { en = "Energy", ru = "Энергия" },
  health = { en = "Health", ru = "Здоровье" },
}
function C.label(stat)
  local lang = I18N.lang
  local c = CTX[stat]
  if c and c[lang] then return c[lang] end
  return I18N.tr(C.STAT_NAMES[stat] or stat)
end

--- as primeiras n letras (UTF-8) de um texto em maiusculas
function C.abbr(s, n)
  local utf8 = require("utf8")
  s = I18N.upper(s)
  local cut = utf8.offset(s, (n or 3) + 1)
  return cut and s:sub(1, cut - 1) or s
end
C.COUNTERS = { "trainings", "feeds", "plays", "pets", "rests", "minigames" }

local function Evo() return require("core.mascot3d.evolution") end
local function clamp(v, a, b) return math.max(a, math.min(b, v)) end

--- estado de cuidados de uma linha (cria/valida)
function C.get(id)
  local r = Evo().record(id)
  local c = r.care
  if type(c) ~= "table" then c = {}; r.care = c end
  c.energy = clamp(tonumber(c.energy) or 80, 0, 100)
  c.happiness = clamp(tonumber(c.happiness) or 70, 0, 100)
  c.health = clamp(tonumber(c.health) or 90, 0, 100)
  c.t = tonumber(c.t) or os.time()
  if type(c.attrs) ~= "table" then c.attrs = {} end
  for _, a in ipairs({ "pow", "def", "spd", "wis" }) do c.attrs[a] = math.max(0, math.floor(tonumber(c.attrs[a]) or 0)) end
  if type(c.count) ~= "table" then c.count = {} end
  for _, k in ipairs(C.COUNTERS) do c.count[k] = math.max(0, math.floor(tonumber(c.count[k]) or 0)) end
  c.sleeping = c.sleeping == true
  return c
end

--- aplica a passagem do tempo (chamado ao abrir e de tempos em tempos)
function C.tick(id, now)
  local c = C.get(id)
  now = now or os.time()
  local dt = now - c.t
  if dt < 60 then return c end
  if dt > 14 * 86400 then dt = 14 * 86400 end   -- longe por semanas: nao castiga alem disso
  local mins = dt / 60
  c.t = now
  if c.sleeping then
    c.energy = clamp(c.energy + mins, 0, 100)
    if c.energy >= 100 then c.sleeping = false end
  else
    c.energy = math.max(math.min(c.energy, 10), c.energy - mins / 30)
  end
  c.happiness = math.max(math.min(c.happiness, 10), c.happiness - mins / 25)
  local hours = mins / 60
  if c.energy < 25 or c.happiness < 20 then
    c.health = math.max(math.min(c.health, 30), c.health - hours)
  elseif c.energy > 50 and c.happiness > 50 then
    c.health = clamp(c.health + hours * 2, 0, 100)
  end
  return c
end

--- atributos finais = base da forma + treinados
function C.attrs(id, form)
  local c = C.get(id)
  local out = {}
  for _, a in ipairs({ "pow", "def", "spd", "wis" }) do
    out[a] = (form and form.stats and form.stats[a] or 0) + c.attrs[a]
  end
  return out
end

--- humor da criatura pelos cuidados (para a animacao e as falas)
function C.mood(id)
  local c = C.get(id)
  if c.sleeping then return "sleep" end
  if c.health < 40 then return "sad" end
  if c.energy < 20 then return "tired" end
  if c.happiness < 25 then return "sad" end
  if c.happiness > 80 then return "happy" end
  return "idle"
end

local function save() require("core.mascot").save() end
local function reward(src) return require("core.mascot").reward(src) end

-- ------------------------------------------------------------------ acoes
-- devolvem: ok, texto (ja traduzido), animacao, xp
function C.feed(id)
  local c = C.tick(id)
  if c.sleeping then return false, I18N.tr(L("Zzz... está dormindo.")), "sleep" end
  if c.energy >= 95 then return false, I18N.tr(L("Estou cheio! Mais tarde.")), "sad" end
  c.energy = clamp(c.energy + 25, 0, 100)
  c.health = clamp(c.health + 3, 0, 100)
  c.count.feeds = c.count.feeds + 1
  save()
  return true, I18N.tr(L("Que delícia!")), "eat", reward("feed")
end

function C.play(id)
  local c = C.tick(id)
  if c.sleeping then return false, I18N.tr(L("Zzz... está dormindo.")), "sleep" end
  if c.energy < 10 then return false, I18N.tr(L("Estou sem energia...")), "sad" end
  c.happiness = clamp(c.happiness + 15, 0, 100)
  c.energy = clamp(c.energy - 8, 0, 100)
  c.count.plays = c.count.plays + 1
  save()
  return true, I18N.tr(L("Que divertido!")), "happy", reward("play")
end

function C.train(id, attr)
  local c = C.tick(id)
  if c.sleeping then return false, I18N.tr(L("Zzz... está dormindo.")), "sleep" end
  if c.energy < 15 then return false, I18N.tr(L("Cansado demais para treinar.")), "sad" end
  attr = attr or "pow"
  c.energy = clamp(c.energy - 12, 0, 100)
  c.happiness = clamp(c.happiness - 3, 0, 100)
  if c.attrs[attr] < 60 then c.attrs[attr] = c.attrs[attr] + 1 end
  c.count.trainings = c.count.trainings + 1
  save()
  return true, string.format(I18N.tr(L("%s +1!")), I18N.tr(require("core.digipet.dex").ATTR_NAMES[attr] or attr)), "attack", reward("train")
end

function C.rest(id)
  local c = C.tick(id)
  c.sleeping = not c.sleeping
  if c.sleeping then c.count.rests = c.count.rests + 1 end
  save()
  if c.sleeping then return true, I18N.tr(L("Boa noite... Zzz")), "sleep", reward("rest") end
  return true, I18N.tr(L("Acordei!")), "happy", 0
end

function C.pet(id)
  local c = C.tick(id)
  c.happiness = clamp(c.happiness + 5, 0, 100)
  c.count.pets = c.count.pets + 1
  save()
  return true, nil, "happy"
end

--- resultado de minigame: ganhou -> +2 no atributo; perdeu -> +0 (gasta energia)
function C.minigame(id, attr, won)
  local c = C.tick(id)
  c.energy = clamp(c.energy - 10, 0, 100)
  if won then
    c.attrs[attr] = math.min(60, c.attrs[attr] + 2)
    c.happiness = clamp(c.happiness + 8, 0, 100)
    c.count.minigames = c.count.minigames + 1
  else
    c.happiness = clamp(c.happiness - 2, 0, 100)
  end
  save()
  return won and reward("minigame") or 0
end

return C
