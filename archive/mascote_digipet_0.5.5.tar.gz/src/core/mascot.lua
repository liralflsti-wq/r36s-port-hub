-- =============================================================================
--  Mascote do R36S PORT HUB (exclusivo de quem completa o album da temporada)
--  O mascote libera quando a conquista final ("Lenda") da temporada 1 e
--  liberada. Cada carta desbloqueada libera uma especie, cor, chapeu, aura ou
--  efeito (ITEMS). Ele vive no canto da tela, reage ao dia a dia e ganha nivel.
--  Estado em mascot.json: especie e itens escolhidos, nome, experiencia,
--  onde aparece, ultima visita.
--  Desenho: ui/mascot_view.lua | tela de personalizacao: ui/screens/mascot.lua
--  3D (0.5.5): este arquivo e o MascotManager. Modulos em core/mascot3d/:
--    registry.lua (MascotRegistry, assets/mascots/registry.json),
--    loader.lua (MascotLoader, .glb), anim.lua (AnimationController),
--    render.lua (shader/profundidade), dialog.lua (MascotDialog).
--  O widget do canto (MascotWidget) e o seletor (MascotSelector) ficam em
--  ui/mascot_view.lua e ui/screens/mascot.lua. Sem 3D no aparelho (ou com a
--  qualidade "2D"), volta sozinho para o desenho 2D.
-- =============================================================================
local L = require("lib.i18n").L
local I18N = require("lib.i18n")
local U = require("lib.util")

local M = {}
local FILE = "mascot.json"

-- itens liberados por carta (id da conquista -> item)
M.SLOTS = { "species", "color", "hat", "aura", "fx" }
M.SLOT_NAMES = { species = L("Mascote"), color = L("Cor"), hat = L("Acessório"), aura = L("Aura"), fx = L("Efeito") }
M.ITEMS = {
  species = {},   -- vem do registro (assets/mascots/registry.json), abaixo
  color = {
    { id = "signature", name = L("Cor original"), card = "legend", signature = true },
    { id = "orange", name = L("Laranja"), card = "first_install", rgb = { 1.0, 0.55, 0.20 } },
    { id = "blue", name = L("Azul"), card = "explorer", rgb = { 0.30, 0.62, 1.0 } },
    { id = "green", name = L("Verde"), card = "library_play", rgb = { 0.36, 0.85, 0.45 } },
    { id = "yellow", name = L("Amarelo"), card = "search", rgb = { 1.0, 0.85, 0.25 } },
    { id = "brown", name = L("Caramelo"), card = "goodbye", rgb = { 0.78, 0.55, 0.35 } },
    { id = "purple", name = L("Roxo"), card = "uninstall", rgb = { 0.66, 0.42, 0.95 } },
    { id = "gray", name = L("Prata"), card = "cancel_download", rgb = { 0.72, 0.75, 0.80 } },
    { id = "rainbow", name = L("Arco-íris"), card = "legend", rainbow = true },
  },
  hat = {
    { id = "none", name = L("Nenhum"), card = "legend" },
    { id = "nightcap", name = L("Touca de dormir"), card = "background_download" },
    { id = "beret", name = L("Boina"), card = "language" },
    { id = "headset", name = L("Fone gamer"), card = "padtest" },
    { id = "cap", name = L("Boné"), card = "speedtest" },
    { id = "antenna", name = L("Antena"), card = "wifi_connect" },
    { id = "bandana", name = L("Bandana"), card = "low_battery" },
    { id = "tophat", name = L("Cartola"), card = "theme_change" },
    { id = "crown", name = L("Coroa"), card = "supporter" },
  },
  aura = {
    { id = "none", name = L("Nenhuma"), card = "legend" },
    { id = "red", name = L("Vermelha"), card = "password_install", rgb = { 1, 0.25, 0.25 } },
    { id = "shield", name = L("Escudo azul"), card = "backup", rgb = { 0.35, 0.65, 1 } },
    { id = "green", name = L("Verde"), card = "local_install", rgb = { 0.35, 1, 0.5 } },
    { id = "orange", name = L("Laranja"), card = "sd_maint", rgb = { 1, 0.6, 0.2 } },
    { id = "cyan", name = L("Ciano"), card = "bios_install", rgb = { 0.3, 0.95, 1 } },
    { id = "gold", name = L("Dourada"), card = "collector", rgb = { 1, 0.82, 0.25 } },
  },
  fx = {
    { id = "none", name = L("Nenhum"), card = "legend" },
    { id = "hearts", name = L("Corações"), card = "daily" },
    { id = "flames", name = L("Chamas azuis"), card = "restore" },
    { id = "stars", name = L("Estrelas"), card = "hub_update" },
    { id = "coins", name = L("Moedas"), card = "supporter" },
  },
}

do
  local Reg = require("core.mascot3d.registry")
  for _, r in ipairs(Reg.list()) do
    M.ITEMS.species[#M.ITEMS.species + 1] = { id = r.id, name = L(r.name), card = r.card or "legend" }
  end
end

M.WHERE = { "all", "home", "off" }
-- configuracoes (Meu perfil): tamanho, qualidade, animacoes, falas
M.SIZES = { "small", "medium", "large" }
M.SIZE_NAMES = { small = L("Pequeno"), medium = L("Médio"), large = L("Grande") }
M.SIZE_SCALE = { small = 1.0, medium = 1.3, large = 2.0 }
M.QUALITIES = { "pixel", "2d" }
M.QUALITY_NAMES = { pixel = L("Pixel art"), ["2d"] = L("Desenho simples") }
M.WHERE_NAMES = { all = L("Em todas as telas"), home = L("Só na tela inicial"), off = L("Escondido") }

local state

local function defaults()
  return { species = "slime", color = "signature", hat = "none", aura = "none", fx = "none",
    name = "Bit", xp = 0, where = "all", last_seen = 0, pets_day = "", pets = 0,
    enabled = true, size = "medium", quality = "pixel", anim = true, talk = "normal" }
end

function M.load()
  if state then return state end
  state = defaults()
  local ok, txt = pcall(love.filesystem.read, FILE)
  if ok and txt then
    local okj, d = pcall(require("lib.json").decode, txt)
    if okj and type(d) == "table" then for k, v in pairs(d) do state[k] = v end end
  end
  return state
end

--- relê o mascot.json do disco (testes / restauracao de backup)
function M.reload() state = nil; return M.load() end

function M.save()
  local ok, txt = pcall(require("lib.json").encode, M.load())
  if ok then pcall(love.filesystem.write, FILE, txt) end
end

function M.get(k) return M.load()[k] end
function M.set(k, v) M.load()[k] = v; M.save() end

--- o mascote ja foi liberado? (conquista final da temporada 1)
function M.unlocked()
  local ok, A = pcall(require, "core.achievements")
  return ok and A.unlocked("legend") ~= nil
end

function M.item(slot, id)
  for _, it in ipairs(M.ITEMS[slot] or {}) do if it.id == id then return it end end
  return M.ITEMS[slot][1]
end

function M.item_unlocked(it)
  if not it then return false end
  local A = require("core.achievements")
  return A.unlocked(it.card) ~= nil
end

--- item escolhido (volta ao primeiro se o escolhido nao estiver liberado)
function M.current(slot)
  local it = M.item(slot, M.load()[slot])
  if not M.item_unlocked(it) then it = M.ITEMS[slot][1] end
  return it
end

-- nivel e experiencia: cada mascote tem os seus (EvolutionManager,
-- core/mascot3d/evolution.lua). O campo antigo "xp" foi migrado na 0.5.5.
local function Evo() return require("core.mascot3d.evolution") end
function M.level(id) return Evo().get_level(id or M.current("species").id) end
function M.level_progress(id) return select(3, Evo().get_progress(id or M.current("species").id)) end
--- estagio de evolucao mostrado (1..5)
function M.stage(id) return Evo().get_stage(id or M.current("species").id) end

--- XP pelas regras de recompensa (limites por dia / uma vez so)
function M.reward(source, key) return Evo().reward(source, key) end
--- compatibilidade: XP avulso para o mascote atual
function M.add_xp(n) return Evo().add_xp(M.current("species").id, n) end

-- ---------------------------------------------------------------------------
-- comportamento: humor atual, fala e reacoes a eventos
M.mood = "idle"        -- idle, happy, sleep, sad, scared, love, dance, worried
M.mood_t = 0
M.bubble = nil         -- { text, t }
M.jump_t = nil

-- animacao 3D (AnimationController) que acompanha o humor
local Anim = require("core.mascot3d.anim")
local Reg = require("core.mascot3d.registry")
M.anim = nil
function M.anim_ctl()
  local sp = M.current("species").id
  if not M.anim or M.anim.species ~= sp then
    local r = Reg.get(sp)
    M.anim = Anim.new({ float = r.float, blob = r.blob })
    M.anim.species = sp
  end
  return M.anim
end

local MOOD_ANIM = { happy = { "wave", 1.6 }, love = { "interaction", 2.5 }, dance = { "celebrate", 3.5 },
  scared = { "surprise", 1.6 } }
local function react(mood, dur)
  local c = M.anim_ctl()
  c.love = (mood == "love")
  local a = MOOD_ANIM[mood]
  if a then Anim.play(c, a[1], math.min(dur or a[2], a[2] + 1))
  elseif mood == "sad" or mood == "worried" then Anim.set_base(c, "sad")
  elseif mood == "sleep" then Anim.set_base(c, "sleep") end
end

--- configuracoes do mascote
function M.enabled() return M.load().enabled ~= false end
function M.talk() return M.load().talk or "normal" end
function M.anim_on() return M.load().anim ~= false end

function M.say(text, mood, dur)
  if text and M.talk() ~= "off" then M.bubble = { text = text, t = dur or 3.2 } end
  if mood then M.mood, M.mood_t = mood, dur or 3.2; react(mood, dur) end
end

local function name() return require("core.achievements").user_name() or I18N.tr(L("amigo")) end

--- fala da categoria (MascotDialog), com a personalidade do mascote atual
function M.line(category)
  return require("core.mascot3d.dialog").line(category, { species = M.current("species").id, name = name() })
end

local TIPS = {
  L("Sabia? START abre os downloads de qualquer tela."),
  L("SELECT marca um port como favorito."),
  L("Segure B por 5 segundos para sair do teste de controles."),
  L("Faça backup das suas configurações de vez em quando!"),
  L("No álbum, A abre a carta inteira."),
  L("Pelo FTP você manda arquivos do PC direto para o console."),
  L("Trocar de tema também muda a música no Sky Warriors."),
  L("Cada carta que você ganha me dá um visual novo!"),
}

--- chamado na abertura do hub (depois do aviso)
function M.on_boot()
  if not M.unlocked() then return end
  local st = M.load()
  local now = os.time()
  local away = st.last_seen > 0 and (now - st.last_seen) or 0
  st.last_seen = now
  M.save()
  local h = tonumber(os.date("%H"))
  local greet = h < 5 and L("Ainda acordado, %s?") or h < 12 and L("Bom dia, %s!") or h < 18 and L("Boa tarde, %s!") or L("Boa noite, %s!")
  if away > 3 * 86400 then
    M.say(string.format(I18N.tr(L("Senti sua falta, %s!")), name()), "sad", 4)
  elseif math.random() < 0.5 then
    M.say(M.line("welcome"), "happy", 3.5)
  else
    M.say(string.format(I18N.tr(greet), name()), "happy", 3.5)
  end
  M.reward("daily")
end

--- eventos do hub
function M.event(kind, key)
  if not M.unlocked() then return end
  if kind == "install" then
    M.say(M.line("success") or I18N.tr(L("Uhuu! Port novo!")), "happy", 3); M.jump_t = 0; M.reward("install")
  elseif kind == "achievement" then
    M.say(M.line("celebrate") or I18N.tr(L("Carta nova! Me deixa ver!")), "dance", 3); M.reward("achievement", key)
  elseif kind == "update" then
    M.say(M.line("update"), "dance", 4)
  elseif kind == "goodbye" then
    M.say(M.line("goodbye"), "sad", 6)
  elseif kind == "battery" then
    M.say(I18N.tr(L("A bateria tá acabando... me carrega!")), "worried", 4)
  elseif kind == "error" then
    M.say(I18N.tr(L("Eita! Deu ruim...")), "scared", 3)
  elseif kind == "cancel" then
    M.say(I18N.tr(L("Desistiu? Tudo bem.")), "sad", 2.5)
  end
end

--- interacoes (tela do mascote)
function M.pet()
  local st = M.load()
  local today = os.date("%Y-%m-%d")
  if st.pets_day ~= today then st.pets_day, st.pets = today, 0 end
  st.pets = st.pets + 1
  M.save()
  M.reward("pet")
  local lines = { L("Hehe, faz cócegas!"), L("Mais um pouquinho!"), L("Eu gosto de você!"), L("Prrr...") }
  M.say(I18N.tr(lines[(st.pets - 1) % #lines + 1]), "love", 2.5)
end

function M.dance()
  M.reward("dance")
  M.say(I18N.tr(L("~ Olha o passinho! ~")), "dance", 3.5)
end

function M.tip()
  M.reward("tip")
  M.say(M.line("tip") or I18N.tr(TIPS[math.random(#TIPS)]), "happy", 5)
end

local bat_warned = false
function M.update(dt)
  if M.bubble then
    M.bubble.t = M.bubble.t - dt
    if M.bubble.t <= 0 then M.bubble = nil end
  end
  if M.mood_t > 0 then
    M.mood_t = M.mood_t - dt
    if M.mood_t <= 0 then M.mood = "idle" end
  end
  if M.jump_t then
    if M.jump_t == 0 then Anim.play(M.anim_ctl(), "jump", 0.8) end
    M.jump_t = M.jump_t + dt
    if M.jump_t > 0.8 then M.jump_t = nil end
  end
  -- animacao 3D: estado de fundo segue o humor; de vez em quando da uma volta
  local c = M.anim_ctl()
  if M.mood == "idle" and c.base ~= "idle" then Anim.set_base(c, "idle"); c.love = false end
  if M.mood == "sleep" then Anim.set_base(c, "sleep") end
  if M.anim_on() then
    Anim.update(c, dt)
    M.walk_in = (M.walk_in or 25) - dt
    if M.walk_in <= 0 then
      M.walk_in = 25 + math.random() * 30
      if M.mood == "idle" and not c.left then Anim.play(c, "walk", 2.6) end
    end
  end
  -- conversa solta (sem outra fala no ar): dica do hub, dica de jogo de
  -- verdade do catalogo ou papo com a personalidade do mascote
  local Brain = require("core.mascot3d.brain")
  pcall(Brain.update, dt)
  local every = require("core.mascot3d.dialog").chatter_interval()
  if every then
    M.chat_in = (M.chat_in or every) - dt
    local cur = App and App.current and App.current()
    if M.chat_in <= 0 then
      M.chat_in = every * (0.75 + math.random() * 0.5)
      local quiet = { splash = true, disclaimer = true, textinput = true, padtest = true, tester = true }
      if not M.bubble and M.mood == "idle" and cur and not quiet[cur.name] then
        local r = math.random()
        local txt = r < 0.4 and Brain.game_tip() or M.line(r < 0.7 and "tip" or "chatter")
        M.say(txt, "happy", 4.5)
      end
    end
  end
  -- dorme de madrugada (quando nao esta fazendo outra coisa)
  if M.mood == "idle" then
    local h = tonumber(os.date("%H"))
    if h >= 1 and h < 6 then M.mood = "sleep"; M.mood_t = 30 end
  end
  -- bateria baixa: avisa uma vez
  local okb, B = pcall(require, "core.battery")
  if okb and B.info and B.info.ok then
    if B.info.pct <= 15 and not B.info.charging then
      if not bat_warned then bat_warned = true; M.event("battery") end
    elseif B.info.pct > 20 or B.info.charging then bat_warned = false end
  end
end

return M
