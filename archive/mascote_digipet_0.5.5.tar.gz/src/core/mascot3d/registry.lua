-- =============================================================================
--  MascotRegistry: lista central dos mascotes (assets/mascots/registry.json)
--  Cada mascote: id, name, model (.glb), card (conquista que libera), color
--  (cor original), personality, messages { welcome, success, celebrate,
--  goodbye }, e opcoes de cena: float (flutua), blob (amassa ao andar),
--  dist (distancia da camera).
--  Para adicionar um mascote novo: coloque o .glb em assets/mascots/ e uma
--  entrada no registry.json (textos novos vao para i18n/en.lua e ru.lua).
--  Veja docs/MASCOTES_3D.md.
-- =============================================================================
local Reg = {}
Reg.DIR = "assets/mascots/"

local data

local FALLBACK = {
  version = 1, default = "slime", hats = "hats.glb",
  mascots = { { id = "slime", name = "Slime", model = "slime.glb", card = "legend", color = { 1, 0.55, 0.2 } } },
}

function Reg.load()
  if data then return data end
  local ok, txt = pcall(love.filesystem.read, Reg.DIR .. "registry.json")
  if ok and txt then
    local okj, d = pcall(require("lib.json").decode, txt)
    if okj and type(d) == "table" and type(d.mascots) == "table" and #d.mascots > 0 then data = d end
  end
  data = data or FALLBACK
  data.by_id = {}
  for _, m in ipairs(data.mascots) do data.by_id[m.id] = m end
  return data
end

function Reg.list() return Reg.load().mascots end

function Reg.get(id)
  local d = Reg.load()
  return d.by_id[id] or d.by_id[d.default] or d.mascots[1]
end

function Reg.model_path(id) return Reg.DIR .. (Reg.get(id).model or (id .. ".glb")) end
function Reg.hats_path() return Reg.DIR .. (Reg.load().hats or "hats.glb") end

return Reg
