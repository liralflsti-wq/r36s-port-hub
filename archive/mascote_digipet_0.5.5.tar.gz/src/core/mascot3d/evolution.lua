-- =============================================================================
--  EvolutionManager: nivel, experiencia e evolucao de CADA mascote
--  Configuracao em assets/mascots/evolution.json:
--    formula  XP para ir do nivel n ao n+1 = round(base * n ^ exponent)
--             (ritmo "lento": estagio 5 em ~8 meses de uso diario)
--    stages   nivel minimo de cada estagio (1, 10, 20, 35, 50)
--    rewards  fontes de XP: xp por vez, limite por dia (per_day) ou so uma
--             vez para sempre (unique, com chave)
--  Regras: XP nunca diminui; nao ha XP por deixar o hub aberto; a mesma
--  recompensa com a mesma chave nao paga duas vezes; o estagio so sobe.
--  A evolucao acontece em 2 tempos: ao cruzar o nivel do estagio, o mascote
--  fica "pronto para evoluir" (can_evolve); a cena de evolucao chama
--  Evo.evolve(id) na hora da troca do modelo. Se o hub fechar antes, a
--  evolucao continua pendente e a cena toca na proxima abertura.
--  Dados (campo "evo" do mascot.json, com versao e validacao):
--    { version, mascots = { id = { xp, stage, unlocked = {1,..}, history =
--      { {t, from, to, level} } } }, daily = { day, counts }, once = { chave } }
--  Criaturas digitais (0.5.5): cada linha percorre uma ARVORE de formas
--  (assets/digipets/creatures.json): o destino depende de nivel, felicidade,
--  saude, treinos, atributos, interacoes e requisitos especiais. r.form e a
--  forma atual; r.stage = tier dela (1..5); r.discovered = formas ja vistas.
--  API:
--    Evo.add_xp(id, n, source, key) -> XP ganho (0 se bloqueado)
--    Evo.reward(source, key)        -> XP ganho pelo mascote atual
--    Evo.get_level(id) / get_stage(id) / stage_for_level(lv)
--    Evo.get_progress(id)           -> xp_no_nivel, xp_necessario, fracao
--    Evo.can_evolve(id) / Evo.evolve(id) / Evo.history(id)
-- =============================================================================
local Evo = {}
Evo.VERSION = 1
Evo.FILE = "assets/mascots/evolution.json"

local cfg
local DEFAULT = {
  formula = { base = 32, exponent = 0.7, max_level = 99 },
  stages = { { stage = 1, min_level = 1 }, { stage = 2, min_level = 10 }, { stage = 3, min_level = 20 },
    { stage = 4, min_level = 35 }, { stage = 5, min_level = 50 } },
  rewards = {},
}

function Evo.config()
  if cfg then return cfg end
  local ok, txt = pcall(love.filesystem.read, Evo.FILE)
  if ok and txt then
    local okj, d = pcall(require("lib.json").decode, txt)
    if okj and type(d) == "table" and type(d.formula) == "table" and type(d.stages) == "table" then cfg = d end
  end
  cfg = cfg or DEFAULT
  cfg.rewards = cfg.rewards or {}
  -- tabela acumulada: total[L] = XP total para estar no nivel L
  local f = cfg.formula
  cfg.total = { [1] = 0 }
  for n = 1, (f.max_level or 99) - 1 do
    cfg.total[n + 1] = cfg.total[n] + math.max(1, math.floor((f.base or 32) * n ^ (f.exponent or 0.7) + 0.5))
  end
  return cfg
end

--- XP necessario para ir do nivel n ao n+1
function Evo.xp_for(n)
  local t = Evo.config().total
  if not t[n + 1] then return math.huge end
  return t[n + 1] - t[n]
end

function Evo.level_for_xp(xp)
  local t = Evo.config().total
  local lv = 1
  for n = 2, #t do if xp >= t[n] then lv = n else break end end
  return lv
end

function Evo.stage_for_level(lv)
  local st = 1
  for _, s in ipairs(Evo.config().stages) do if lv >= (s.min_level or 1) then st = math.max(st, s.stage) end end
  return st
end

function Evo.stage_info(stage)
  for _, s in ipairs(Evo.config().stages) do if s.stage == stage then return s end end
  return nil
end

function Evo.max_stage() return #Evo.config().stages end

-- ---------------------------------------------------------------- dados
local function Mo() return require("core.mascot") end

local function sanitize(evo)
  if type(evo) ~= "table" then evo = {} end
  evo.version = tonumber(evo.version) or 0
  if type(evo.mascots) ~= "table" then evo.mascots = {} end
  for id, r in pairs(evo.mascots) do
    if type(r) ~= "table" or type(id) ~= "string" then evo.mascots[id] = nil
    else
      r.xp = math.max(0, math.floor(tonumber(r.xp) or 0))
      r.stage = math.max(1, math.min(Evo.max_stage(), math.floor(tonumber(r.stage) or 1)))
      if type(r.unlocked) ~= "table" then r.unlocked = {} end
      local un = {}
      for _, s in ipairs(r.unlocked) do if tonumber(s) then un[#un + 1] = math.floor(tonumber(s)) end end
      r.unlocked = un
      local have = {}
      for _, s in ipairs(un) do have[s] = true end
      for s = 1, r.stage do if not have[s] then r.unlocked[#r.unlocked + 1] = s end end
      table.sort(r.unlocked)
      if type(r.history) ~= "table" then r.history = {} end
    end
  end
  if type(evo.daily) ~= "table" then evo.daily = {} end
  if type(evo.daily.counts) ~= "table" then evo.daily.counts = {} end
  if type(evo.once) ~= "table" then evo.once = {} end
  return evo
end

--- estado de evolucao (dentro do mascot.json), validado e migrado
function Evo.data()
  local st = Mo().load()
  if Evo._checked ~= st then
    local old_version = type(st.evo) == "table" and tonumber(st.evo.version) or nil
    st.evo = sanitize(st.evo)
    if not old_version then
      -- migracao 0.5.5: o nivel unico antigo vai para o mascote atual (sem perder nivel)
      local xp_old = tonumber(st.xp) or 0
      local lv_old = math.floor(math.sqrt(math.max(0, xp_old) / 10)) + 1
      local cur = st.species or "slime"
      local r = Evo.record(cur, st.evo)
      r.xp = math.max(r.xp, Evo.config().total[math.min(lv_old, #Evo.config().total)] or 0)
    end
    st.evo.version = Evo.VERSION
    Evo._checked = st
  end
  return st.evo
end

local function Dex() return require("core.digipet.dex") end

function Evo.record(id, evo)
  evo = evo or Evo.data()
  local r = evo.mascots[id]
  if not r then
    r = { xp = 0, stage = 1, unlocked = { 1 }, history = {} }
    evo.mascots[id] = r
  end
  -- forma atual na arvore (dados antigos: so o estagio -> forma principal)
  local ln = Dex().line(id)
  if ln then
    local f = r.form and Dex().form(r.form)
    if not f or f.line ~= id then
      local pick = ln.forms[1]
      for _, fm in ipairs(ln.forms) do if fm.tier == r.stage and fm.branch ~= "alt" then pick = fm end end
      r.form = pick.id
    end
    r.stage = Dex().form(r.form).tier
    if type(r.discovered) ~= "table" then r.discovered = {} end
    local seen = {}
    for _, x in ipairs(r.discovered) do seen[x] = true end
    if not seen[r.form] then r.discovered[#r.discovered + 1] = r.form end
  end
  return r
end

--- forma atual (tabela da enciclopedia) de uma linha
function Evo.get_form(id) return Dex().form(Evo.record(id).form) end
function Evo.discovered(id, form_id)
  for _, x in ipairs(Evo.record(id).discovered or {}) do if x == form_id then return true end end
  return false
end

local function save() Mo().save() end

-- ---------------------------------------------------------------- consultas
function Evo.get_xp(id) return Evo.record(id).xp end
function Evo.get_level(id) return Evo.level_for_xp(Evo.record(id).xp) end
--- estagio ATUAL (o modelo mostrado). Pode estar atras do nivel ate a cena tocar.
function Evo.get_stage(id) return Evo.record(id).stage end
function Evo.history(id) return Evo.record(id).history end
function Evo.is_unlocked(id, stage)
  for _, s in ipairs(Evo.record(id).unlocked) do if s == stage then return true end end
  return false
end

--- progresso dentro do nivel: xp no nivel, xp necessario, fracao
function Evo.get_progress(id)
  local xp = Evo.record(id).xp
  local lv = Evo.level_for_xp(xp)
  local t = Evo.config().total
  local need = Evo.xp_for(lv)
  if need == math.huge then return 0, 0, 1 end
  local cur = xp - t[lv]
  return cur, need, math.max(0, math.min(1, cur / need))
end

--- nivel que falta para a proxima forma (nil no ultimo estagio)
function Evo.next_stage_level(id)
  local st = Evo.get_stage(id)
  local nxt = Evo.stage_info(st + 1)
  return nxt and nxt.min_level or nil
end

-- ------------------------------------------------------------- requisitos
local function count_lines_tier(t)
  local n = 0
  for lid, rr in pairs(Evo.data().mascots) do
    local f = rr.form and Dex().form(rr.form)
    if f and f.tier >= t then n = n + 1 end
  end
  return n
end

local function screens_seen()
  local n = 0
  for k in pairs(Evo.data().once) do if k:find("^discover:") then n = n + 1 end end
  return n
end

local function album_done()
  local okA, A = pcall(require, "core.achievements")
  if not okA then return false end
  local a, b = A.count()
  return b > 0 and a >= b
end

--- confere um requisito; devolve lista { {key, need, have, ok} } e ok geral
function Evo.check_req(id, req)
  local Care = require("core.digipet.care")
  local c = Care.tick(id)
  local f = Evo.get_form(id)
  local attrs = Care.attrs(id, f)
  local out, all = {}, true
  local function chk(key, need, have)
    local ok = (have or 0) >= need
    out[#out + 1] = { key = key, need = need, have = math.floor(have or 0), ok = ok }
    if not ok then all = false end
  end
  if req.level then chk("level", req.level, Evo.get_level(id)) end
  if req.happiness then chk("happiness", req.happiness, c.happiness) end
  if req.health then chk("health", req.health, c.health) end
  for _, k in ipairs({ "trainings", "feeds", "plays", "pets", "minigames" }) do
    if req[k] then chk(k, req[k], c.count[k]) end
  end
  if req.care then chk("care", req.care, c.count.pets + c.count.plays + c.count.feeds) end
  if type(req.attr) == "table" then for a, v in pairs(req.attr) do chk("attr_" .. a, v, attrs[a]) end end
  if req.attr_sum then chk("attr_sum", req.attr_sum, attrs.pow + attrs.def + attrs.spd + attrs.wis) end
  if req.lines then chk("lines", req.lines, count_lines_tier(4)) end
  if req.screens then chk("screens", req.screens, screens_seen()) end
  if req.album then chk("album", 1, album_done() and 1 or 0) end
  if req.night then
    local h = tonumber(os.date("%H"))
    chk("night", 1, (h >= 0 and h < 4) and 1 or 0)
  end
  return all, out
end

--- destinos possiveis a partir da forma atual: { {to=forma, ok, list, entry} }
function Evo.candidates(id)
  local f = Evo.get_form(id)
  local out = {}
  for _, e in ipairs(f and f.evolves or {}) do
    local ok, list = Evo.check_req(id, e.req or {})
    out[#out + 1] = { to = Dex().form(e.to), ok = ok, list = list, entry = e }
  end
  return out
end

--- pode evoluir agora? devolve a forma de destino (primeiro ramo cumprido)
function Evo.can_evolve(id)
  if not Dex().line(id) then
    local r = Evo.record(id)
    return Evo.stage_for_level(Evo.level_for_xp(r.xp)) > r.stage
  end
  for _, cnd in ipairs(Evo.candidates(id)) do
    if cnd.ok and cnd.to then return cnd.to end
  end
  return false
end

--- evolui para a proxima forma (chamado pela cena de evolucao). Nunca duplica.
function Evo.evolve(id, to_id)
  local r = Evo.record(id)
  local target = Evo.can_evolve(id)
  if not target then return false end
  if to_id and target.id ~= to_id then
    -- o jogador escolheu outro ramo valido?
    local okc = false
    for _, cnd in ipairs(Evo.candidates(id)) do if cnd.ok and cnd.to and cnd.to.id == to_id then okc = true; target = cnd.to end end
    if not okc then return false end
  end
  local from_form, from = r.form, r.stage
  r.form = target.id
  r.stage = target.tier
  if not Evo.is_unlocked(id, r.stage) then r.unlocked[#r.unlocked + 1] = r.stage; table.sort(r.unlocked) end
  local seen = false
  for _, x in ipairs(r.discovered or {}) do if x == target.id then seen = true end end
  if not seen then r.discovered[#r.discovered + 1] = target.id end
  r.history[#r.history + 1] = { t = os.time(), from = from, to = r.stage, from_form = from_form, to_form = target.id,
    level = Evo.get_level(id) }
  while #r.history > 50 do table.remove(r.history, 1) end
  save()
  pcall(function() require("lib.util").log("criatura evoluiu:", id, from_form, "->", target.id) end)
  return true, from_form, target.id
end

-- ---------------------------------------------------------------- XP
local function today() return os.date("%Y-%m-%d") end

--- concede XP a um mascote. source/key controlam limites (evolution.json)
function Evo.add_xp(id, n, source, key)
  n = math.floor(tonumber(n) or 0)
  if n <= 0 or not id then return 0 end
  local evo = Evo.data()
  local rw = source and Evo.config().rewards[source]
  if rw then
    if rw.unique then
      local k = source .. ":" .. tostring(key or "")
      if evo.once[k] then return 0 end
      evo.once[k] = true
    elseif rw.per_day then
      if evo.daily.day ~= today() then evo.daily.day, evo.daily.counts = today(), {} end
      local c = evo.daily.counts[source] or 0
      if c >= rw.per_day then return 0 end
      evo.daily.counts[source] = c + 1
    end
  end
  local r = Evo.record(id, evo)
  local before = Evo.level_for_xp(r.xp)
  r.xp = r.xp + n
  save()
  local after = Evo.level_for_xp(r.xp)
  if after > before then pcall(Evo.on_level_up, id, after) end
  return n
end

--- recompensa configurada para o mascote atual (so com mascote liberado)
function Evo.reward(source, key)
  if not Mo().unlocked() then return 0 end
  local rw = Evo.config().rewards[source]
  if not rw then return 0 end
  return Evo.add_xp(Mo().current("species").id, rw.xp or 0, source, key)
end

--- subiu de nivel: fala e, se cruzou o estagio, deixa a evolucao pendente
function Evo.on_level_up(id, lv)
  local cur = Mo().current("species").id
  if id ~= cur then return end
  if Evo.can_evolve(id) then
    Evo.pending = id
  else
    local I18N = require("lib.i18n")
    Mo().say(string.format(I18N.tr(require("lib.i18n").L("Subi para o nível %d!")), lv), "happy", 3.5)
  end
end

--- chamado no update do mascote: evolucao pendente do mascote atual?
function Evo.check_pending()
  local cur = Mo().current("species").id
  if Evo.can_evolve(cur) then Evo.pending = cur end
  return Evo.pending
end

return Evo
