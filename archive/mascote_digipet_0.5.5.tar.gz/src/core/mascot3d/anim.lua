-- =============================================================================
--  AnimationController dos mascotes 3D
--  Anima cada PECA do modelo (rotacao, deslocamento, escala) por procedimento,
--  sem esqueleto: funciona em qualquer mascote que siga os nomes de pecas do
--  gerador (root, body, head, arm_l/r, leg_l/r, wing_l/r, tail, tail_tip,
--  ear_l/r, horn_l/r, eye_l/r, mouth, antenna_tip, smoke_N, cape...).
--  Pecas que o modelo nao tem sao simplesmente ignoradas.
--  Animacoes: idle, blink, breathing, walk, jump, wave, celebrate, sleep,
--  surprise, interaction (+ sad, variacao do idle). Piscar e respirar correm
--  por cima de todas. A troca entre animacoes e suave (mistura de 0,25 s).
--    local c = Anim.new(cfg)      cfg = { float = bool } (registro)
--    Anim.play(c, "wave", 1.5)    toca por 1,5 s e volta ao estado base
--    Anim.set_base(c, "sleep")    estado de fundo (humor)
--    Anim.update(c, dt)
--    Anim.pose(c, animate)        -> { peca = {rx,ry,rz,tx,ty,tz,sx,sy,sz,color,hide} }
-- =============================================================================
local Anim = {}

Anim.LIST = { "idle", "blink", "breathing", "walk", "jump", "wave", "celebrate", "sleep", "surprise", "interaction" }
Anim.BLEND = 0.25

local sin, cos, abs, pi = math.sin, math.cos, math.abs, math.pi

function Anim.new(cfg)
  return {
    cfg = cfg or {}, base = "idle", state = "idle", t = 0, time = 0, left = nil,
    prev = nil, prev_t = 0, mix = 1,
    blink_in = 2 + math.random() * 3, blink_t = nil,
  }
end

--- troca o estado de fundo (idle, sleep, sad...)
function Anim.set_base(c, name)
  if c.base == name then return end
  c.base = name
  if not c.left then Anim.play(c, name) end
end

--- toca uma animacao; dur = nil fica nela ate outra ser pedida
function Anim.play(c, name, dur)
  if c.state == name and not dur then return end
  c.prev, c.prev_t = c.state, c.t
  c.state, c.t, c.mix = name, 0, 0
  c.left = dur
end

function Anim.update(c, dt)
  c.t = c.t + dt
  c.prev_t = c.prev_t + dt
  c.time = c.time + dt
  c.mix = math.min(1, c.mix + dt / Anim.BLEND)
  if c.left then
    c.left = c.left - dt
    if c.left <= 0 then c.left = nil; Anim.play(c, c.base) end
  end
  -- piscar (independente)
  if c.blink_t then
    c.blink_t = c.blink_t + dt
    if c.blink_t > 0.14 then c.blink_t = nil end
  else
    c.blink_in = c.blink_in - dt
    if c.blink_in <= 0 then c.blink_t = 0; c.blink_in = 2 + math.random() * 4 end
  end
end

-- ------------------------------------------------------------------ poses
-- cada pose escreve em P[peca] = { campos }; get(P, nome) cria a entrada
local function get(P, n)
  local q = P[n]
  if not q then q = {}; P[n] = q end
  return q
end
local function add(P, n, k, v) local q = get(P, n); q[k] = (q[k] or 0) + v end

local POSES = {}

function POSES.idle(P, t, cfg)
  add(P, "root", "ry", sin(t * 0.55) * 0.22)
  add(P, "head", "rz", sin(t * 1.1) * 0.05)
  add(P, "head", "rx", sin(t * 0.8) * 0.03)
  add(P, "arm_l", "rz", -0.05 + sin(t * 1.6) * 0.06)
  add(P, "arm_r", "rz", 0.05 - sin(t * 1.6) * 0.06)
  add(P, "tail", "ry", sin(t * 2.2) * 0.35)
  add(P, "tail_tip", "ry", sin(t * 2.2 - 0.8) * 0.4)
  add(P, "wing_l", "ry", sin(t * 1.4) * 0.12)
  add(P, "wing_r", "ry", -sin(t * 1.4) * 0.12)
  add(P, "ear_l", "rz", sin(t * 0.9) * 0.05)
  add(P, "ear_r", "rz", -sin(t * 0.9 + 1) * 0.05)
  add(P, "cape", "rx", -0.05 - sin(t * 1.3) * 0.05)
end

function POSES.sad(P, t, cfg)
  POSES.idle(P, t * 0.5, cfg)
  add(P, "head", "rx", 0.28)
  add(P, "arm_l", "rz", 0.12)
  add(P, "arm_r", "rz", -0.12)
  add(P, "ear_l", "rz", 0.35)
  add(P, "ear_r", "rz", -0.35)
  add(P, "wing_l", "rz", 0.2)
  add(P, "wing_r", "rz", -0.2)
  get(P, "eye_l").sy = 0.7; get(P, "eye_r").sy = 0.7
  add(P, "eye_l", "ty", -0.01); add(P, "eye_r", "ty", -0.01)
end

function POSES.walk(P, t, cfg)
  local w = t * 8
  add(P, "root", "ty", abs(sin(w)) * 0.035)
  add(P, "root", "rz", sin(w) * 0.06)
  add(P, "root", "ry", sin(t * 0.6) * 0.5)
  add(P, "leg_l", "rx", sin(w) * 0.55)
  add(P, "leg_r", "rx", -sin(w) * 0.55)
  add(P, "arm_l", "rx", -sin(w) * 0.6)
  add(P, "arm_r", "rx", sin(w) * 0.6)
  add(P, "tail", "ry", sin(w * 0.5) * 0.4)
  add(P, "head", "rz", -sin(w) * 0.04)
  if cfg.blob then
    get(P, "body").sy = 1 + sin(w) * 0.06; get(P, "body").sx = 1 - sin(w) * 0.04
  end
end

local function hop(P, p, h)
  -- p: 0..1 de um pulo (agacha, sobe, cai, assenta)
  local up = sin(math.max(0, math.min(1, (p - 0.15) / 0.7)) * pi)
  local squash = p < 0.15 and (p / 0.15) or (p > 0.85 and (1 - p) / 0.15 or 0)
  add(P, "root", "ty", up * h)
  local b = get(P, "root")
  b.sy = (b.sy or 1) * (1 - squash * 0.14 + up * 0.06)
  b.sx = (b.sx or 1) * (1 + squash * 0.08 - up * 0.03)
  b.sz = b.sx
  return up
end

function POSES.jump(P, t, cfg)
  local p = math.min(1, t / 0.8)
  local up = hop(P, p, 0.32)
  add(P, "arm_l", "rz", -up * 1.6)
  add(P, "arm_r", "rz", up * 1.6)
  add(P, "leg_l", "rx", up * 0.3)
  add(P, "leg_r", "rx", -up * 0.3)
  add(P, "wing_l", "ry", up * 0.6)
  add(P, "wing_r", "ry", -up * 0.6)
  add(P, "ear_l", "rz", -up * 0.2)
  add(P, "ear_r", "rz", up * 0.2)
end

function POSES.wave(P, t, cfg)
  POSES.idle(P, t, cfg)
  local raise = math.min(1, t / 0.25)
  add(P, "arm_r", "rz", raise * (2.3 + sin(t * 11) * 0.35))
  add(P, "wing_r", "ry", -raise * (0.5 + sin(t * 11) * 0.3))
  add(P, "head", "rz", -raise * 0.12)
  add(P, "root", "ry", -0.25 * raise)
  P.eyes_happy = true
end

function POSES.celebrate(P, t, cfg)
  local p = (t % 0.55) / 0.55
  local up = hop(P, p, 0.18)
  add(P, "root", "ry", sin(t * 3.2) * 0.6)
  add(P, "arm_l", "rz", -2.4 - sin(t * 14) * 0.3)
  add(P, "arm_r", "rz", 2.4 + sin(t * 14) * 0.3)
  add(P, "wing_l", "ry", sin(t * 16) * 0.6)
  add(P, "wing_r", "ry", -sin(t * 16) * 0.6)
  add(P, "tail", "ry", sin(t * 9) * 0.6)
  add(P, "head", "rz", sin(t * 7) * 0.12)
  get(P, "antenna_tip").s = 1 + up * 0.5
  P.eyes_happy = true
end

function POSES.sleep(P, t, cfg)
  local b = sin(t * 1.4)
  add(P, "head", "rx", 0.32)
  add(P, "head", "rz", 0.12)
  add(P, "root", "rz", 0.04)
  local q = get(P, "body"); q.sy = (q.sy or 1) * (1 + b * 0.035); q.sx = (q.sx or 1) * (1 - b * 0.015)
  add(P, "arm_l", "rz", 0.15); add(P, "arm_r", "rz", -0.15)
  add(P, "wing_l", "rz", 0.15); add(P, "wing_r", "rz", -0.15)
  add(P, "ear_l", "rz", 0.3); add(P, "ear_r", "rz", -0.3)
  add(P, "tail", "ry", 0.6)
  P.eyes_closed = true
end

function POSES.surprise(P, t, cfg)
  local k = math.min(1, t / 0.15)
  local jolt = sin(math.min(1, t / 0.35) * pi)
  add(P, "root", "ty", jolt * 0.08)
  add(P, "root", "rx", -0.12 * k)
  add(P, "arm_l", "rz", -1.2 * k + sin(t * 30) * 0.05)
  add(P, "arm_r", "rz", 1.2 * k - sin(t * 30) * 0.05)
  add(P, "wing_l", "ry", 0.7 * k); add(P, "wing_r", "ry", -0.7 * k)
  add(P, "ear_l", "rz", -0.25 * k); add(P, "ear_r", "rz", 0.25 * k)
  add(P, "tail", "rx", -0.5 * k)
  local e = 1 + 0.35 * k
  get(P, "eye_l").s = e; get(P, "eye_r").s = e
  local m = get(P, "mouth"); m.sx = 1 + 0.2 * k; m.sy = 1 + 2.2 * k
end

function POSES.interaction(P, t, cfg)
  -- carinho: espreme, inclina a cabeca, bochechas e olhos felizes
  local s = sin(t * 9)
  local q = get(P, "body"); q.sy = (q.sy or 1) * (1 - 0.06 + s * 0.04); q.sx = (q.sx or 1) * (1 + 0.04 - s * 0.03)
  q.sz = q.sx
  add(P, "head", "rz", 0.18 + sin(t * 4.5) * 0.08)
  add(P, "root", "ry", sin(t * 2) * 0.2)
  add(P, "arm_l", "rz", -0.5 + s * 0.1)
  add(P, "arm_r", "rz", 0.5 - s * 0.1)
  add(P, "tail", "ry", sin(t * 12) * 0.5)
  add(P, "wing_l", "ry", 0.2 + s * 0.15); add(P, "wing_r", "ry", -0.2 - s * 0.15)
  P.eyes_happy = true
  P.blush = true
end

-- "blink" e "breathing" sozinhos: o idle com o efeito em destaque
function POSES.blink(P, t, cfg) POSES.idle(P, t, cfg); if t % 0.6 < 0.14 then P.eyes_closed = true end end
function POSES.breathing(P, t, cfg)
  POSES.idle(P, t, cfg)
  local b = sin(t * 2.4)
  local q = get(P, "body"); q.sy = (q.sy or 1) * (1 + b * 0.05); q.sx = (q.sx or 1) * (1 - b * 0.02)
end

-- ------------------------------------------------------------------ mistura
local FIELDS = { "rx", "ry", "rz", "tx", "ty", "tz" }
local SFIELDS = { "sx", "sy", "sz", "s" }

local function blend(a, b, k)
  local out = {}
  local names = {}
  for n, v in pairs(a) do if type(v) == "table" then names[n] = true end end
  for n, v in pairs(b) do if type(v) == "table" then names[n] = true end end
  for n in pairs(names) do
    local qa, qb, q = a[n] or {}, b[n] or {}, {}
    for _, f in ipairs(FIELDS) do q[f] = (qa[f] or 0) * (1 - k) + (qb[f] or 0) * k end
    for _, f in ipairs(SFIELDS) do
      if qa[f] or qb[f] then q[f] = (qa[f] or 1) * (1 - k) + (qb[f] or 1) * k end
    end
    q.color = (k < 0.5 and qa.color or qb.color)
    out[n] = q
  end
  for _, flag in ipairs({ "eyes_happy", "eyes_closed", "blush" }) do
    if (k < 0.5 and a[flag]) or (k >= 0.5 and b[flag]) then out[flag] = true end
  end
  return out
end

local function eval(name, t, cfg)
  local P = {}
  ;(POSES[name] or POSES.idle)(P, t, cfg)
  return P
end

--- pose final de todas as pecas
--  animate=false: pose parada (economiza e respeita "animacoes desligadas")
function Anim.pose(c, animate)
  local cfg = c.cfg
  local P
  if animate == false then
    P = {}
    if c.base == "sleep" then P.eyes_closed = true; add(P, "head", "rx", 0.3) end
  else
    P = eval(c.state, c.t, cfg)
    if c.mix < 1 and c.prev then
      local s = c.mix
      P = blend(eval(c.prev, c.prev_t, cfg), P, s * s * (3 - 2 * s))
    end
    -- respirar (sempre) e flutuar (fantasma, caveira)
    local b = sin(c.time * 2.1)
    local q = get(P, "body")
    q.sy = (q.sy or 1) * (1 + b * 0.022)
    q.sx = (q.sx or 1) * (1 - b * 0.010)
    if cfg.float then
      add(P, "root", "ty", 0.06 + sin(c.time * 1.8) * 0.035)
      add(P, "root", "rz", sin(c.time * 1.1) * 0.03)
    end
    for i = 1, 4 do add(P, "smoke_" .. i, "ry", c.time * (0.5 + i * 0.22)) end
    local tip = get(P, "antenna_tip")
    tip.s = (tip.s or 1) * (1 + 0.15 * sin(c.time * 5))
    if c.blink_t and not P.eyes_happy then P.eyes_closed = true end
  end
  -- expressoes nos olhos
  for _, e in ipairs({ "eye_l", "eye_r" }) do
    local q = get(P, e)
    if P.eyes_closed then q.sy = 0.12
    elseif P.eyes_happy then q.sy = (q.sy or 1) * 0.4; q.ty = (q.ty or 0) + 0.008 end
    if c.love then q.color = { 1, 0.35, 0.55, 0.9 } end
  end
  if P.blush or c.love then
    local q = get(P, "cheeks"); q.s = 1.35
  end
  return P
end

return Anim
