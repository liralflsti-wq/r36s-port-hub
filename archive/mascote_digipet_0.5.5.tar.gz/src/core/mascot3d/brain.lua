-- =============================================================================
--  Cerebro do mascote (MascotBrain): o que ele comenta enquanto voce usa o hub
--  Sem IA: regras com dados REAIS do hub (catalogo, ports instalados,
--  downloads, favoritos, cartas, atualizacoes). O MascotDialog continua sendo
--  o ponto para ligar uma IA no futuro (Dialog.provider).
--    Brain.on_screen(nome, params)  ao entrar/voltar para uma tela
--    Brain.update(dt)               ports novos no catalogo, versao nova do hub
--    Brain.game_tip()               dica sobre um port de verdade do catalogo
--    Brain.update_news(notes)       conta a novidade da atualizacao instalada
--  Controle para nao virar spam: espera minima entre falas (conforme a
--  frequencia escolhida em Meu perfil), cada tela comenta no maximo 1 vez a
--  cada 4 minutos, e "Em silencio" desliga tudo.
-- =============================================================================
local L = require("lib.i18n").L
local I18N = require("lib.i18n")

local B = {}

-- espera minima entre comentarios de tela (segundos) e chance de comentar
local GAP = { often = 8, normal = 18, rare = 50 }
local CHANCE = { often = 0.95, normal = 0.7, rare = 0.35 }
local SCREEN_COOLDOWN = 240

local last_talk = -999
local screen_last = {}
local told_update = false
local catalog_sig
B.told = {}

local function M() return require("core.mascot") end
local function now() return (App and App.t) or 0 end
local function tr(s) return I18N.tr(L(s)) end
local function pick(t) return t[math.random(#t)] end

local function freq() return M().talk() end

--- pode falar agora? (respeita silencio, intervalo e balao no ar)
local function can_talk(force)
  if not M().unlocked() or not M().enabled() then return false end
  local f = freq()
  if f == "off" then return false end
  if M().bubble and not force then return false end
  if not force and now() - last_talk < (GAP[f] or 25) then return false end
  return true
end

local function say(text, mood, dur)
  if not text or text == "" then return false end
  last_talk = now()
  pcall(function() require("lib.util").log("mascote diz:", text) end)
  M().say(text, mood or "happy", dur or 4.5)
  return true
end

-- ---------------------------------------------------------------- dados reais
local function catalog() local ok, C = pcall(require, "core.catalog"); return ok and C or nil end

local function installed_ports()
  local C = catalog()
  local okm, Man = pcall(require, "core.manifest")
  local out = {}
  if not C or not okm then return out end
  for _, p in ipairs(C.ports or {}) do
    local ok, st = pcall(Man.status, p)
    if ok and st ~= "none" then out[#out + 1] = p end
  end
  return out
end

local function random_port(filter)
  local C = catalog()
  if not C or not C.ports or #C.ports == 0 then return nil end
  local pool = {}
  for _, p in ipairs(C.ports) do if not p.builtin and (not filter or filter(p)) then pool[#pool + 1] = p end end
  return #pool > 0 and pick(pool) or nil
end

--- dica sobre um port de verdade (nome, categoria, tamanho)
function B.game_tip()
  local p = random_port()
  if not p then return nil end
  local lines = {
    function() return string.format(tr("Dica de jogo: %s, da categoria %s. Já conhece?"), p.name, p.category or "?") end,
    function()
      if p.size_label and p.size_label ~= "?" and p.size_label ~= "—" then
        return string.format(tr("%s tem só %s. Cabe fácil no seu cartão!"), p.name, p.size_label)
      end
      return string.format(tr("Já pensou em jogar %s hoje?"), p.name)
    end,
    function() return string.format(tr("Se curte %s, procure %s na Central de Conteúdo."), p.category or "?", p.name) end,
  }
  return pick(lines)()
end

-- ---------------------------------------------------------------- telas
local SCREENS = {}

SCREENS.menu = function(p)
  local inst = installed_ports()
  local opts = {}
  if #inst > 0 then
    local g = pick(inst)
    opts[#opts + 1] = string.format(tr("Que tal jogar %s agora?"), g.name)
    opts[#opts + 1] = string.format(tr("Você já tem %d ports instalados. Bela coleção!"), #inst)
  end
  local okn, N = pcall(require, "core.updnotice")
  if okn and N.pending() then opts[#opts + 1] = tr("Tem versão nova do hub! Vá em Configurações > Atualizações.") end
  opts[#opts + 1] = B.game_tip()
  return pick(opts)
end

SCREENS.store = function(prm)
  if prm and prm.mine then return SCREENS.myports() end
  if prm and prm.favs then
    local okf, F = pcall(require, "core.favorites")
    local n = okf and F.count() or 0
    if n == 0 then return tr("Nenhum favorito ainda. SELECT marca um port!") end
    return string.format(tr("%d favoritos! Você tem bom gosto."), n)
  end
  local C = catalog()
  local n = C and #(C.ports or {}) or 0
  local novos = 0
  if C and C.is_new then for _, p in ipairs(C.ports or {}) do if C.is_new(p) then novos = novos + 1 end end end
  if novos > 0 then return string.format(tr("Tem %d ports novos por aqui! Procure a etiqueta NOVO."), novos) end
  if n > 0 then return string.format(tr("Central de Conteúdo: %d ports esperando por você!"), n) end
  return tr("Bora achar um port novo?")
end

SCREENS.details = function(prm)
  local p = prm and prm.port
  if not p then return nil end
  local okm, Man = pcall(require, "core.manifest")
  local st = okm and select(2, pcall(Man.status, p)) or "none"
  if st == "update" then return string.format(tr("%s tem atualização! Vale a pena baixar."), p.name) end
  if st == "installed" then return string.format(tr("%s já está no seu console. Bora jogar?"), p.name) end
  local okf, F = pcall(require, "core.favorites")
  if okf and F.is(p) then return string.format(tr("%s está nos seus favoritos!"), p.name) end
  if p.size_label and p.size_label ~= "?" and p.size_label ~= "—" then
    return string.format(tr("%s: %s, ocupa %s. Quer instalar?"), p.name, p.category or "?", p.size_label)
  end
  return string.format(tr("Hmm, %s parece divertido!"), p.name)
end

-- Biblioteca de jogos = ROMs dos emuladores (core/library), nao os ports
SCREENS.library = function()
  local ok, Lib = pcall(require, "core.library")
  if not ok or not Lib.systems then return nil end
  local recent = Lib.recent()
  if recent[1] and math.random() < 0.5 then
    return string.format(tr("Da última vez você jogou %s. Vai continuar?"), recent[1].name)
  end
  local sys = Lib.with_games()
  if #sys == 0 then return tr("Nenhum jogo de emulador encontrado. Coloque ROMs no cartão!") end
  local s = pick(sys)
  local g = s.games[math.random(#s.games)]
  if g and g.name then
    return string.format(tr("Que tal %s no %s? Tenho um pressentimento bom."), g.name, s.fullname or s.name or s.key or "?")
  end
  return string.format(tr("Você tem %d jogos na biblioteca!"), Lib.total_games())
end
SCREENS.library_games = SCREENS.library
SCREENS.myports = function()
  local inst = installed_ports()
  if #inst == 0 then return tr("Nenhum port instalado ainda... vamos instalar algo?") end
  return string.format(tr("Que tal jogar %s hoje?"), pick(inst).name)
end

SCREENS.downloads = function()
  local okd, D = pcall(require, "core.downloads")
  if okd then
    local a = D.active()
    if a then return tr("Baixando... eu fico de olho para você!") end
    if D.waiting_count() > 0 then return string.format(tr("%d downloads na fila."), D.waiting_count()) end
  end
  return tr("Nenhum download agora. Tudo tranquilo!")
end

SCREENS.categories = function()
  local p = random_port()
  if p and p.category then return string.format(tr("Já olhou a categoria %s?"), p.category) end
  return tr("Escolha uma categoria e eu te acompanho!")
end

SCREENS.search = function() return tr("Procurando algo? Digite o nome do jogo.") end
SCREENS.settings = function() return pick({ tr("Mexendo nas configurações? Cuidado aí!"), tr("Dica: faça backup antes de mudar muita coisa.") }) end
SCREENS.settings_cat = function(prm)
  if prm and prm.id == "achievements" then return string.format(tr("Esse é o seu perfil, %s!"), require("core.achievements").user_name() or tr("amigo")) end
  return nil
end
SCREENS.about = function() return tr("Esse projeto é feito pela comunidade. Valeu por usar!") end
SCREENS.albums = function()
  local A = require("core.achievements")
  local a, b = A.count()
  if a >= b then return tr("Álbum completo! Você é lenda!") end
  return string.format(tr("Faltam %d cartas no seu álbum."), b - a)
end
SCREENS.achievements = SCREENS.albums
SCREENS.themes = function() return tr("Tema novo? Eu fico bonito em qualquer um!") end
SCREENS.ftp = function() return tr("Pelo FTP você manda arquivos do PC direto para o console.") end
SCREENS.wifi = function() return tr("Sem Wi-Fi não tem catálogo novo, hein!") end
SCREENS.netdiag = function() return tr("Vamos ver como está essa internet.") end
SCREENS.padtest = function() return tr("Aperte todos os botões! Eu conto.") end
SCREENS.bios = function() return tr("Alguns emuladores precisam de BIOS para funcionar.") end
SCREENS.update = function() return tr("Atualizar o hub traz novidades e correções.") end
SCREENS.updmgr = SCREENS.update
SCREENS.sdmaint = function() return tr("Cuidar do cartão SD evita dor de cabeça!") end
SCREENS.battery = function() return tr("Bateria é vida. Fique de olho!") end
SCREENS.digipet = function()
  local id = M().current("species").id
  local okE, Evo = pcall(require, "core.mascot3d.evolution")
  if okE and Evo.can_evolve(id) then return tr("Sinto uma energia estranha... acho que vou evoluir!") end
  local c = require("core.digipet.care").get(id)
  if c.energy < 30 then return tr("Tô com fome... me dá um lanche?") end
  if c.happiness < 35 then return tr("Brinca comigo um pouquinho?") end
  return pick({ tr("Bora treinar hoje?"), tr("Esse aparelho é a minha casa!") })
end
SCREENS.digidex = function() return tr("Quantas criaturas será que existem?") end

function B.on_screen(name, params)
  if not name or name == "mascot" then return end
  local fn = SCREENS[name]
  if not fn or not can_talk() then return end
  local t = now()
  if screen_last[name] and t - screen_last[name] < SCREEN_COOLDOWN then return end
  if math.random() > (CHANCE[freq()] or 0.7) then return end
  local ok, text = pcall(fn, params)
  if ok and text then
    screen_last[name] = t
    say(text, "happy", 4.5)
  end
end

-- ---------------------------------------------------------------- vigilancia
--- ports que entraram no catalogo desde a ultima vez (lista salva no mascote)
local function check_new_ports()
  local C = catalog()
  if not C or not C.ports or #C.ports == 0 then return end
  local sig = #C.ports .. "|" .. tostring(C.updated or "")
  if sig == catalog_sig then return end
  catalog_sig = sig
  local st = M().load()
  local seen = type(st.seen_ports) == "table" and st.seen_ports or nil
  local ids, set = {}, {}
  for _, p in ipairs(C.ports) do if not p.builtin and p.id then ids[#ids + 1] = p.id; set[p.id] = p end end
  if not seen then st.seen_ports = ids; M().save(); return end   -- primeira vez: so memoriza
  local old = {}
  for _, id in ipairs(seen) do old[id] = true end
  local fresh = {}
  for _, id in ipairs(ids) do if not old[id] then fresh[#fresh + 1] = set[id] end end
  st.seen_ports = ids
  M().save()
  if #fresh > 0 and freq() ~= "off" then
    local p = fresh[1]
    local txt = #fresh == 1 and string.format(tr("Port novo no catálogo: %s! Corre ver!"), p.name)
      or string.format(tr("Chegaram %d ports novos no catálogo! Um deles é %s."), #fresh, p.name)
    B.pending = { txt, "dance" }
  end
end

function B.update(dt)
  if not M().unlocked() then return end
  B.check_t = (B.check_t or 0) - dt
  if B.check_t <= 0 then
    B.check_t = 5
    pcall(check_new_ports)
    if not told_update then
      local okn, N = pcall(require, "core.updnotice")
      if okn and N.pending() then
        told_update = true
        B.pending = B.pending or { string.format(tr("Saiu versão nova do hub: %s! Vá em Configurações > Atualizações."), N.label or N.version or ""), "surprise" }
      end
    end
  end
  -- criatura: pronta para evoluir ou precisando de cuidado (no maximo 1x por hora)
  B.care_t = (B.care_t or 20) - dt
  if B.care_t <= 0 and not B.pending then
    B.care_t = 60
    local id = M().current("species").id
    local okE, Evo = pcall(require, "core.mascot3d.evolution")
    local key, txt
    if okE and Evo.can_evolve(id) then key, txt = "evo", tr("Estou pronto para evoluir! Abra o aparelho em Meu perfil.")
    else
      local okC, Care = pcall(require, "core.digipet.care")
      local c = okC and Care.tick(id)
      if c and not c.sleeping and c.energy < 25 then key, txt = "food", tr("Tô com fome... me dá um lanche?")
      elseif c and c.happiness < 25 then key, txt = "play", tr("Brinca comigo um pouquinho?") end
    end
    if key and (now() - (B.told[key] or -9999)) > 3600 then
      B.told[key] = now()
      B.pending = { txt, key == "evo" and "dance" or "sad" }
    end
  end
  -- recado guardado: fala assim que puder (fora da tela de abertura)
  if B.pending and can_talk(true) and not M().bubble then
    local cur = App and App.current and App.current()
    if cur and cur.name ~= "splash" and cur.name ~= "disclaimer" and cur.name ~= "textinput" then
      local p = B.pending
      B.pending = nil
      say(p[1], p[2] == "surprise" and "scared" or p[2], 6)
    end
  end
end

--- novidade da atualizacao recem-instalada (notas do pacote)
function B.update_news(notes)
  if type(notes) ~= "table" then return end
  local first = (type(notes.changes) == "table" and notes.changes[1]) or (type(notes.fixes) == "table" and notes.fixes[1])
    or notes.description
  if type(first) == "table" then first = first.text or first[1] end
  if type(first) ~= "string" or first == "" then return end
  if #first > 90 then first = first:sub(1, 87):gsub("[\192-\255][\128-\191]*$", "") .. "..." end
  B.pending = { string.format(tr("Novidade da versão %s: %s"), tostring(notes.to_label or notes.to or ""), first), "dance" }
end

return B
