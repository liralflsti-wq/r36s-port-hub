-- =============================================================================
--  MascotDialog: o que o mascote fala e quando
--  Categorias: welcome, success, tip, update, celebrate, goodbye, error,
--  chatter (conversa solta de vez em quando). As frases com a personalidade
--  de cada mascote vem do registro (registry.json); as gerais ficam aqui.
--  Frequencia (campo "talk" do mascot.json): often, normal, rare, off.
--  Pronto para IA no futuro, sem depender dela:
--    Dialog.provider = function(category, ctx) return "texto" ou nil end
--  Se o provedor devolver nil (ou der erro), usa as frases locais.
-- =============================================================================
local L = require("lib.i18n").L
local I18N = require("lib.i18n")
local Reg = require("core.mascot3d.registry")

local D = {}

D.FREQ = { "often", "normal", "rare", "off" }
D.FREQ_NAMES = { often = L("Bastante"), normal = L("Normal"), rare = L("Pouco"), off = L("Em silêncio") }
-- intervalo da conversa solta (segundos)
local CHATTER = { often = 90, normal = 240, rare = 600 }

D.provider = nil

local SHARED = {
  tip = {
    L("Sabia? START abre os downloads de qualquer tela."),
    L("SELECT marca um port como favorito."),
    L("Segure B por 5 segundos para sair do teste de controles."),
    L("Faça backup das suas configurações de vez em quando!"),
    L("No álbum, A abre a carta inteira."),
    L("Pelo FTP você manda arquivos do PC direto para o console."),
    L("Trocar de tema também muda a música no Sky Warriors."),
    L("Cada carta que você ganha me dá um visual novo!"),
  },
  update = { L("O hub foi atualizado! Vem ver as novidades.") },
  error = { L("Eita! Deu ruim...") },
  chatter = {
    L("Tô aqui se precisar, viu?"),
    L("Que tal procurar um port novo hoje?"),
    L("Já viu o seu álbum de cartas?"),
    L("Hmm... que silêncio bom."),
  },
}

function D.freq()
  local v = require("core.mascot").talk()
  for _, f in ipairs(D.FREQ) do if f == v then return v end end
  return "normal"
end

function D.set_freq(v) require("core.mascot").set("talk", v) end

function D.chatter_interval() return CHATTER[D.freq()] end

--- frase da categoria para o mascote (ja traduzida); ctx = { species, name }
function D.line(category, ctx)
  ctx = ctx or {}
  if D.provider then
    local ok, txt = pcall(D.provider, category, ctx)
    if ok and type(txt) == "string" and txt ~= "" then return txt end
  end
  local m = Reg.get(ctx.species)
  local pool = m.messages and m.messages[category]
  if not pool or #pool == 0 then pool = SHARED[category] end
  if not pool or #pool == 0 then return nil end
  local txt = I18N.tr(L(pool[math.random(#pool)]))
  if txt:find("%%s") then txt = string.format(txt, ctx.name or "") end
  return txt
end

return D
