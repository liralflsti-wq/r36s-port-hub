#!/usr/bin/env python3
# =============================================================================
#  Gerador dos mascotes 3D low-poly do R36S PORT HUB (arte original, em codigo)
#  Saida: assets/mascots/<id>.glb  (glTF 2.0 binario, sem dependencias)
#         assets/mascots/hats.glb  (acessorios, um no por chapeu)
#  Cada mascote e montado por PECAS (nos do glTF) com o ponto de articulacao
#  (pivo) no lugar certo, para o AnimationController mexer cada uma:
#    root > body > head > (eye_l, eye_r, mouth, ear_*, horn_*, hat_anchor)
#               > arm_l, arm_r, leg_l, leg_r, tail, wing_l, wing_r ...
#  Sombreamento chapado (normal por face) e cor por vertice. Pecas com
#  extras.tint=true sao pintadas em tons de cinza e recebem a cor escolhida
#  pelo jogador no shader; extras.emissive=true brilha (sem luz).
#  Coordenadas: Y para cima, frente para +Z, pes em y=0, altura ~1.0.
#  Uso: python3 tools/make_mascots_glb.py [pasta_saida]
# =============================================================================
import json, math, os, struct, sys

# ---------------------------------------------------------------- geometria
def ico(sub=1):
    t = (1 + 5 ** 0.5) / 2
    v = [(-1, t, 0), (1, t, 0), (-1, -t, 0), (1, -t, 0), (0, -1, t), (0, 1, t), (0, -1, -t), (0, 1, -t),
         (t, 0, -1), (t, 0, 1), (-t, 0, -1), (-t, 0, 1)]
    v = [norm(p) for p in v]
    f = [(0, 11, 5), (0, 5, 1), (0, 1, 7), (0, 7, 10), (0, 10, 11), (1, 5, 9), (5, 11, 4), (11, 10, 2), (10, 7, 6),
         (7, 1, 8), (3, 9, 4), (3, 4, 2), (3, 2, 6), (3, 6, 8), (3, 8, 9), (4, 9, 5), (2, 4, 11), (6, 2, 10),
         (8, 6, 7), (9, 8, 1)]
    for _ in range(sub):
        cache = {}
        def mid(a, b):
            k = (min(a, b), max(a, b))
            if k not in cache:
                p = norm(tuple((v[a][i] + v[b][i]) / 2 for i in range(3)))
                v.append(p); cache[k] = len(v) - 1
            return cache[k]
        nf = []
        for a, b, c in f:
            ab, bc, ca = mid(a, b), mid(b, c), mid(c, a)
            nf += [(a, ab, ca), (b, bc, ab), (c, ca, bc), (ab, bc, ca)]
        f = nf
    return [tuple(v[i] for i in tri) for tri in f]

def norm(p):
    l = math.sqrt(sum(c * c for c in p)) or 1
    return tuple(c / l for c in p)

def box():
    P = [(-1, -1, -1), (1, -1, -1), (1, 1, -1), (-1, 1, -1), (-1, -1, 1), (1, -1, 1), (1, 1, 1), (-1, 1, 1)]
    Q = [(4, 5, 6, 7), (1, 0, 3, 2), (0, 4, 7, 3), (5, 1, 2, 6), (3, 7, 6, 2), (0, 1, 5, 4)]
    out = []
    for a, b, c, d in Q:
        out += [(P[a], P[b], P[c]), (P[a], P[c], P[d])]
    return out

def cyl(seg=8, r0=1.0, r1=1.0, caps=True):
    """cilindro/cone de y=0 a y=1 (raio r0 embaixo, r1 em cima)"""
    out = []
    for i in range(seg):
        a0, a1 = 2 * math.pi * i / seg, 2 * math.pi * (i + 1) / seg
        b0 = (math.sin(a0) * r0, 0, math.cos(a0) * r0); b1 = (math.sin(a1) * r0, 0, math.cos(a1) * r0)
        t0 = (math.sin(a0) * r1, 1, math.cos(a0) * r1); t1 = (math.sin(a1) * r1, 1, math.cos(a1) * r1)
        if r1 > 0:
            out += [(b0, b1, t1), (b0, t1, t0)]
        else:
            out += [(b0, b1, (0, 1, 0))]
        if caps:
            out.append(((0, 0, 0), b1, b0))
            if r1 > 0:
                out.append(((0, 1, 0), t0, t1))
    return out

def cone(seg=8):
    return cyl(seg, 1.0, 0.0)

def tri2(a, b, c):
    """triangulo de duas faces (asas, capas)"""
    return [(a, b, c), (a, c, b)]

def rotm(rx, ry, rz):
    rx, ry, rz = map(math.radians, (rx, ry, rz))
    cx, sx, cy, sy, cz, sz = math.cos(rx), math.sin(rx), math.cos(ry), math.sin(ry), math.cos(rz), math.sin(rz)
    X = ((1, 0, 0), (0, cx, -sx), (0, sx, cx))
    Y = ((cy, 0, sy), (0, 1, 0), (-sy, 0, cy))
    Z = ((cz, -sz, 0), (sz, cz, 0), (0, 0, 1))
    def mm(A, B):
        return tuple(tuple(sum(A[i][k] * B[k][j] for k in range(3)) for j in range(3)) for i in range(3))
    return mm(Y, mm(X, Z))

def xform(tris, s=(1, 1, 1), r=(0, 0, 0), t=(0, 0, 0)):
    if isinstance(s, (int, float)):
        s = (s, s, s)
    R = rotm(*r)
    out = []
    for tri in tris:
        nt = []
        for p in tri:
            q = (p[0] * s[0], p[1] * s[1], p[2] * s[2])
            q = tuple(R[i][0] * q[0] + R[i][1] * q[1] + R[i][2] * q[2] for i in range(3))
            nt.append((q[0] + t[0], q[1] + t[1], q[2] + t[2]))
        # escala negativa inverte a ordem dos vertices
        if s[0] * s[1] * s[2] < 0:
            nt = [nt[0], nt[2], nt[1]]
        out.append(tuple(nt))
    return out

# ---------------------------------------------------------------- modelo
class Model:
    def __init__(self, mid):
        self.id = mid
        self.parts = {}   # nome -> dict(parent, pivot, tris=[(tri, rgb)], extras)
        self.order = []

    def part(self, name, parent=None, pivot=(0, 0, 0), **extras):
        self.parts[name] = {"parent": parent, "pivot": pivot, "tris": [], "extras": extras}
        self.order.append(name)
        return name

    def add(self, name, tris, rgb):
        self.parts[name]["tris"] += [(t, rgb) for t in tris]

    def tri_count(self):
        return sum(len(p["tris"]) for p in self.parts.values())

def facenormal(a, b, c):
    u = [b[i] - a[i] for i in range(3)]; v = [c[i] - a[i] for i in range(3)]
    n = (u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0])
    return norm(n)

def model_bounds(model):
    """altura (pes em y=0 ate o topo), largura e profundidade do modelo"""
    ys, xs, zs = [0.0], [0.0], [0.0]
    for p in model.parts.values():
        for tri, _ in p["tris"]:
            for v in tri:
                xs.append(abs(v[0])); ys.append(v[1]); zs.append(abs(v[2]))
    return {"height": round(max(ys), 4), "width": round(2 * max(xs), 4), "depth": round(2 * max(zs), 4)}

def write_glb(model, path):
    nodes, meshes, accessors, views = [], [], [], []
    blob = bytearray()
    index = {n: i for i, n in enumerate(model.order)}

    def push(data, target=34962):
        while len(blob) % 4:
            blob.append(0)
        off = len(blob)
        blob.extend(data)
        views.append({"buffer": 0, "byteOffset": off, "byteLength": len(data), "target": target})
        return len(views) - 1

    for name in model.order:
        p = model.parts[name]
        par = p["parent"]
        ppiv = model.parts[par]["pivot"] if par else (0, 0, 0)
        node = {"name": name, "translation": [round(p["pivot"][i] - ppiv[i], 5) for i in range(3)]}
        ex = {k: v for k, v in p["extras"].items() if v}
        if ex:
            node["extras"] = ex
        if p["tris"]:
            pos, col = bytearray(), bytearray()
            mn, mx = [1e9] * 3, [-1e9] * 3
            for tri, rgb in p["tris"]:
                for v in tri:
                    lv = [v[i] - p["pivot"][i] for i in range(3)]
                    for i in range(3):
                        mn[i] = min(mn[i], lv[i]); mx[i] = max(mx[i], lv[i])
                    pos += struct.pack("<3f", *lv)
                    col += struct.pack("<4B", *[max(0, min(255, int(round(c * 255)))) for c in rgb], 255)
            cnt = len(p["tris"]) * 3
            a0 = len(accessors)
            accessors.append({"bufferView": push(pos), "componentType": 5126, "count": cnt, "type": "VEC3",
                              "min": [round(x, 5) for x in mn], "max": [round(x, 5) for x in mx]})
            # sem NORMAL: pelo glTF 2.0 o leitor calcula a normal chapada de cada
            # face (e o visual low-poly que queremos), e o arquivo fica 1/3 menor
            accessors.append({"bufferView": push(col), "componentType": 5121, "normalized": True, "count": cnt,
                              "type": "VEC4"})
            meshes.append({"name": name, "primitives": [{"attributes": {"POSITION": a0, "COLOR_0": a0 + 1},
                                                         "mode": 4}]})
            node["mesh"] = len(meshes) - 1
        nodes.append(node)
    for name in model.order:
        par = model.parts[name]["parent"]
        if par:
            nodes[index[par]].setdefault("children", []).append(index[name])
    roots = [index[n] for n in model.order if not model.parts[n]["parent"]]
    while len(blob) % 4:
        blob.append(0)
    gltf = {"asset": {"version": "2.0", "generator": "R36S PORT HUB make_mascots_glb.py"},
            "scene": 0, "scenes": [{"name": model.id, "nodes": roots}], "nodes": nodes, "meshes": meshes,
            "accessors": accessors, "bufferViews": views, "buffers": [{"byteLength": len(blob)}],
            "extras": {"triangles": model.tri_count(), **model_bounds(model)}}
    js = json.dumps(gltf, separators=(",", ":")).encode()
    while len(js) % 4:
        js += b" "
    out = struct.pack("<III", 0x46546C67, 2, 12 + 8 + len(js) + 8 + len(blob))
    out += struct.pack("<II", len(js), 0x4E4F534A) + js
    out += struct.pack("<II", len(blob), 0x004E4942) + bytes(blob)
    with open(path, "wb") as f:
        f.write(out)
    return len(out)

# ---------------------------------------------------------------- paleta
W = (0.96, 0.96, 0.96)       # pecas tingidas (cor do jogador)
W2 = (0.80, 0.80, 0.80)      # tingido mais escuro
W3 = (0.64, 0.64, 0.64)
INK = (0.10, 0.08, 0.12)
WHITE = (1, 1, 1)
CREAM = (1.0, 0.93, 0.78)
PINK = (1.0, 0.55, 0.65)
STEEL = (0.74, 0.78, 0.84)
STEEL2 = (0.52, 0.56, 0.63)
DARK = (0.20, 0.21, 0.26)
GOLD = (1.0, 0.80, 0.25)
BONE = (0.93, 0.91, 0.84)
SHADOW = (0.13, 0.10, 0.20)
SHADOW2 = (0.24, 0.17, 0.36)

def eyes(m, head, y, z, dx=0.11, r=0.055, sy=1.25, color=INK, shine=True, emissive=False):
    """dois olhos (eye_l, eye_r) presos na cabeca, com brilho"""
    for side, sx in (("l", -1), ("r", 1)):
        n = m.part("eye_" + side, head, (sx * dx, y, z), emissive=emissive)
        m.add(n, xform(ico(1), (r, r * sy, r * 0.6), t=(sx * dx, y, z)), color)
        if shine:
            m.add(n, xform(ico(0), r * 0.32, t=(sx * dx + r * 0.35, y + r * 0.45, z + r * 0.5)), WHITE)

def mouth(m, head, y, z, w=0.05, color=INK):
    n = m.part("mouth", head, (0, y, z))
    m.add(n, xform(box(), (w, w * 0.35, 0.012), t=(0, y, z)), color)

# ---------------------------------------------------------------- mascotes
def slime():
    m = Model("slime")
    m.part("root")
    m.part("body", "root", (0, 0, 0), tint=True)
    m.add("body", xform(ico(2), (0.46, 0.40, 0.42), t=(0, 0.38, 0)), W)
    m.add("body", xform(ico(1), (0.30, 0.12, 0.28), t=(0, 0.06, 0.04)), W2)
    m.part("head", "body", (0, 0.45, 0), tint=True)
    m.add("head", xform(cone(6), (0.10, 0.22, 0.10), t=(0.03, 0.70, -0.02), r=(-12, 0, -10)), W)
    eyes(m, "head", 0.46, 0.39, dx=0.13, r=0.062)
    mouth(m, "head", 0.34, 0.41, 0.045)
    # bochechas
    m.part("cheeks", "head", (0, 0.38, 0.38))
    for sx in (-1, 1):
        m.add("cheeks", xform(ico(0), (0.05, 0.025, 0.02), t=(sx * 0.24, 0.37, 0.36)), PINK)
    m.part("arm_l", "body", (-0.40, 0.30, 0.05), tint=True)
    m.add("arm_l", xform(ico(1), (0.09, 0.07, 0.08), t=(-0.46, 0.27, 0.05)), W)
    m.part("arm_r", "body", (0.40, 0.30, 0.05), tint=True)
    m.add("arm_r", xform(ico(1), (0.09, 0.07, 0.08), t=(0.46, 0.27, 0.05)), W)
    m.part("hat_anchor", "head", (0, 0.78, 0), hat_scale=0.85)
    return m

def robot():
    m = Model("robot")
    m.part("root")
    m.part("leg_l", "root", (-0.13, 0.20, 0))
    m.add("leg_l", xform(cyl(6), (0.06, 0.18, 0.06), t=(-0.13, 0.04, 0)), STEEL2)
    m.add("leg_l", xform(box(), (0.10, 0.04, 0.12), t=(-0.13, 0.04, 0.03)), DARK)
    m.part("leg_r", "root", (0.13, 0.20, 0))
    m.add("leg_r", xform(cyl(6), (0.06, 0.18, 0.06), t=(0.13, 0.04, 0)), STEEL2)
    m.add("leg_r", xform(box(), (0.10, 0.04, 0.12), t=(0.13, 0.04, 0.03)), DARK)
    m.part("body", "root", (0, 0.22, 0), tint=True)
    m.add("body", xform(box(), (0.26, 0.20, 0.20), t=(0, 0.42, 0)), W)
    m.part("panel", "body", (0, 0.42, 0.2))
    m.add("panel", xform(box(), (0.14, 0.09, 0.015), t=(0, 0.42, 0.205)), DARK)
    for i, c in enumerate(((1, 0.3, 0.3), (1, 0.85, 0.2), (0.3, 1, 0.5))):
        m.add("panel", xform(box(), (0.025, 0.025, 0.01), t=(-0.07 + i * 0.07, 0.44, 0.222)), c)
    for side, sx in (("l", -1), ("r", 1)):
        n = m.part("arm_" + side, "body", (sx * 0.28, 0.56, 0))
        m.add(n, xform(cyl(6), (0.045, 0.22, 0.045), t=(sx * 0.31, 0.34, 0)), STEEL2)
        m.add(n, xform(ico(1), 0.075, t=(sx * 0.31, 0.32, 0)), STEEL)
        m.add(n, xform(ico(0), 0.06, t=(sx * 0.30, 0.58, 0)), DARK)
    m.part("head", "body", (0, 0.64, 0), tint=True)
    m.add("head", xform(box(), (0.30, 0.20, 0.22), t=(0, 0.83, 0)), W)
    m.add("head", xform(box(), (0.04, 0.08, 0.08), t=(-0.32, 0.83, 0)), W2)
    m.add("head", xform(box(), (0.04, 0.08, 0.08), t=(0.32, 0.83, 0)), W2)
    m.add("head", xform(box(), (0.25, 0.14, 0.02), t=(0, 0.83, 0.215)), (0.06, 0.08, 0.12))
    m.add("head", xform(cyl(6), (0.06, 0.04, 0.06), t=(0, 0.62, 0)), STEEL2)
    for side, sx in (("l", -1), ("r", 1)):
        n = m.part("eye_" + side, "head", (sx * 0.10, 0.86, 0.24), emissive=True)
        m.add(n, xform(box(), (0.045, 0.045, 0.01), t=(sx * 0.10, 0.86, 0.24)), (0.35, 0.95, 1.0))
    n = m.part("mouth", "head", (0, 0.76, 0.24), emissive=True)
    m.add(n, xform(box(), (0.07, 0.012, 0.01), t=(0, 0.76, 0.24)), (0.35, 0.95, 1.0))
    m.part("antenna", "head", (0, 1.03, 0))
    m.add("antenna", xform(cyl(5), (0.015, 0.14, 0.015), t=(0, 1.03, 0)), STEEL2)
    m.part("antenna_tip", "antenna", (0, 1.18, 0), emissive=True)
    m.add("antenna_tip", xform(ico(1), 0.045, t=(0, 1.19, 0)), (1, 0.3, 0.3))
    m.part("hat_anchor", "head", (0, 1.03, 0), hat_scale=0.95)
    return m

def cat():
    m = Model("cat")
    m.part("root")
    for side, sx in (("l", -1), ("r", 1)):
        n = m.part("leg_" + side, "root", (sx * 0.13, 0.14, 0.08), tint=True)
        m.add(n, xform(cyl(6), (0.06, 0.14, 0.06), t=(sx * 0.13, 0.0, 0.08)), W)
        m.add(n, xform(ico(1), (0.065, 0.04, 0.075), t=(sx * 0.13, 0.03, 0.11)), CREAM)
    m.part("body", "root", (0, 0.16, 0), tint=True)
    m.add("body", xform(ico(1), (0.27, 0.24, 0.30), t=(0, 0.30, -0.02)), W)
    m.add("body", xform(ico(1), (0.17, 0.16, 0.10), t=(0, 0.28, 0.20)), CREAM)
    for side, sx in (("l", -1), ("r", 1)):
        n = m.part("arm_" + side, "body", (sx * 0.20, 0.36, 0.12), tint=True)
        m.add(n, xform(ico(1), (0.06, 0.11, 0.06), t=(sx * 0.21, 0.26, 0.15)), W)
    m.part("tail", "body", (0, 0.26, -0.28), tint=True)
    m.add("tail", xform(cyl(6), (0.04, 0.22, 0.04), r=(-55, 0, 0), t=(0, 0.26, -0.28)), W)
    m.part("tail_tip", "tail", (0, 0.39, -0.46), tint=True)
    m.add("tail_tip", xform(cyl(6, 1, 0.4), (0.04, 0.2, 0.04), r=(-10, 0, 0), t=(0, 0.39, -0.46)), W2)
    m.part("head", "body", (0, 0.50, 0.02), tint=True)
    m.add("head", xform(ico(1), (0.32, 0.27, 0.27), t=(0, 0.70, 0.03)), W)
    m.add("head", xform(ico(1), (0.12, 0.08, 0.08), t=(0, 0.62, 0.24)), CREAM)
    m.add("head", xform(cone(4), (0.03, 0.025, 0.03), r=(180, 45, 0), t=(0, 0.68, 0.31)), PINK)
    for side, sx in (("l", -1), ("r", 1)):
        n = m.part("ear_" + side, "head", (sx * 0.17, 0.90, 0.02), tint=True)
        m.add(n, xform(cone(4), (0.10, 0.17, 0.07), r=(0, 45, sx * -18), t=(sx * 0.17, 0.88, 0.02)), W)
        m.add(n, xform(cone(4), (0.05, 0.11, 0.03), r=(0, 45, sx * -18), t=(sx * 0.165, 0.89, 0.06)), PINK)
        for k in (-1, 1):
            m.add("head", xform(box(), (0.08, 0.004, 0.004), r=(0, 0, k * 8), t=(sx * 0.27, 0.64 + k * 0.025, 0.22)), INK)
    eyes(m, "head", 0.73, 0.255, dx=0.12, r=0.05, sy=1.35)
    mouth(m, "head", 0.60, 0.30, 0.03)
    m.part("hat_anchor", "head", (0, 0.95, 0.03), hat_scale=0.85)
    return m

def ghost():
    m = Model("ghost")
    m.part("root")
    m.part("body", "root", (0, 0.10, 0), tint=True, light=True)
    m.add("body", xform(ico(2), (0.36, 0.36, 0.34), t=(0, 0.56, 0)), W)
    m.add("body", xform(cyl(10, 1.0, 1.0, caps=False), (0.36, 0.30, 0.34), t=(0, 0.26, 0)), W)
    # barra ondulada
    seg = 10
    for i in range(seg):
        a0, a1 = 2 * math.pi * i / seg, 2 * math.pi * (i + 1) / seg
        am = (a0 + a1) / 2
        p0 = (math.sin(a0) * 0.36, 0.26, math.cos(a0) * 0.34)
        p1 = (math.sin(a1) * 0.36, 0.26, math.cos(a1) * 0.34)
        pm = (math.sin(am) * 0.33, 0.10, math.cos(am) * 0.31)
        m.add("body", [(p0, p1, pm), (p0, pm, p1)], W2)
    for side, sx in (("l", -1), ("r", 1)):
        n = m.part("arm_" + side, "body", (sx * 0.34, 0.46, 0.04), tint=True, light=True)
        m.add(n, xform(ico(1), (0.10, 0.06, 0.07), r=(0, 0, sx * -25), t=(sx * 0.40, 0.42, 0.04)), W)
    m.part("head", "body", (0, 0.56, 0))
    eyes(m, "head", 0.62, 0.31, dx=0.12, r=0.06, sy=1.6)
    n = m.part("mouth", "head", (0, 0.47, 0.32))
    m.add(n, xform(ico(1), (0.04, 0.05, 0.02), t=(0, 0.47, 0.32)), INK)
    m.part("cheeks", "head", (0, 0.52, 0.31))
    for sx in (-1, 1):
        m.add("cheeks", xform(ico(0), (0.045, 0.022, 0.02), t=(sx * 0.21, 0.53, 0.29)), PINK)
    m.part("hat_anchor", "head", (0, 0.91, 0), hat_scale=0.8)
    return m

def skull():
    m = Model("skull")
    m.part("root")
    m.part("body", "root", (0, 0.05, 0), tint=False)
    m.add("body", xform(cyl(9, 1.0, 0.45, caps=False), (0.34, 0.58, 0.30), t=(0, 0.02, 0)), SHADOW)
    m.add("body", xform(cyl(9, 1.0, 0.95), (0.345, 0.05, 0.305), t=(0, 0.0, 0)), SHADOW2)
    # capuz (atras da cabeca)
    m.add("body", xform(ico(1), (0.31, 0.33, 0.26), t=(0, 0.74, -0.15)), SHADOW)
    m.add("body", xform(cone(6), (0.22, 0.30, 0.18), r=(-35, 0, 0), t=(0, 0.88, -0.22)), SHADOW)
    # pontas de fumaça na barra
    for i in range(9):
        a = 2 * math.pi * (i + 0.5) / 9
        p = (math.sin(a) * 0.33, 0.02, math.cos(a) * 0.29)
        m.add("body", xform(cone(4), (0.06, 0.14, 0.06), r=(180, 0, 0), t=p), SHADOW2)
    for side, sx in (("l", -1), ("r", 1)):
        n = m.part("arm_" + side, "body", (sx * 0.22, 0.48, 0.05))
        m.add(n, xform(cyl(6, 1, 0.7), (0.07, 0.22, 0.07), r=(180, 0, sx * -12), t=(sx * 0.24, 0.48, 0.06)), SHADOW)
        m.add(n, xform(ico(1), 0.045, t=(sx * 0.28, 0.25, 0.08)), BONE)
        for k in (-1, 0, 1):
            m.add(n, xform(box(), (0.008, 0.035, 0.008), t=(sx * 0.28 + k * 0.022, 0.20, 0.09)), BONE)
    m.part("head", "body", (0, 0.58, 0.02))
    m.add("head", xform(ico(1), (0.25, 0.23, 0.23), t=(0, 0.76, 0.04)), BONE)
    m.add("head", xform(box(), (0.14, 0.06, 0.12), t=(0, 0.58, 0.08)), BONE)
    for k in range(-2, 3):
        m.add("head", xform(box(), (0.012, 0.025, 0.01), t=(k * 0.05, 0.55, 0.205)), INK)
    # orbitas fundas
    for sx in (-1, 1):
        m.add("head", xform(ico(1), (0.075, 0.065, 0.03), t=(sx * 0.095, 0.74, 0.245)), INK)
    m.add("head", xform(cone(3), (0.03, 0.05, 0.02), r=(180, 0, 0), t=(0, 0.69, 0.265)), INK)
    m.add("head", xform(box(), (0.004, 0.06, 0.004), r=(0, 0, 25), t=(0.12, 0.90, 0.21)), (0.6, 0.58, 0.52))
    for side, sx in (("l", -1), ("r", 1)):
        n = m.part("eye_" + side, "head", (sx * 0.095, 0.74, 0.27), tint=True, emissive=True)
        m.add(n, xform(ico(1), (0.035, 0.03, 0.02), t=(sx * 0.095, 0.74, 0.27)), W)
    m.part("mouth", "head", (0, 0.58, 0.2))
    # fumaça que orbita (gira em volta do pivo central; fica abaixo do rosto)
    for i in range(1, 4):
        n = m.part("smoke_%d" % i, "root", (0, 0.3, 0))
        a = i * 2.1
        m.add(n, xform(ico(1), 0.045 + i * 0.01, t=(math.sin(a) * 0.48, 0.12 + i * 0.1, math.cos(a) * 0.40)),
              SHADOW2 if i % 2 else SHADOW)
    m.part("hat_anchor", "head", (0, 0.98, 0.04), hat_scale=0.75)
    return m

def dragon():
    m = Model("dragon")
    m.part("root")
    for side, sx in (("l", -1), ("r", 1)):
        n = m.part("leg_" + side, "root", (sx * 0.14, 0.18, 0.02), tint=True)
        m.add(n, xform(cyl(6, 1, 0.8), (0.08, 0.18, 0.08), t=(sx * 0.14, 0.0, 0.02)), W)
        for k in (-1, 0, 1):
            m.add(n, xform(cone(4), (0.015, 0.04, 0.015), r=(90, 0, 0), t=(sx * 0.14 + k * 0.035, 0.02, 0.09)), CREAM)
    m.part("body", "root", (0, 0.18, 0), tint=True)
    m.add("body", xform(ico(1), (0.28, 0.27, 0.27), t=(0, 0.36, 0)), W)
    m.add("body", xform(ico(1), (0.18, 0.20, 0.10), t=(0, 0.34, 0.19)), CREAM)
    for i in range(3):
        m.add("body", xform(cone(4), (0.04, 0.08, 0.04), r=(-30 - i * 25, 0, 0),
                            t=(0, 0.60 - i * 0.12, -0.18 - i * 0.05)), W3)
    for side, sx in (("l", -1), ("r", 1)):
        n = m.part("arm_" + side, "body", (sx * 0.22, 0.42, 0.1), tint=True)
        m.add(n, xform(ico(1), (0.05, 0.10, 0.05), r=(20, 0, 0), t=(sx * 0.24, 0.33, 0.14)), W)
        n = m.part("wing_" + side, "body", (sx * 0.16, 0.50, -0.14), tint=True)
        b = (sx * 0.16, 0.50, -0.14)
        tip = (sx * 0.55, 0.82, -0.22)
        m.add(n, tri2(b, tip, (sx * 0.48, 0.48, -0.24)), W2)
        m.add(n, tri2(b, (sx * 0.48, 0.48, -0.24), (sx * 0.30, 0.40, -0.20)), W3)
        m.add(n, xform(cyl(4), (0.015, 0.45, 0.015), r=(0, 0, sx * -62), t=b), W3)
    m.part("tail", "body", (0, 0.22, -0.22), tint=True)
    m.add("tail", xform(cyl(6, 1, 0.55), (0.08, 0.26, 0.08), r=(-115, 0, 0), t=(0, 0.22, -0.22)), W)
    m.part("tail_tip", "tail", (0, 0.11, -0.45), tint=True)
    m.add("tail_tip", xform(cone(4), (0.08, 0.10, 0.03), r=(-90, 0, 0), t=(0, 0.11, -0.45)), W3)
    m.part("head", "body", (0, 0.58, 0.04), tint=True)
    m.add("head", xform(ico(1), (0.26, 0.23, 0.24), t=(0, 0.78, 0.02)), W)
    m.add("head", xform(ico(1), (0.15, 0.10, 0.13), t=(0, 0.70, 0.20)), W)
    for sx in (-1, 1):
        m.add("head", xform(ico(0), 0.015, t=(sx * 0.05, 0.75, 0.32)), INK)
    for side, sx in (("l", -1), ("r", 1)):
        n = m.part("horn_" + side, "head", (sx * 0.12, 0.96, -0.04))
        m.add(n, xform(cone(5), (0.04, 0.16, 0.04), r=(-30, 0, sx * -20), t=(sx * 0.12, 0.95, -0.04)), CREAM)
    eyes(m, "head", 0.84, 0.215, dx=0.11, r=0.05, sy=1.3)
    mouth(m, "head", 0.665, 0.325, 0.04)
    m.part("hat_anchor", "head", (0, 1.0, 0.02), hat_scale=0.8)
    return m

def knight():
    m = Model("knight")
    m.part("root")
    for side, sx in (("l", -1), ("r", 1)):
        n = m.part("leg_" + side, "root", (sx * 0.12, 0.22, 0))
        m.add(n, xform(cyl(6), (0.07, 0.22, 0.07), t=(sx * 0.12, 0.0, 0)), STEEL2)
        m.add(n, xform(box(), (0.08, 0.04, 0.11), t=(sx * 0.12, 0.03, 0.03)), DARK)
    m.part("body", "root", (0, 0.22, 0))
    m.add("body", xform(cyl(8, 1.0, 1.15), (0.24, 0.30, 0.20), t=(0, 0.22, 0)), STEEL)
    m.part("tabard", "body", (0, 0.40, 0.2), tint=True)
    m.add("tabard", xform(box(), (0.15, 0.17, 0.015), t=(0, 0.36, 0.215)), W)
    m.add("tabard", xform(cone(3), (0.06, 0.08, 0.01), r=(180, 0, 0), t=(0, 0.44, 0.235)), GOLD)
    m.add("body", xform(box(), (0.25, 0.03, 0.21), t=(0, 0.25, 0)), DARK)
    m.part("cape", "body", (0, 0.50, -0.16), tint=True)
    m.add("cape", tri2((-0.24, 0.52, -0.17), (0.24, 0.52, -0.17), (0.30, 0.04, -0.26)), W2)
    m.add("cape", tri2((-0.24, 0.52, -0.17), (0.30, 0.04, -0.26), (-0.30, 0.04, -0.26)), W2)
    n = m.part("arm_l", "body", (-0.28, 0.48, 0))
    m.add(n, xform(ico(1), 0.09, t=(-0.30, 0.48, 0)), STEEL)
    m.add(n, xform(cyl(6), (0.05, 0.18, 0.05), t=(-0.31, 0.26, 0.02)), STEEL2)
    # escudo (tingido, com emblema de dragao em ouro)
    m.add(n, xform(cyl(6, 1, 1), (0.16, 0.03, 0.19), r=(90, 0, 0), t=(-0.36, 0.32, 0.12)), W)
    m.add(n, xform(cone(3), (0.07, 0.10, 0.01), r=(180, 0, 0), t=(-0.36, 0.38, 0.155)), GOLD)
    n = m.part("arm_r", "body", (0.28, 0.48, 0))
    m.add(n, xform(ico(1), 0.09, t=(0.30, 0.48, 0)), STEEL)
    m.add(n, xform(cyl(6), (0.05, 0.18, 0.05), t=(0.31, 0.26, 0.02)), STEEL2)
    m.add(n, xform(box(), (0.06, 0.015, 0.03), t=(0.31, 0.27, 0.10)), GOLD)
    m.add(n, xform(box(), (0.018, 0.25, 0.008), t=(0.31, 0.53, 0.10)), (0.88, 0.92, 0.98))
    m.add(n, xform(box(), (0.018, 0.04, 0.02), t=(0.31, 0.22, 0.10)), DARK)
    m.part("head", "body", (0, 0.56, 0))
    m.add("head", xform(cyl(8, 1.0, 0.9), (0.25, 0.30, 0.24), t=(0, 0.58, 0)), STEEL)
    m.add("head", xform(ico(1), (0.225, 0.12, 0.215), t=(0, 0.88, 0)), STEEL)
    m.add("head", xform(box(), (0.17, 0.025, 0.02), t=(0, 0.76, 0.225)), INK)
    m.add("head", xform(box(), (0.02, 0.08, 0.02), t=(0, 0.68, 0.225)), INK)
    m.part("crest", "head", (0, 0.98, 0), tint=True)
    for i in range(4):
        m.add("crest", xform(cone(4), (0.04, 0.12 - i * 0.015, 0.03), r=(-25 - i * 20, 0, 0),
                             t=(0, 0.98 - i * 0.04, 0.06 - i * 0.09)), W)
    for side, sx in (("l", -1), ("r", 1)):
        n = m.part("horn_" + side, "head", (sx * 0.22, 0.82, 0))
        m.add(n, xform(cone(5), (0.035, 0.16, 0.035), r=(0, 0, sx * -55), t=(sx * 0.22, 0.82, 0)), GOLD)
        n = m.part("eye_" + side, "head", (sx * 0.07, 0.765, 0.24), tint=True, emissive=True)
        m.add(n, xform(box(), (0.035, 0.012, 0.01), t=(sx * 0.07, 0.765, 0.245)), W)
    m.part("hat_anchor", "head", (0, 1.0, 0), hat_scale=0.9)
    return m

def owl():
    m = Model("owl")
    m.part("root")
    m.part("body", "root", (0, 0.06, 0), tint=True)
    m.add("body", xform(ico(1), (0.34, 0.40, 0.31), t=(0, 0.44, 0)), W)
    m.add("body", xform(ico(1), (0.22, 0.25, 0.10), t=(0, 0.34, 0.23)), CREAM)
    for i in range(3):
        for k in (-1, 0, 1):
            if i == 2 and k != 0:
                continue
            m.add("body", xform(cone(3), (0.025, 0.03, 0.01), r=(180, 0, 0), t=(k * 0.07, 0.42 - i * 0.07, 0.33)), (0.85, 0.75, 0.6))
    for side, sx in (("l", -1), ("r", 1)):
        n = m.part("leg_" + side, "root", (sx * 0.10, 0.06, 0.12))
        for k in (-1, 0, 1):
            m.add(n, xform(cone(4), (0.018, 0.07, 0.018), r=(80, k * 20, 0), t=(sx * 0.10, 0.03, 0.12)), (1, 0.62, 0.2))
        n = m.part("wing_" + side, "body", (sx * 0.30, 0.56, 0), tint=True)
        m.add(n, xform(ico(1), (0.07, 0.24, 0.20), r=(0, 0, sx * 10), t=(sx * 0.32, 0.38, -0.01)), W2)
    m.part("head", "body", (0, 0.60, 0), tint=True)
    m.add("head", xform(ico(1), (0.31, 0.24, 0.27), t=(0, 0.80, 0)), W)
    for sx in (-1, 1):
        m.add("head", xform(ico(1), (0.12, 0.12, 0.05), t=(sx * 0.12, 0.81, 0.20)), CREAM)
    for side, sx in (("l", -1), ("r", 1)):
        n = m.part("ear_" + side, "head", (sx * 0.18, 0.98, 0), tint=True)
        m.add(n, xform(cone(4), (0.05, 0.14, 0.04), r=(-10, 0, sx * -30), t=(sx * 0.18, 0.96, 0)), W2)
        n = m.part("eye_" + side, "head", (sx * 0.12, 0.82, 0.25))
        m.add(n, xform(ico(1), (0.075, 0.075, 0.03), t=(sx * 0.12, 0.82, 0.235)), WHITE)
        m.add(n, xform(ico(1), (0.042, 0.048, 0.02), t=(sx * 0.12, 0.82, 0.26)), INK)
        m.add(n, xform(ico(0), 0.014, t=(sx * 0.12 + 0.015, 0.84, 0.28)), WHITE)
    n = m.part("mouth", "head", (0, 0.73, 0.26))
    m.add(n, xform(cone(4), (0.04, 0.09, 0.035), r=(155, 0, 0), t=(0, 0.77, 0.26)), (1, 0.7, 0.2))
    m.part("hat_anchor", "head", (0, 1.02, 0), hat_scale=0.85)
    return m

# ---------------------------------------------------------------- chapeus
def hats():
    m = Model("hats")
    m.part("root")
    m.part("nightcap", "root")
    m.add("nightcap", xform(cyl(8, 1, 1), (0.30, 0.06, 0.28), t=(0, -0.03, 0)), (0.95, 0.95, 1))
    m.add("nightcap", xform(cyl(8, 1, 0.1), (0.27, 0.36, 0.25), r=(0, 0, 25), t=(0, 0.02, 0)), (0.35, 0.45, 0.95))
    m.add("nightcap", xform(ico(1), 0.06, t=(0.17, 0.33, 0)), (0.95, 0.95, 1))
    m.part("beret", "root")
    m.add("beret", xform(ico(1), (0.32, 0.09, 0.30), r=(0, 0, -10), t=(0.02, 0.03, 0)), (0.85, 0.18, 0.25))
    m.add("beret", xform(cyl(5), (0.02, 0.05, 0.02), t=(0.02, 0.11, 0)), (0.6, 0.1, 0.15))
    m.part("headset", "root")
    for sx in (-1, 1):
        m.add("headset", xform(box(), (0.04, 0.025, 0.04), r=(0, 0, sx * -60), t=(sx * 0.27, 0.06, 0)), DARK)
        m.add("headset", xform(cyl(8), (0.10, 0.06, 0.10), r=(0, 0, 90), t=(sx * 0.30 + (0.06 if sx < 0 else 0), -0.14, 0)), DARK)
        m.add("headset", xform(cyl(8), (0.07, 0.01, 0.07), r=(0, 0, 90), t=(sx * 0.36 + (0.01 if sx < 0 else 0), -0.14, 0)), (0.2, 1, 0.5))
    m.add("headset", xform(box(), (0.20, 0.025, 0.04), t=(0, 0.13, 0)), DARK)
    m.add("headset", xform(cyl(5), (0.012, 0.18, 0.012), r=(75, 0, 0), t=(-0.33, -0.17, 0.02)), DARK)
    m.add("headset", xform(ico(0), 0.03, t=(-0.33, -0.21, 0.19)), (0.2, 1, 0.5))
    m.part("cap", "root")
    m.add("cap", xform(ico(1), (0.30, 0.16, 0.29), t=(0, 0.0, 0)), (0.20, 0.55, 1.0))
    m.add("cap", xform(cyl(8), (0.24, 0.02, 0.18), t=(0, -0.01, 0.20)), (0.12, 0.35, 0.80))
    m.add("cap", xform(ico(0), 0.03, t=(0, 0.16, 0)), WHITE)
    m.part("antenna", "root")
    m.add("antenna", xform(cyl(6), (0.10, 0.03, 0.10), t=(0, -0.02, 0)), DARK)
    m.add("antenna", xform(cyl(5), (0.012, 0.28, 0.012), r=(0, 0, 12), t=(0, 0.0, 0)), STEEL2)
    m.add("antenna", xform(ico(1), 0.05, t=(-0.06, 0.29, 0)), (0.3, 1, 0.6))
    m.part("bandana", "root")
    m.add("bandana", xform(cyl(10, 1, 1, caps=False), (0.31, 0.08, 0.29), t=(0, -0.10, 0)), (0.9, 0.15, 0.2))
    m.add("bandana", xform(cyl(10, 1, 1, caps=False), (0.30, 0.08, 0.28), t=(0, -0.10, 0)), (0.9, 0.15, 0.2))
    m.add("bandana", xform(cone(3), (0.06, 0.16, 0.02), r=(110, 0, 20), t=(0.06, -0.06, -0.30)), (0.8, 0.12, 0.18))
    m.add("bandana", xform(cone(3), (0.06, 0.14, 0.02), r=(120, 0, -20), t=(-0.04, -0.06, -0.30)), (0.8, 0.12, 0.18))
    m.part("tophat", "root")
    m.add("tophat", xform(cyl(10), (0.30, 0.025, 0.28), t=(0, 0.0, 0)), (0.12, 0.12, 0.15))
    m.add("tophat", xform(cyl(10), (0.18, 0.30, 0.17), t=(0, 0.02, 0)), (0.12, 0.12, 0.15))
    m.add("tophat", xform(cyl(10), (0.185, 0.05, 0.175), t=(0, 0.05, 0)), (0.9, 0.2, 0.3))
    m.part("crown", "root")
    m.add("crown", xform(cyl(8, 1, 1), (0.22, 0.08, 0.21), t=(0, -0.02, 0)), GOLD)
    for i in range(8):
        a = 2 * math.pi * i / 8
        m.add("crown", xform(cone(4), (0.05, 0.12, 0.03), r=(0, math.degrees(a), 0),
                             t=(math.sin(a) * 0.19, 0.06, math.cos(a) * 0.18)), GOLD)
    for i in range(4):
        a = 2 * math.pi * i / 4
        m.add("crown", xform(ico(0), 0.03, t=(math.sin(a) * 0.225, 0.02, math.cos(a) * 0.215)),
              ((1, 0.3, 0.4), (0.3, 0.6, 1), (0.3, 1, 0.5), (1, 0.3, 0.4))[i])
    return m

# ============================================================== EVOLUCOES
# Cada mascote tem 5 formas. A forma 1 e o modelo acima, sem mudanca; as
# formas 2..5 ganham pecas novas, silhueta e proporcoes diferentes e ficam
# maiores (STAGE_SCALE). Pecas com nome especial sao animadas pelo jogo:
#   orbit_N (gira em volta do pivo), spin_N (gira no lugar), pulse_N (pulsa),
#   wing_l/r, tail, cape, eye_l/r etc. (veja core/mascot3d/anim.lua)
STAGE_SCALE = [1.0, 1.07, 1.14, 1.21, 1.30]

class Ctx:
    """ajudantes de modelagem para as evolucoes"""
    def __init__(self, m):
        self.m = m
        self.n = 0

    def new(self, parent, pivot, prefix="fx", **ex):
        self.n += 1
        name = "%s_%d" % (prefix, self.n) if prefix in ("fx", "orbit", "spin", "pulse") else prefix
        if name in self.m.parts:
            name = "%s_%d" % (prefix, self.n)
        self.m.part(name, parent, pivot, **ex)
        return name

    def crystal(self, part, pos, size, r=(0, 0, 0), color=(0.5, 0.95, 1.0), sy=2.0):
        tris = xform(cone(4), (size, size * sy, size), t=(0, 0, 0)) + xform(cone(4), (size, size * sy * 0.6, size), r=(180, 0, 0))
        self.m.add(part, xform(tris, 1, r=r, t=pos), color)

    def ring(self, part, center, radius, n, size, color, shape="ico", tilt=(0, 0, 0)):
        for i in range(n):
            a = 2 * math.pi * i / n
            p = (math.sin(a) * radius, 0, math.cos(a) * radius)
            p = xform([(p, p, p)], 1, r=tilt)[0][0]
            p = (p[0] + center[0], p[1] + center[1], p[2] + center[2])
            g = ico(0) if shape == "ico" else (box() if shape == "box" else cone(4))
            self.m.add(part, xform(g, size, r=(0, math.degrees(a), 0), t=p), color)

    def crown(self, part, base, radius, n, h, color, gem=None):
        self.m.add(part, xform(cyl(max(6, n), 1, 1), (radius, h * 0.35, radius * 0.95), t=base), color)
        for i in range(n):
            a = 2 * math.pi * i / n
            p = (base[0] + math.sin(a) * radius * 0.9, base[1] + h * 0.3, base[2] + math.cos(a) * radius * 0.86)
            self.m.add(part, xform(cone(4), (h * 0.25, h, h * 0.18), r=(0, math.degrees(a), 0), t=p), color)
        if gem:
            self.m.add(part, xform(ico(0), h * 0.28, t=(base[0], base[1] + h * 0.2, base[2] + radius * 0.98)), gem)

    def wings(self, parent, root, span, height, color, style="bat", tint=False, emissive=False, color2=None):
        """par de asas wing_l / wing_r presas em root=(0,y,z)"""
        for side, sx in (("l", -1), ("r", 1)):
            name = "wing_" + side
            if name in self.m.parts:
                name = self.new(parent, (sx * 0.12 + root[0], root[1], root[2]), "fx", tint=tint, emissive=emissive)
            else:
                self.m.part(name, parent, (sx * 0.12, root[1], root[2]), tint=tint, emissive=emissive)
            b = (sx * 0.12, root[1], root[2])
            c2 = color2 or color
            if style == "bat":
                tip = (sx * (0.12 + span), root[1] + height, root[2] - 0.08)
                mid = (sx * (0.12 + span * 0.85), root[1] - height * 0.15, root[2] - 0.1)
                low = (sx * (0.12 + span * 0.45), root[1] - height * 0.35, root[2] - 0.06)
                self.m.add(name, tri2(b, tip, mid), color)
                self.m.add(name, tri2(b, mid, low), c2)
                self.m.add(name, xform(cyl(4), (0.015, span * 1.15, 0.015), r=(0, 0, sx * -60), t=b), c2)
            elif style == "feather":
                for k in range(5):
                    ang = 20 + k * 14
                    ln = span * (1.0 - k * 0.12)
                    self.m.add(name, xform(cone(4), (0.06, ln, 0.02), r=(0, 0, sx * -(90 - ang)), t=b),
                               color if k % 2 == 0 else c2)
            elif style == "crystal":
                for k in range(4):
                    ang = 25 + k * 18
                    ln = span * (1.0 - k * 0.15)
                    self.m.add(name, xform(cone(4), (0.05, ln, 0.025), r=(0, 0, sx * -(90 - ang)), t=b),
                               color if k % 2 == 0 else c2)
            elif style == "panel":
                for k in range(3):
                    self.m.add(name, xform(box(), (span * 0.32, 0.05, 0.012), r=(0, 0, sx * (25 - k * 20)),
                                           t=(sx * (0.12 + span * 0.42), root[1] + 0.12 - k * 0.12, root[2] - 0.06)),
                               color if k % 2 == 0 else c2)

    def orbiters(self, center, n, radius, size, color, shape="ico", emissive=True, y_spread=0.1):
        for i in range(n):
            name = self.new("root", center, "orbit", emissive=emissive)
            a = 2 * math.pi * i / n
            p = (center[0] + math.sin(a) * radius, center[1] + (i % 2) * y_spread, center[2] + math.cos(a) * radius)
            g = ico(1) if shape == "ico" else (box() if shape == "box" else cone(4))
            self.m.add(name, xform(g, size, r=(30, math.degrees(a), 20), t=p), color)

    def halo(self, parent, center, radius, color, n=14, size=0.025, tilt=(75, 0, 0)):
        name = self.new(parent, center, "spin", emissive=True)
        self.ring(name, center, radius, n, size, color, tilt=tilt)
        return name

    def cape(self, parent, top_y, z, w, bottom_y, color, tint=True):
        name = "cape" if "cape" not in self.m.parts else self.new(parent, (0, top_y, z), "fx", tint=tint)
        if name == "cape":
            self.m.part("cape", parent, (0, top_y, z), tint=tint)
        a, b = (-w, top_y, z), (w, top_y, z)
        c, d = (w * 1.3, bottom_y, z - 0.1), (-w * 1.3, bottom_y, z - 0.1)
        self.m.add(name, tri2(a, b, c), color)
        self.m.add(name, tri2(a, c, d), color)

    def sword(self, part, grip, length, blade=(0.88, 0.92, 0.98), r=(0, 0, 0)):
        tris = xform(box(), (0.018, length / 2, 0.008), t=(0, length / 2, 0))
        tris += xform(cone(4), (0.02, 0.06, 0.008), t=(0, length, 0))
        self.m.add(part, xform(tris, 1, r=r, t=grip), blade)
        self.m.add(part, xform(box(), (0.06, 0.015, 0.025), r=r, t=grip), GOLD)

def recolor(m, name, rgb):
    if name in m.parts:
        m.parts[name]["tris"] = [(t, rgb) for t, _ in m.parts[name]["tris"]]

def scale_model(m, k):
    for p in m.parts.values():
        p["pivot"] = tuple(c * k for c in p["pivot"])
        p["tris"] = [(tuple(tuple(c * k for c in v) for v in tri), rgb) for tri, rgb in p["tris"]]

def scale_tree(m, name, k, center=(0, 0, 0)):
    """aumenta uma peca e todas as filhas em volta de um centro (o rosto acompanha)"""
    sk = k if isinstance(k, tuple) else (k, k, k)
    names = [name]
    i = 0
    while i < len(names):
        for n, p in m.parts.items():
            if p["parent"] == names[i] and n not in names:
                names.append(n)
        i += 1
    f = lambda v: tuple(center[j] + (v[j] - center[j]) * sk[j] for j in range(3))
    for n in names:
        p = m.parts[n]
        p["pivot"] = f(p["pivot"])
        p["tris"] = [(tuple(f(v) for v in tri), rgb) for tri, rgb in p["tris"]]

def scale_part(m, name, k):
    """aumenta uma peca em volta do proprio pivo"""
    p = m.parts[name]
    pv = p["pivot"]
    sk = k if isinstance(k, tuple) else (k, k, k)
    p["tris"] = [(tuple(tuple(pv[i] + (v[i] - pv[i]) * sk[i] for i in range(3)) for v in tri), rgb) for tri, rgb in p["tris"]]

CYAN_E = (0.45, 0.95, 1.0)
GOLD_E = (1.0, 0.85, 0.35)
VIOLET_E = (0.75, 0.45, 1.0)
FLAME_E = (1.0, 0.55, 0.15)
WHITE_E = (0.92, 0.97, 1.0)
RED = (0.85, 0.15, 0.22)

def evo_slime(m, s):
    c = Ctx(m)
    if s >= 2:   # Slime Borbulhante: bolhas grandes nos lados e topo pontudo
        scale_tree(m, "body", (1.06, 1.06, 1.06))
        b = c.new("head", (0, 0.78, 0), "pulse", tint=True)
        for k, (x, y, z, r) in enumerate(((-0.34, 0.7, 0.0, 0.1), (0.36, 0.66, -0.02, 0.085), (0.1, 0.92, -0.08, 0.075))):
            m.add(b, xform(ico(1), r, t=(x, y, z)), W2)
        m.add("head", xform(cone(6), (0.07, 0.2, 0.07), r=(-20, 0, 25), t=(-0.12, 0.76, -0.04)), W)
    if s >= 3:   # Slime de Cristal: nucleo de cristal brilhando saindo do topo
        core = c.new("head", (0, 0.72, 0), "pulse", emissive=True)
        c.crystal(core, (0, 0.80, 0.0), 0.09, color=CYAN_E, sy=2.4)
        for a in (-35, 35):
            c.crystal(core, (math.sin(math.radians(a)) * 0.2, 0.70, -0.05), 0.045, r=(0, 0, -a), color=CYAN_E)
    if s >= 4:   # Rei Slime: corpo largo, coroa e capa real
        scale_tree(m, "body", (1.12, 1.0, 1.1))
        cr = c.new("head", (0, 0.84, 0), "fx")
        c.crown(cr, (0, 0.84, 0.02), 0.2, 6, 0.14, GOLD, gem=(1, 0.25, 0.35))
        c.cape("body", 0.6, -0.3, 0.26, 0.04, RED, tint=False)
        sc = c.new("arm_r", (0.46, 0.27, 0.05), "fx")
        m.add(sc, xform(cyl(5), (0.015, 0.36, 0.015), r=(0, 0, -15), t=(0.47, 0.18, 0.08)), GOLD)
        m.add(sc, xform(ico(1), 0.045, t=(0.56, 0.52, 0.08)), (1, 0.3, 0.4))
    if s >= 5:   # Slime Celestial: asas de cristal, aureola e joias em orbita
        c.wings("body", (0, 0.55, -0.32), 0.62, 0.42, CYAN_E, style="crystal", emissive=True, color2=WHITE_E)
        c.halo("head", (0, 1.06, -0.02), 0.2, GOLD_E)
        c.orbiters((0, 0.45, 0), 3, 0.62, 0.05, CYAN_E)
        recolor(m, "eye_l", (0.1, 0.25, 0.45)); recolor(m, "eye_r", (0.1, 0.25, 0.45))

def evo_robot(m, s):
    c = Ctx(m)
    if s >= 2:   # Robo Mecanico: cabeca larga, oculos de solda, chave inglesa grande
        scale_tree(m, "head", (1.18, 1.0, 1.05), center=(0, 0.64, 0))
        gg = c.new("head", (0, 0.93, 0.24), "fx")
        m.add(gg, xform(box(), (0.3, 0.035, 0.02), t=(0, 0.95, 0.25)), DARK)
        for sx in (-1, 1):
            m.add(gg, xform(cyl(8), (0.06, 0.04, 0.06), r=(90, 0, 0), t=(sx * 0.12, 0.95, 0.25)), (1, 0.75, 0.2))
        w = c.new("arm_r", (0.31, 0.3, 0), "fx")
        m.add(w, xform(box(), (0.03, 0.2, 0.02), t=(0.36, 0.22, 0.12)), STEEL)
        m.add(w, xform(cyl(6, 1, 1), (0.09, 0.03, 0.09), r=(90, 0, 0), t=(0.36, 0.02, 0.12)), STEEL)
        m.add(w, xform(box(), (0.04, 0.05, 0.03), t=(0.36, 0.0, 0.18)), DARK)
        for sx in (-1, 1):
            m.add("body", xform(ico(1), (0.1, 0.07, 0.1), t=(sx * 0.29, 0.6, 0)), STEEL2)
        a2 = c.new("head", (0.12, 1.03, 0), "fx")
        m.add(a2, xform(cyl(5), (0.012, 0.1, 0.012), r=(0, 0, -20), t=(0.12, 1.03, 0)), STEEL2)
        m.add(a2, xform(ico(1), 0.03, t=(0.16, 1.13, 0)), (0.3, 1, 0.5))
    if s >= 3:   # Robo Jato: mochila a jato com fogo e nucleo no peito
        jp = c.new("body", (0, 0.45, -0.22), "fx")
        for sx in (-1, 1):
            m.add(jp, xform(cyl(6), (0.08, 0.34, 0.08), t=(sx * 0.2, 0.28, -0.24)), STEEL)
            m.add(jp, xform(cone(6), (0.085, 0.1, 0.085), t=(sx * 0.2, 0.62, -0.24)), RED)
            m.add(jp, tri2((sx * 0.26, 0.5, -0.22), (sx * 0.52, 0.3, -0.25), (sx * 0.26, 0.3, -0.22)), RED)
        fl = c.new("body", (0, 0.28, -0.26), "pulse", emissive=True)
        for sx in (-1, 1):
            m.add(fl, xform(cone(6), (0.07, 0.3, 0.07), r=(180, 0, 0), t=(sx * 0.2, 0.28, -0.24)), FLAME_E)
        core = c.new("body", (0, 0.42, 0.21), "pulse", emissive=True)
        m.add(core, xform(ico(1), (0.05, 0.05, 0.02), t=(0, 0.52, 0.215)), CYAN_E)
    if s >= 4:   # Mecha Guardiao: blindagem pesada, crista em V e canhao
        for sx in (-1, 1):
            m.add("body", xform(box(), (0.18, 0.12, 0.18), r=(0, 0, sx * -15), t=(sx * 0.38, 0.68, 0)), W2)
            m.add("body", xform(cone(4), (0.05, 0.14, 0.05), r=(0, 0, sx * -30), t=(sx * 0.46, 0.78, 0)), GOLD)
            m.add("leg_" + ("l" if sx < 0 else "r"), xform(box(), (0.08, 0.1, 0.09), t=(sx * 0.13, 0.12, 0.02)), W2)
        v = c.new("head", (0, 1.0, 0.2), "fx")
        m.add(v, xform(cone(3), (0.06, 0.34, 0.02), r=(0, 0, 50), t=(-0.02, 0.98, 0.24)), GOLD)
        m.add(v, xform(cone(3), (0.06, 0.34, 0.02), r=(0, 0, -50), t=(0.02, 0.98, 0.24)), GOLD)
        cn = c.new("arm_l", (-0.31, 0.3, 0), "fx")
        m.add(cn, xform(cyl(6), (0.07, 0.22, 0.07), r=(90, 0, 0), t=(-0.33, 0.22, -0.05)), DARK)
        m.add(cn, xform(cyl(6), (0.045, 0.02, 0.045), r=(90, 0, 0), t=(-0.33, 0.22, 0.17)), CYAN_E)
    if s >= 5:   # Tita Nucleo: nucleo enorme, aneis em orbita e asas de energia
        big = c.new("body", (0, 0.45, 0.2), "pulse", emissive=True)
        m.add(big, xform(ico(1), (0.11, 0.11, 0.05), t=(0, 0.44, 0.23)), CYAN_E)
        c.wings("body", (0, 0.6, -0.25), 0.55, 0.3, CYAN_E, style="panel", emissive=True, color2=WHITE_E)
        c.orbiters((0, 0.55, 0), 4, 0.6, 0.04, GOLD_E, shape="box")
        c.halo("head", (0, 1.12, 0), 0.24, CYAN_E, tilt=(80, 0, 0))

def evo_cat(m, s):
    c = Ctx(m)
    if s >= 2:   # Gato Aventureiro: oculos de aviador na testa, mochila e lenco
        gg = c.new("head", (0, 0.86, 0.2), "fx")
        m.add(gg, xform(cyl(10, 1, 1, caps=False), (0.31, 0.04, 0.26), r=(-12, 0, 0), t=(0, 0.82, 0.02)), (0.45, 0.3, 0.2))
        for sx in (-1, 1):
            m.add(gg, xform(cyl(8), (0.075, 0.05, 0.075), r=(80, 0, 0), t=(sx * 0.1, 0.86, 0.25)), (0.6, 0.85, 1.0))
            m.add(gg, xform(cyl(8, 1, 1, caps=False), (0.085, 0.05, 0.085), r=(80, 0, 0), t=(sx * 0.1, 0.86, 0.245)), GOLD)
        bp = c.new("body", (0, 0.35, -0.3), "fx")
        m.add(bp, xform(box(), (0.17, 0.17, 0.09), t=(0, 0.33, -0.32)), (0.55, 0.35, 0.2))
        m.add(bp, xform(box(), (0.14, 0.05, 0.1), t=(0, 0.47, -0.32)), (0.7, 0.45, 0.25))
        sc = c.new("body", (0, 0.5, 0.04), "fx")
        m.add(sc, xform(cyl(10, 1, 1), (0.2, 0.05, 0.18), t=(0, 0.47, 0.03)), RED)
        m.add(sc, xform(cone(3), (0.06, 0.16, 0.02), r=(160, 0, 15), t=(0.08, 0.48, 0.2)), RED)
    if s >= 3:   # Gato de Duas Caudas: segunda cauda e chamas azuis nas pontas
        t2 = c.new("body", (0.04, 0.26, -0.28), "tail2", tint=True)
        m.add(t2, xform(cyl(6), (0.04, 0.24, 0.04), r=(-50, 30, 0), t=(0.04, 0.26, -0.28)), W)
        for x, y, z in ((0.0, 0.62, -0.58), (0.16, 0.58, -0.5)):
            fl = c.new("root", (x, y, z), "pulse", emissive=True)
            m.add(fl, xform(cone(5), (0.05, 0.13, 0.05), t=(x, y - 0.03, z)), (0.4, 0.75, 1.0))
        mk = c.new("head", (0, 0.86, 0.22), "fx", emissive=True)
        m.add(mk, xform(cone(3), (0.03, 0.06, 0.01), r=(180, 0, 0), t=(0, 0.88, 0.27)), (0.4, 0.75, 1.0))
    if s >= 4:   # Gato Guardiao: elmo com crista, ombreiras, peitoral e terceira cauda
        hm = c.new("head", (0, 0.85, 0), "fx")
        m.add(hm, xform(ico(1), (0.34, 0.18, 0.3), t=(0, 0.84, 0.0)), STEEL)
        for k in range(4):
            m.add(hm, xform(cone(4), (0.03, 0.14, 0.04), r=(-30 - k * 25, 0, 0), t=(0, 0.98 - k * 0.03, 0.08 - k * 0.09)), RED)
        for sx in (-1, 1):
            m.add("body", xform(ico(1), (0.13, 0.08, 0.12), t=(sx * 0.24, 0.48, 0.05)), STEEL)
        m.add("body", xform(box(), (0.16, 0.13, 0.03), t=(0, 0.3, 0.27)), STEEL)
        m.add("body", xform(ico(0), 0.04, t=(0, 0.33, 0.31)), (0.4, 0.75, 1.0))
        tr = c.new("head", (0, 0.88, 0.1), "fx")
        m.add(tr, xform(cyl(10, 1, 1, caps=False), (0.3, 0.03, 0.26), r=(-15, 0, 0), t=(0, 0.83, 0.03)), GOLD)
        t3 = c.new("body", (-0.04, 0.26, -0.28), "tail3", tint=True)
        m.add(t3, xform(cyl(6), (0.04, 0.24, 0.04), r=(-50, -30, 0), t=(-0.04, 0.26, -0.28)), W)
    if s >= 5:   # Gato Lunar Lendario: lua crescente atras da cabeca e estrelas
        moon = c.new("head", (0, 0.9, -0.2), "pulse", emissive=True)
        for k in range(9):
            a = math.radians(-120 + k * 30)
            m.add(moon, xform(ico(0), 0.05 - abs(k - 4) * 0.006, t=(math.sin(a) * 0.32, 0.88 + math.cos(a) * 0.32, -0.25)), GOLD_E)
        c.orbiters((0, 0.5, 0), 5, 0.6, 0.035, WHITE_E, shape="cone")
        recolor(m, "eye_l", (0.1, 0.35, 0.6)); recolor(m, "eye_r", (0.1, 0.35, 0.6))

def evo_ghost(m, s):
    c = Ctx(m)
    if s >= 2:   # Fantasma Brincalhao: lingua de fora e lanterna
        lt = c.new("arm_r", (0.4, 0.42, 0.04), "fx")
        m.add(lt, xform(cyl(5), (0.01, 0.12, 0.01), t=(0.46, 0.32, 0.14)), DARK)
        m.add(lt, xform(cyl(6), (0.1, 0.03, 0.1), t=(0.46, 0.3, 0.14)), DARK)
        m.add(lt, xform(cyl(6), (0.1, 0.03, 0.1), t=(0.46, 0.06, 0.14)), DARK)
        for k in range(4):
            a = k * math.pi / 2 + 0.4
            m.add(lt, xform(box(), (0.008, 0.12, 0.008), t=(0.46 + math.sin(a) * 0.09, 0.18, 0.14 + math.cos(a) * 0.09)), DARK)
        lf = c.new("arm_r", (0.46, 0.18, 0.14), "pulse", emissive=True)
        m.add(lf, xform(ico(1), 0.08, t=(0.46, 0.18, 0.14)), GOLD_E)
        hd = c.new("head", (0, 0.88, 0), "fx")
        m.add(hd, xform(cone(6), (0.22, 0.24, 0.2), r=(-15, 0, 10), t=(0.0, 0.82, -0.04)), (0.35, 0.3, 0.55))
        m.add("mouth", xform(ico(1), (0.03, 0.015, 0.02), t=(0, 0.44, 0.33)), PINK)
    if s >= 3:   # Espirito da Lanterna: crista de fogo azul, chamas em orbita e cauda longa
        fc = c.new("head", (0, 0.88, 0), "pulse", emissive=True)
        for k, x in enumerate((-0.12, 0, 0.12)):
            m.add(fc, xform(cone(5), (0.07, 0.24 + (0.08 if k == 1 else 0), 0.07), t=(x, 0.84, -0.02)), CYAN_E)
        c.orbiters((0, 0.5, 0), 3, 0.55, 0.06, CYAN_E)
        m.add("body", xform(cone(6), (0.12, 0.3, 0.1), r=(150, 0, 0), t=(0, 0.14, -0.22)), W2)
    if s >= 4:   # Espectro Real: chifres em coroa e correntes
        cr = c.new("head", (0, 0.88, 0), "fx")
        for k, x in enumerate((-0.2, -0.1, 0, 0.1, 0.2)):
            m.add(cr, xform(cone(4), (0.035, 0.14 + (0.06 if k == 2 else 0), 0.03), r=(0, 0, -x * 80), t=(x, 0.86, 0.0)), VIOLET_E if k == 2 else (0.55, 0.5, 0.7))
        ch = c.new("body", (0, 0.3, 0), "fx")
        for k in range(6):
            m.add(ch, xform(box(), (0.022, 0.012, 0.012), r=(0, 0, 30 * (k % 2)), t=(-0.28 + k * 0.05, 0.36 - k * 0.025, 0.3)), (0.55, 0.55, 0.6))
        recolor(m, "eye_l", (0.45, 0.15, 0.8)); recolor(m, "eye_r", (0.45, 0.15, 0.8))
    if s >= 5:   # Fantasma Aurora: asas etereas, aureola e brilho
        c.wings("body", (0, 0.6, -0.3), 0.6, 0.45, (0.55, 1.0, 0.85), style="feather", emissive=True, color2=(0.75, 0.6, 1.0))
        c.halo("head", (0, 1.0, -0.02), 0.22, (0.6, 1.0, 0.9))

def evo_skull(m, s):
    c = Ctx(m)
    if s >= 2:   # Ceifador Sombrio: foice e capuz maior
        sc = c.new("arm_r", (0.28, 0.3, 0.08), "fx")
        m.add(sc, xform(cyl(5), (0.025, 1.0, 0.025), r=(0, 0, 8), t=(0.34, -0.08, 0.2)), (0.45, 0.3, 0.2))
        for k in range(7):
            a = math.radians(-10 + k * 22)
            m.add(sc, xform(box(), (0.06, 0.025, 0.015), r=(0, 0, math.degrees(a)), t=(0.28 - math.sin(a) * 0.24, 0.9 + math.cos(a) * 0.08 - 0.05, 0.2)), (0.85, 0.88, 0.95))
        m.add("body", xform(cone(6), (0.26, 0.34, 0.2), r=(-40, 0, 0), t=(0, 0.9, -0.25)), SHADOW)
    if s >= 3:   # Lorde das Sombras: coroa de chifres e runas brilhando
        cr = c.new("head", (0, 0.95, 0.04), "fx")
        for k in range(5):
            a = math.radians(-60 + k * 30)
            m.add(cr, xform(cone(4), (0.05, 0.26, 0.05), r=(0, 0, -math.degrees(a) * 0.6), t=(math.sin(a) * 0.2, 0.94, 0.04)), (0.3, 0.18, 0.45))
        rn = c.new("body", (0, 0.25, 0.27), "pulse", emissive=True)
        for k in range(4):
            m.add(rn, xform(box(), (0.025, 0.04, 0.005), r=(0, 0, 45 * k), t=(-0.12 + k * 0.08, 0.2 + (k % 2) * 0.05, 0.26)), VIOLET_E)
        for sx in (-1, 1):
            m.add("body", xform(cone(4), (0.06, 0.16, 0.06), r=(0, 0, sx * -60), t=(sx * 0.27, 0.56, 0)), (0.18, 0.12, 0.26))
    if s >= 4:   # Monarca Sombrio: laminas flutuantes e capa longa
        for i in range(4):
            name = c.new("root", (0, 0.5, 0), "orbit", emissive=False)
            a = 2 * math.pi * i / 4
            c.sword(name, (math.sin(a) * 0.62, 0.32, math.cos(a) * 0.5), 0.3, blade=(0.6, 0.5, 0.85), r=(0, math.degrees(a), 0))
        c.cape("body", 0.62, -0.18, 0.28, 0.0, SHADOW2, tint=False)
    if s >= 5:   # Soberano Eterno: asas de sombra, chamas escuras e gema no peito
        c.wings("body", (0, 0.62, -0.2), 0.7, 0.55, SHADOW, style="bat", color2=SHADOW2)
        edge = c.new("body", (0, 0.62, -0.2), "pulse", emissive=True)
        for sx in (-1, 1):
            m.add(edge, xform(cyl(4), (0.012, 0.8, 0.012), r=(0, 0, sx * -60), t=(sx * 0.12, 0.62, -0.2)), VIOLET_E)
        gem = c.new("body", (0, 0.42, 0.28), "pulse", emissive=True)
        m.add(gem, xform(ico(0), 0.05, t=(0, 0.42, 0.28)), VIOLET_E)
        c.halo("head", (0, 1.1, 0.0), 0.24, VIOLET_E, n=10, size=0.035)

def evo_dragon(m, s):
    c = Ctx(m)
    if s >= 2:   # Dragao Jovem: asas e chifres maiores, mais espinhos
        scale_part(m, "wing_l", 1.3); scale_part(m, "wing_r", 1.3)
        scale_part(m, "horn_l", 1.3); scale_part(m, "horn_r", 1.3)
        for i in range(3):
            m.add("tail", xform(cone(4), (0.035, 0.07, 0.03), r=(-80, 0, 0), t=(0, 0.2 - i * 0.03, -0.28 - i * 0.07)), W3)
    if s >= 3:   # Dragao Alado: asas enormes, peito com escamas, ponta da cauda grande
        scale_part(m, "wing_l", 1.35); scale_part(m, "wing_r", 1.35)
        for k in range(3):
            m.add("body", xform(box(), (0.12 - k * 0.02, 0.03, 0.02), t=(0, 0.42 - k * 0.07, 0.29 - k * 0.01)), CREAM)
        scale_part(m, "tail_tip", 1.6)
    if s >= 4:   # Dragao Anciao: placas douradas, 4 chifres, barba de espinhos
        for sx in (-1, 1):
            h2 = c.new("head", (sx * 0.08, 0.98, -0.08), "fx")
            m.add(h2, xform(cone(5), (0.03, 0.13, 0.03), r=(-45, 0, sx * -10), t=(sx * 0.08, 0.97, -0.08)), CREAM)
            m.add("body", xform(box(), (0.1, 0.03, 0.12), r=(0, 0, sx * -25), t=(sx * 0.24, 0.58, 0)), GOLD)
        m.add("head", xform(box(), (0.09, 0.02, 0.1), t=(0, 0.9, 0.12)), GOLD)
        for k in (-1, 0, 1):
            m.add("head", xform(cone(4), (0.02, 0.07, 0.02), r=(180, 0, k * 15), t=(k * 0.05, 0.62, 0.22)), CREAM)
    if s >= 5:   # Dragao Lendario: chifres de cristal, asas com veias de energia, orbes de fogo
        recolor(m, "horn_l", CYAN_E); recolor(m, "horn_r", CYAN_E)
        m.parts["horn_l"]["extras"]["emissive"] = True; m.parts["horn_r"]["extras"]["emissive"] = True
        vein = c.new("body", (0, 0.5, -0.14), "pulse", emissive=True)
        for sx in (-1, 1):
            m.add(vein, xform(cyl(4), (0.012, 0.95, 0.012), r=(0, 0, sx * -60), t=(sx * 0.16, 0.5, -0.15)), FLAME_E)
            m.add(vein, xform(cyl(4), (0.01, 0.7, 0.01), r=(0, 0, sx * -95), t=(sx * 0.16, 0.5, -0.15)), FLAME_E)
        c.orbiters((0, 0.5, 0), 3, 0.65, 0.05, FLAME_E)

def evo_knight(m, s):
    c = Ctx(m)
    if s >= 2:   # Cavaleiro de Prata: ombreiras, escudo maior e penacho
        for sx in (-1, 1):
            m.add("arm_" + ("l" if sx < 0 else "r"), xform(ico(1), (0.13, 0.08, 0.12), t=(sx * 0.31, 0.56, 0)), STEEL)
        scale_part(m, "arm_l", 1.0)
        pl = c.new("head", (0, 1.0, -0.05), "fx", tint=True)
        for k in range(6):
            m.add(pl, xform(cone(4), (0.05, 0.32, 0.05), r=(-20 - k * 20, 0, (k - 2.5) * 6), t=(0, 0.98, 0.0)), W)
        m.parts["crest"]["tris"] = []
    if s >= 3:   # Paladino Dragao: aletas de dragao no elmo, espada brilhando
        for sx in (-1, 1):
            m.add("head", tri2((sx * 0.22, 0.9, 0), (sx * 0.55, 1.2, -0.1), (sx * 0.22, 0.66, -0.05)), GOLD)
            m.add("head", tri2((sx * 0.22, 0.8, 0), (sx * 0.45, 0.9, -0.08), (sx * 0.22, 0.66, -0.05)), (0.85, 0.6, 0.15))
        gl = c.new("arm_r", (0.31, 0.3, 0.1), "pulse", emissive=True)
        m.add(gl, xform(box(), (0.012, 0.25, 0.01), t=(0.31, 0.53, 0.105)), CYAN_E)
    if s >= 4:   # Guardiao Real: escudo-torre, capa longa e detalhes dourados
        m.add("arm_l", xform(box(), (0.2, 0.3, 0.025), t=(-0.38, 0.32, 0.13)), STEEL2)
        m.add("arm_l", xform(cone(3), (0.09, 0.13, 0.01), r=(180, 0, 0), t=(-0.38, 0.4, 0.16)), GOLD)
        c.cape("body", 0.56, -0.2, 0.26, -0.04, RED, tint=False)
        m.add("body", xform(cyl(8, 1, 1), (0.25, 0.025, 0.21), t=(0, 0.5, 0)), GOLD)
    if s >= 5:   # Cavaleiro Lendario: armadura dourada, asas de energia, aureola
        recolor(m, "head", GOLD); 
        for k in range(len(m.parts["head"]["tris"])):
            pass
        c.wings("body", (0, 0.5, -0.2), 0.65, 0.5, GOLD_E, style="feather", emissive=True, color2=WHITE_E)
        c.halo("head", (0, 1.14, 0), 0.24, GOLD_E)
        fl = c.new("arm_r", (0.31, 0.78, 0.1), "pulse", emissive=True)
        m.add(fl, xform(cone(5), (0.04, 0.16, 0.03), t=(0.31, 0.78, 0.1)), FLAME_E)

def evo_owl(m, s):
    c = Ctx(m)
    if s >= 2:   # Coruja Sabia: oculos redondos e cachecol
        gl = c.new("head", (0, 0.82, 0.27), "fx")
        for sx in (-1, 1):
            c.ring(gl, (sx * 0.12, 0.82, 0.28), 0.1, 12, 0.022, GOLD, shape="box", tilt=(90, 0, 0))
        m.add(gl, xform(box(), (0.04, 0.012, 0.012), t=(0, 0.85, 0.28)), GOLD)
        sc = c.new("body", (0, 0.62, 0), "fx")
        m.add(sc, xform(cyl(10, 1, 1), (0.3, 0.08, 0.27), t=(0, 0.58, 0)), (0.3, 0.55, 0.95))
        m.add(sc, xform(box(), (0.06, 0.16, 0.02), r=(0, 0, 10), t=(0.12, 0.45, 0.27)), (0.3, 0.55, 0.95))
    if s >= 3:   # Coruja Arcana: livro flutuante e anel de runas
        bk = c.new("root", (0, 0.35, 0.45), "pulse")
        m.add(bk, xform(box(), (0.12, 0.012, 0.09), r=(-30, 0, 0), t=(0, 0.35, 0.45)), (0.55, 0.25, 0.2))
        m.add(bk, xform(box(), (0.11, 0.008, 0.085), r=(-30, 0, 0), t=(0, 0.365, 0.45)), CREAM)
        rr = c.halo("body", (0, 0.42, 0), 0.5, VIOLET_E, n=12, size=0.022, tilt=(0, 0, 0))
    if s >= 4:   # Coruja Mestre: asas grandes abertas, manto e cajado
        scale_part(m, "wing_l", (1.6, 1.3, 1.2)); scale_part(m, "wing_r", (1.6, 1.3, 1.2))
        c.cape("body", 0.6, -0.25, 0.26, 0.05, (0.3, 0.2, 0.5), tint=False)
        st = c.new("root", (0.36, 0.0, 0.15), "fx")
        m.add(st, xform(cyl(5), (0.015, 0.95, 0.015), t=(0.36, 0.0, 0.15)), (0.45, 0.3, 0.2))
        so = c.new("root", (0.36, 0.98, 0.15), "pulse", emissive=True)
        m.add(so, xform(ico(1), 0.05, t=(0.36, 0.98, 0.15)), VIOLET_E)
    if s >= 5:   # Coruja Celestial: constelacao em volta, coroa de penas, olhos de estrela
        cr = c.new("head", (0, 1.0, 0), "fx")
        for k in range(5):
            a = math.radians(-40 + k * 20)
            m.add(cr, xform(cone(4), (0.025, 0.14, 0.015), r=(0, 0, -math.degrees(a)), t=(math.sin(a) * 0.15, 0.98, -0.05)), GOLD_E)
        c.orbiters((0, 0.6, 0), 6, 0.62, 0.03, WHITE_E, shape="cone", y_spread=0.25)
        for e in ("eye_l", "eye_r"):
            m.parts[e]["tris"] = [(t, (0.15, 0.35, 0.85) if rgb == INK else rgb) for t, rgb in m.parts[e]["tris"]]

EVOLVE = {"slime": evo_slime, "robot": evo_robot, "cat": evo_cat, "ghost": evo_ghost, "skull": evo_skull,
          "dragon": evo_dragon, "knight": evo_knight, "owl": evo_owl}
BASES = {"slime": slime, "robot": robot, "cat": cat, "ghost": ghost, "skull": skull, "dragon": dragon,
         "knight": knight, "owl": owl}

def build_stage(mid, s):
    m = BASES[mid]()
    if s > 1:
        EVOLVE[mid](m, s)
        scale_model(m, STAGE_SCALE[s - 1])
    m.id = "%s/stage-%d" % (mid, s)
    return m


# ---------------------------------------------------------- formas alternativas
# Ramo de "cuidado" (nivel 20): nasce da forma 2 com pecas e silhueta proprias.
LEAF = (0.35, 0.78, 0.35)
MUD = (0.42, 0.32, 0.22)

def alt_slime(m):   # Lamaroth: slime do pantano com cogumelos e musgo
    c = Ctx(m)
    scale_tree(m, "body", (1.18, 0.9, 1.15))
    for x, z, h in ((-0.18, -0.05, 0.12), (0.12, 0.08, 0.16)):
        mu = c.new("head", (x, 0.7, z), "fx")
        m.add(mu, xform(cyl(6), (0.025, h, 0.025), t=(x, 0.66, z)), CREAM)
        m.add(mu, xform(ico(1), (0.1, 0.05, 0.1), t=(x, 0.66 + h, z)), (0.85, 0.2, 0.2))
        for k in range(3):
            m.add(mu, xform(ico(0), 0.015, t=(x + (k - 1) * 0.04, 0.7 + h, z + 0.07)), WHITE)
    moss = c.new("body", (0, 0.4, 0), "fx")
    for k in range(6):
        a = k * 1.05
        m.add(moss, xform(ico(0), 0.06, t=(math.sin(a) * 0.42, 0.25 + (k % 2) * 0.12, math.cos(a) * 0.36)), LEAF)
    for k in range(4):
        a = 0.6 + k * 1.5
        m.add("body", xform(cone(4), (0.05, 0.12, 0.05), r=(180, 0, 0), t=(math.sin(a) * 0.38, 0.12, math.cos(a) * 0.34)), MUD)

def alt_robot(m):   # Engrenix: robo de obra com broca, esteiras e engrenagem
    c = Ctx(m)
    for side, sx in (("l", -1), ("r", 1)):
        m.parts["leg_" + side]["tris"] = []
        m.add("leg_" + side, xform(box(), (0.09, 0.08, 0.2), t=(sx * 0.15, 0.08, 0.02)), DARK)
        for k in range(4):
            m.add("leg_" + side, xform(cyl(6), (0.05, 0.02, 0.05), r=(0, 0, 90), t=(sx * 0.15 + 0.1 * sx, 0.07, -0.13 + k * 0.09)), STEEL2)
    dr = c.new("arm_r", (0.31, 0.25, 0.05), "spin")
    m.add(dr, xform(cone(6), (0.07, 0.22, 0.07), r=(90, 0, 0), t=(0.31, 0.22, 0.08)), GOLD)
    gear = c.new("body", (0, 0.5, -0.24), "spin")
    c.ring(gear, (0, 0.5, -0.24), 0.17, 10, 0.035, STEEL2, shape="box", tilt=(90, 0, 0))
    m.add(gear, xform(cyl(10), (0.13, 0.04, 0.13), r=(90, 0, 0), t=(0, 0.5, -0.26)), STEEL)
    for k in range(3):
        m.add("body", xform(box(), (0.06, 0.02, 0.005), r=(0, 0, 40), t=(-0.15 + k * 0.15, 0.27, 0.205)), (1, 0.85, 0.1))
    hh = c.new("head", (0, 1.0, 0), "fx")
    m.add(hh, xform(ico(1), (0.24, 0.1, 0.2), t=(0, 1.02, 0)), (1, 0.82, 0.1))

def alt_cat(m):     # Folhagato: gato da floresta com coroa de flores e cauda de cipo
    c = Ctx(m)
    fl = c.new("head", (0, 0.92, 0.03), "fx")
    for k in range(7):
        a = math.radians(-70 + k * 23)
        p = (math.sin(a) * 0.24, 0.9 + math.cos(a) * 0.04, 0.03 + math.cos(a) * 0.12)
        m.add(fl, xform(ico(0), 0.04, t=p), ((1, 0.55, 0.75), (1, 0.9, 0.3), (1, 1, 1))[k % 3])
    for side, sx in (("l", -1), ("r", 1)):
        lf = c.new("ear_" + side, (sx * 0.17, 0.98, 0.02), "fx")
        m.add(lf, xform(cone(3), (0.08, 0.16, 0.02), r=(0, 0, sx * -30), t=(sx * 0.22, 0.98, 0.0)), LEAF)
    for k in range(5):
        m.add("tail_tip", xform(cone(3), (0.05, 0.1, 0.012), r=(0, 0, 40 * (k - 2)), t=(0, 0.48 + k * 0.03, -0.55 - k * 0.02)), LEAF)
    m.add("body", xform(ico(1), (0.16, 0.14, 0.1), t=(0, 0.24, 0.24)), LEAF)

def alt_ghost(m):   # Travessombra: fantasma bufao com chapeu de tres pontas e mascara
    c = Ctx(m)
    hat = c.new("head", (0, 0.86, 0), "fx")
    for k, (rz, col) in enumerate(((50, (0.85, 0.2, 0.4)), (0, (0.35, 0.2, 0.75)), (-50, (0.85, 0.2, 0.4)))):
        m.add(hat, xform(cone(5), (0.08, 0.26, 0.07), r=(0, 0, rz), t=(-0.12 + k * 0.12, 0.84, 0)), col)
        tip = xform([((0, 0.26, 0),) * 3], 1, r=(0, 0, rz))[0][0]
        m.add(hat, xform(ico(1), 0.04, t=(-0.12 + k * 0.12 + tip[0], 0.84 + tip[1], 0)), GOLD)
    mask = c.new("head", (0, 0.62, 0.32), "fx")
    m.add(mask, xform(ico(1), (0.25, 0.18, 0.05), t=(0, 0.62, 0.3)), WHITE)
    for sx in (-1, 1):
        m.add(mask, xform(ico(0), (0.05, 0.035, 0.02), t=(sx * 0.1, 0.66, 0.35)), INK)
    m.add(mask, xform(box(), (0.1, 0.012, 0.01), t=(0, 0.55, 0.35)), INK)
    for k in range(5):
        m.add("body", xform(box(), (0.03, 0.015, 0.36), t=(0, 0.28 + k * 0.001, 0), r=(0, k * 36, 0)), (0.85, 0.2, 0.4) if k % 2 else (0.35, 0.2, 0.75))

def alt_skull(m):   # Necrolume: caveira lanterneira com costelas e chama verde
    c = Ctx(m)
    GRN = (0.4, 1.0, 0.55)
    rib = c.new("body", (0, 0.35, 0.22), "fx")
    for k in range(4):
        m.add(rib, xform(cyl(8, 1, 1, caps=False), (0.15 - k * 0.015, 0.012, 0.05), t=(0, 0.46 - k * 0.06, 0.22)), BONE)
    m.add(rib, xform(box(), (0.012, 0.13, 0.01), t=(0, 0.38, 0.27)), BONE)
    lt = c.new("arm_l", (-0.28, 0.25, 0.1), "fx")
    m.add(lt, xform(ico(1), (0.07, 0.06, 0.06), t=(-0.3, 0.05, 0.12)), BONE)
    for sx in (-1, 1):
        m.add(lt, xform(box(), (0.004, 0.06, 0.004), t=(-0.3 + sx * 0.05, 0.12, 0.12)), (0.4, 0.4, 0.45))
    fl = c.new("arm_l", (-0.3, 0.1, 0.12), "pulse", emissive=True)
    m.add(fl, xform(cone(5), (0.035, 0.1, 0.035), t=(-0.3, 0.06, 0.12)), GRN)
    c.orbiters((0, 0.45, 0), 3, 0.5, 0.035, GRN)
    recolor(m, "eye_l", GRN); recolor(m, "eye_r", GRN)
    m.parts["eye_l"]["extras"]["tint"] = False; m.parts["eye_r"]["extras"]["tint"] = False

def alt_dragon(m):  # Maridrago: dragao do mar com barbatanas, crista e bolhas
    c = Ctx(m)
    for side in ("l", "r"):
        sx = -1 if side == "l" else 1
        m.parts["wing_" + side]["tris"] = []
        b = (sx * 0.2, 0.42, -0.05)
        for k in range(3):
            m.add("wing_" + side, tri2(b, (sx * (0.45 - k * 0.05), 0.55 - k * 0.12, -0.1 - k * 0.04), (sx * 0.38, 0.35 - k * 0.08, -0.06)), W2)
    cr = c.new("head", (0, 0.95, -0.05), "fx", tint=True)
    for k in range(5):
        m.add(cr, tri2((0, 0.98 - k * 0.07, -0.02 - k * 0.07), (0, 1.1 - k * 0.07, -0.08 - k * 0.07), (0, 0.95 - k * 0.07, -0.12 - k * 0.07)), W3)
    for sx in (-1, 1):
        m.add("head", tri2((sx * 0.22, 0.82, 0), (sx * 0.36, 0.9, -0.08), (sx * 0.3, 0.72, -0.04)), W3)
    scale_part(m, "tail_tip", (2.0, 1.4, 1.2))
    c.orbiters((0, 0.45, 0), 4, 0.55, 0.035, (0.6, 0.9, 1.0), y_spread=0.25)

def alt_knight(m):  # Flechart: cavaleiro arqueiro com capuz, arco e aljava
    c = Ctx(m)
    m.parts["crest"]["tris"] = []
    hood = c.new("head", (0, 0.9, -0.02), "fx")
    m.add(hood, xform(ico(1), (0.28, 0.2, 0.27), t=(0, 0.86, -0.04)), (0.25, 0.55, 0.3))
    m.add(hood, xform(cone(5), (0.12, 0.16, 0.1), r=(-60, 0, 0), t=(0, 0.92, -0.2)), (0.25, 0.55, 0.3))
    m.parts["arm_r"]["tris"] = [t for t in m.parts["arm_r"]["tris"] if t[1] not in ((0.88, 0.92, 0.98), GOLD)]
    bow = c.new("arm_l", (-0.33, 0.3, 0.1), "fx")
    m.parts["arm_l"]["tris"] = [t for t in m.parts["arm_l"]["tris"] if t[1] not in (W, GOLD)]
    for k in range(7):
        a = math.radians(-60 + k * 20)
        m.add(bow, xform(box(), (0.012, 0.045, 0.012), r=(0, 0, math.degrees(a) * 0.5), t=(-0.42 + math.cos(a) * 0.06, 0.3 + math.sin(a) * 0.25, 0.1)), (0.55, 0.35, 0.2))
    m.add(bow, xform(box(), (0.002, 0.25, 0.002), t=(-0.39, 0.3, 0.1)), WHITE)
    q = c.new("body", (0.1, 0.5, -0.2), "fx")
    m.add(q, xform(cyl(6), (0.05, 0.3, 0.05), r=(0, 0, -25), t=(0.06, 0.32, -0.22)), (0.5, 0.3, 0.18))
    for k in range(3):
        m.add(q, xform(cone(3), (0.02, 0.06, 0.005), r=(0, 0, -25), t=(0.16 + k * 0.02, 0.6 + k * 0.01, -0.22)), (1, 0.4, 0.4))
    c.cape("body", 0.52, -0.18, 0.24, 0.05, (0.25, 0.55, 0.3), tint=False)

def alt_owl(m):     # Tempestuja: coruja da tempestade com nuvem e raios
    c = Ctx(m)
    cl = c.new("root", (0, 1.15, 0), "pulse")
    for k in range(5):
        m.add(cl, xform(ico(1), 0.1 + (k % 2) * 0.03, t=(-0.24 + k * 0.12, 1.18 + (k % 2) * 0.04, -0.05)), (0.55, 0.58, 0.68))
    for sx in (-1, 1):
        bolt = c.new("root", (sx * 0.45, 0.7, 0), "pulse", emissive=True)
        pts = [(0, 0), (0.06, -0.12), (-0.02, -0.14), (0.05, -0.3)]
        for i in range(3):
            a = (sx * 0.45 + pts[i][0], 0.95 + pts[i][1], 0.05)
            b = (sx * 0.45 + pts[i + 1][0], 0.95 + pts[i + 1][1], 0.05)
            mx, my = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
            ln = math.hypot(b[0] - a[0], b[1] - a[1])
            ang = math.degrees(math.atan2(b[0] - a[0], a[1] - b[1]))
            m.add(bolt, xform(box(), (0.015, ln / 2, 0.01), r=(0, 0, ang), t=(mx, my, 0.05)), (1, 0.95, 0.35))
    for side in ("l", "r"):
        sx = -1 if side == "l" else 1
        for k in range(4):
            m.add("wing_" + side, xform(cone(3), (0.04, 0.16, 0.01), r=(0, 0, sx * (-120 + k * 15)), t=(sx * 0.38, 0.32 + k * 0.06, 0)), W3)
    for side in ("l", "r"):
        scale_part(m, "ear_" + side, (1.3, 1.8, 1.2))

ALT = {"slime": alt_slime, "robot": alt_robot, "cat": alt_cat, "ghost": alt_ghost, "skull": alt_skull,
       "dragon": alt_dragon, "knight": alt_knight, "owl": alt_owl}

def build_alt(mid):
    m = BASES[mid]()
    EVOLVE[mid](m, 2)
    ALT[mid](m)
    scale_model(m, STAGE_SCALE[2])
    m.id = "%s/alt" % mid
    return m

if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__))
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, "..", "assets", "mascots")
    os.makedirs(out, exist_ok=True)
    total = 0
    for mid in BASES:
        os.makedirs(os.path.join(out, mid), exist_ok=True)
        for st in range(1, 6):
            m = build_stage(mid, st)
            size = write_glb(m, os.path.join(out, mid, "stage-%d.glb" % st))
            total += size
            print("%-14s %4d triangulos  %6d bytes  %d pecas" % (m.id, m.tri_count(), size, len(m.order)))
        m = build_alt(mid)
        total += write_glb(m, os.path.join(out, mid, "alt.glb"))
        print("%-14s %4d triangulos" % (m.id, m.tri_count()))
    h = hats()
    total += write_glb(h, os.path.join(out, "hats.glb"))
    print("total: %d bytes" % total)
