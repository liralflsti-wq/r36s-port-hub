# Criaturas digitais e o aparelho BITPOCKET (0.5.5)

O mascote é um bichinho virtual em pixel art que vive no aparelho **BITPOCKET**, um portátil de design original.
Ele é liberado pela carta final da Temporada 1 (Lenda). Cada linha de criatura é liberada pela sua carta.

## Arquitetura

| Parte | Arquivo | Papel |
|---|---|---|
| Dados das criaturas | `assets/digipets/creatures.json` (gerado por `tools/digipet_content.py`) | 8 linhas × 6 formas: nome, elemento, raridade, habilidade, descrição, história, atributos e árvore |
| Sprites | `assets/digipets/sprites/<forma>.png/.json`, `assets/digipets/hats/` | Folhas 80×80 com 10 animações |
| Enciclopédia de dados | `core/digipet/dex.lua` | Lê e indexa o JSON |
| Cuidados | `core/digipet/care.lua` | Energia, felicidade, saúde, atributos, contadores e ações |
| Evolução | `core/mascot3d/evolution.lua` + `assets/mascots/evolution.json` | XP e nível por linha, árvore ramificada, requisitos, histórico, validação |
| Gerenciador | `core/mascot.lua` | Estado (`mascot.json`), humor, eventos, configurações |
| Falas | `core/mascot3d/dialog.lua`, `core/mascot3d/brain.lua` | Personalidade, comentários com dados reais, avisos de evolução e de cuidado |
| Sprites na tela | `ui/digipet/sprite.lua` | Cache de 3 formas, quadros, clarão branco e silhueta |
| Aparelho | `ui/digipet/device.lua` | Carcaça, LCD, medidores, ícones de pixel, 5 modelos |
| Telas | `ui/screens/digipet.lua` (aparelho), `digigame.lua` (minigames), `digievo.lua` (painel de evolução), `digidex.lua` (enciclopédia), `mascot.lua` (Personalizar) | |
| Canto da tela | `ui/mascot_view.lua` | Criatura em pixel art (o desenho 2D antigo fica como reserva) |

## Árvore de cada linha

```
Inicial (nv 1) -> Intermediária (nv 10) -> Avançada (nv 20, treinos 15)        -> Suprema (nv 35, saúde 60,
                                       -> Alternativa (nv 20, felicidade 70,       atributo principal 15)
                                          60 cuidados)                           -> Secreta (nv 50, felicidade 90,
                                       -> (nv 25 sem nenhum ramo: Avançada)         soma dos atributos 100 +
                                                                                   requisito especial da linha)
```

Requisitos especiais das formas secretas:

| Linha | Requisito especial |
|---|---|
| Slime | 150 refeições |
| Robô | 40 minigames vencidos |
| Gato | 200 carinhos |
| Fantasma | evoluir de madrugada |
| Caveira | álbum completo |
| Dragão | 150 treinos |
| Cavaleiro | 3 linhas na forma Suprema |
| Coruja | 40 telas do hub descobertas |

Raridade (comum, incomum, épica, lendária, única) é separada do estágio. As formas alternativas costumam ser
mais raras que as principais, e as secretas são sempre únicas.

## Cuidados, sem morte e sem perder nível

- **Energia:** cai 1 a cada 30 minutos, até no mínimo 10.
- **Felicidade:** cai 1 a cada 25 minutos, até no mínimo 10.
- **Saúde:** só cai quando a energia ou a felicidade estão baixas, até no mínimo 30. Sobe quando as duas estão boas.

| Ação | Efeito |
|---|---|
| Alimentar | energia +25, saúde +3 |
| Brincar | felicidade +15, energia −8 |
| Treinar | +1 no atributo, energia −12 |
| Descansar | +1 de energia por minuto (também com o hub fechado) |
| Carinho | felicidade +5 |
| Minigame Reflexo | vitória: Força +2 |
| Minigame Memória | vitória: Sabedoria +2 |

Cada ação dá XP com limite diário (`evolution.json`). Deixar o hub aberto não dá XP.

## Modelos de aparelho

| Modelo | Como liberar |
|---|---|
| Clássico | já vem com o aparelho |
| Neon | carta do teste de controles |
| Cristal | uma criatura na forma Avançada |
| Sombra | uma forma Secreta descoberta |
| Dourado | três criaturas na forma Suprema |

A opção "Cor" de Personalizar pinta a carcaça.

## Gerar os sprites (no PC)

Os modelos 3D low-poly ficam em `tools/mascot_src/models`, fora do pacote do console. Para gerar tudo:

```
python3 src/tools/make_mascots_glb.py tools/mascot_src/models   # modelos (formas 1-5 + alternativa)
python3 tools/digipet_content.py                                # creatures.json
tools/bake_sprites.sh                                           # sprites (BAKE_ONLY=id1,id2 para alguns)
python3 tools/digipet_i18n.py                                   # traduções
```

O gerador fotografa cada forma com câmera ortográfica, quadro a quadro. Depois aplica uma paleta original
de 32 cores e um contorno de 1 pixel, e aumenta olhos e boca para o rosto ler bem em poucos pixels.

## Adicionar uma criatura

1. Crie o modelo no gerador e o adicione em `BASES`, `EVOLVE` e `ALT`.
2. Coloque a linha em `tools/digipet_content.py`.
3. Rode `bake_sprites.sh` e `digipet_i18n.py` (com os textos novos).
4. Adicione a espécie no `assets/mascots/registry.json` (personalidade e falas).

## Testes

- **Autotest `evotest`** (`dev/test_evolution.lua`, 33 verificações): XP, níveis, limites, ramos, requisitos,
  cuidados, salvamento, migração, dados corrompidos e sprites das 48 formas.
- **Pacote de teste do administrador** (`tools/build.sh --admin`): no aparelho, L1 dá +1 nível e R1 cumpre os
  requisitos. A versão normal não traz isso.
