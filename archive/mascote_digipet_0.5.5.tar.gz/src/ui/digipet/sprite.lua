-- =============================================================================
--  Sprites pixel art das criaturas (assets/digipets/sprites/<forma>.png/.json)
--  Folha: quadros de 80x80, uma linha por animacao (idle, walk, happy, sad,
--  sleep, eat, attack, hurt, evolution, victory). O .json diz quantos quadros,
--  a velocidade, se repete e onde fica a cabeca (para o acessorio).
--  Carregamento sob demanda com cache pequeno (3 formas): a forma que sai do
--  cache e liberada. Desenho sempre com filtro "nearest" (pixel nitido).
--    SP.draw(form_id, anim, t, cx, feet_y, scale, o)
--      o = { flip, white (0..1 clarao), black (silhueta), alpha, hat }
--    SP.frame_count(form_id, anim) / SP.duration(form_id, anim)
-- =============================================================================
local lg = love.graphics
local json = require("lib.json")

local SP = {}
SP.DIR = "assets/digipets/sprites/"
SP.SIZE = 80
SP.FOOT_Y = 74        -- linha dos pes dentro do quadro (sai do gerador)
SP.CACHE = 3

local cache, order = {}, {}
local hats = {}
local shader

local CODE = [[
uniform float u_white;
uniform float u_black;
vec4 effect(vec4 col, Image tex, vec2 uv, vec2 sc) {
  vec4 p = Texel(tex, uv);
  vec3 c = mix(p.rgb, vec3(1.0), u_white);
  c = mix(c, vec3(0.04, 0.03, 0.08), u_black);
  return vec4(c, p.a) * col;
}
]]

local function get_shader()
  if shader == nil then
    local ok, sh = pcall(lg.newShader, CODE)
    shader = ok and sh or false
  end
  return shader or nil
end

local function touch(id)
  for i, x in ipairs(order) do if x == id then table.remove(order, i); break end end
  table.insert(order, 1, id)
  while #order > SP.CACHE do
    local old = table.remove(order)
    local e = cache[old]
    if e and e.img then pcall(e.img.release, e.img) end
    cache[old] = nil
  end
end

--- carrega a folha de uma forma (ou devolve nil se faltar)
function SP.get(id)
  local e = cache[id]
  if e == nil then
    e = false
    local okm, txt = pcall(love.filesystem.read, SP.DIR .. id .. ".json")
    local oki, img = pcall(lg.newImage, SP.DIR .. id .. ".png")
    if okm and txt and oki and img then
      local okj, meta = pcall(json.decode, txt)
      if okj and type(meta) == "table" and meta.anims then
        img:setFilter("nearest", "nearest")
        e = { img = img, meta = meta, quads = {} }
      end
    end
    cache[id] = e
  end
  if e then touch(id) end
  return e or nil
end

function SP.exists(id) return SP.get(id) ~= nil end

local function anim_info(e, anim)
  return e.meta.anims[anim] or e.meta.anims.idle
end

function SP.frame_count(id, anim)
  local e = SP.get(id)
  return e and anim_info(e, anim).frames or 1
end

function SP.duration(id, anim)
  local e = SP.get(id)
  if not e then return 1 end
  local a = anim_info(e, anim)
  return a.frames / (a.fps or 8)
end

--- indice do quadro (1..n) no tempo t
function SP.frame(e, anim, t)
  local a = anim_info(e, anim)
  local i = math.floor((t or 0) * (a.fps or 8))
  if a.loop then i = i % a.frames else i = math.min(a.frames - 1, i) end
  return i + 1, a
end

local function quad(e, row, col)
  local k = row * 16 + col
  local q = e.quads[k]
  if not q then
    local S = e.meta.size or SP.SIZE
    q = lg.newQuad(col * S, row * S, S, S, e.img:getDimensions())
    e.quads[k] = q
  end
  return q
end

local function hat_img(id)
  if hats[id] == nil then
    local ok, img = pcall(lg.newImage, "assets/digipets/hats/" .. id .. ".png")
    hats[id] = ok and img or false
    if hats[id] then hats[id]:setFilter("nearest", "nearest") end
  end
  return hats[id] or nil
end

--- desenha a criatura com os pes em (cx, feet_y); devolve false se nao ha sprite
function SP.draw(id, anim, t, cx, feet_y, scale, o)
  o = o or {}
  local e = SP.get(id)
  if not e then return false end
  scale = scale or 1
  local S = e.meta.size or SP.SIZE
  local fi, a = SP.frame(e, anim, t)
  local sx = o.flip and -scale or scale
  local x = math.floor(cx - (o.flip and -1 or 1) * (S / 2) * scale + 0.5)
  local y = math.floor(feet_y - SP.FOOT_Y * scale + 0.5)
  local sh = (o.white or o.black) and get_shader()
  if sh then
    lg.setShader(sh)
    sh:send("u_white", o.white or 0)
    sh:send("u_black", o.black or 0)
  end
  lg.setColor(1, 1, 1, o.alpha or 1)
  lg.draw(e.img, quad(e, a.row, fi - 1), x, y, 0, sx, scale)
  -- acessorio na cabeca (sprite pixel art do chapeu)
  if o.hat and o.hat ~= "none" then
    local hi = hat_img(o.hat)
    local hp = e.meta.hat and e.meta.hat[anim] and e.meta.hat[anim][fi] or (e.meta.hat and e.meta.hat.idle and e.meta.hat.idle[1])
    if hi and hp then
      -- o chapeu foi gerado em 40x40 com a base em (20, 24)
      local ax = x + (o.flip and -1 or 1) * hp[1] * scale
      lg.draw(hi, math.floor(ax - 20 * scale + 0.5), math.floor(y + hp[2] * scale - 24 * scale + 0.5), 0, scale, scale)
    end
  end
  if sh then lg.setShader() end
  return true
end

--- altura aproximada (px) da criatura na escala dada (para efeitos em volta)
function SP.height(id, scale)
  local f = require("core.digipet.dex").form(id)
  local tier = f and f.tier or 1
  return (30 + (tier - 1) * 6) * (scale or 1)
end

function SP.clear()
  for id, e in pairs(cache) do if e and e.img then pcall(e.img.release, e.img) end end
  cache, order = {}, {}
end

return SP
