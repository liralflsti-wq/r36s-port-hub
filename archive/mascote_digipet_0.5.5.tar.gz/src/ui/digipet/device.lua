-- =============================================================================
--  BITPOCKET: o aparelho virtual da criatura (design original)
--  Carcaca arredondada, tela LCD colorida com linhas de varredura, medidores
--  em blocos de pixel, botoes e alto-falante. 5 modelos desbloqueaveis.
--    DV.SKINS / DV.unlocked(skin) / DV.current()
--    DV.draw(x, y, w, h, o)   -> retangulo da tela LCD (lx, ly, lw, lh)
--    DV.meter(x, y, n, v, c)  medidor de blocos (v 0..100)
--    DV.lcd_text(...)         texto na fonte de pixel com cor do LCD
-- =============================================================================
local L = require("lib.i18n").L
local I18N = require("lib.i18n")
local T = require("ui.theme")
local G = require("ui.gfx")
local lg = love.graphics

local DV = {}

local function rgb(h) return { tonumber(h:sub(1, 2), 16) / 255, tonumber(h:sub(3, 4), 16) / 255, tonumber(h:sub(5, 6), 16) / 255 } end

-- cada modelo: carcaca, borda, tela, tinta da tela, condicao para liberar
DV.SKINS = {
  { id = "classic", name = L("Clássico"), shell = rgb("e8e2d0"), edge = rgb("8c8470"), lcd = rgb("b9d4a2"),
    lcd2 = rgb("a3c28c"), ink = rgb("1f2e1a"), accent = rgb("e83a3a"),
    need = L("Já vem com o aparelho.") },
  { id = "neon", name = L("Neon"), shell = rgb("1b1f3a"), edge = rgb("6ec6ff"), lcd = rgb("0e1630"),
    lcd2 = rgb("15214a"), ink = rgb("73eff7"), accent = rgb("ff7ab8"),
    need = L("Libere a carta do teste de controles."), card = "padtest" },
  { id = "crystal", name = L("Cristal"), shell = rgb("b8f1ff"), edge = rgb("3f8fe6"), lcd = rgb("e6fbff"),
    lcd2 = rgb("cdeff8"), ink = rgb("1d3f5c"), accent = rgb("9d6bff"),
    need = L("Leve uma criatura até a forma Avançada."), tier = 3 },
  { id = "shadow", name = L("Sombra"), shell = rgb("2b1d3a"), edge = rgb("9d6bff"), lcd = rgb("1a1226"),
    lcd2 = rgb("241838"), ink = rgb("c9b0ff"), accent = rgb("9d6bff"),
    need = L("Descubra uma forma Secreta."), tier = 5 },
  { id = "gold", name = L("Dourado"), shell = rgb("ffd26b"), edge = rgb("b8743c"), lcd = rgb("fff4c2"),
    lcd2 = rgb("f5e2a0"), ink = rgb("4a2c1e"), accent = rgb("e83a3a"),
    need = L("Leve três criaturas até a forma Suprema."), lines4 = 3 },
}
DV.BY_ID = {}
for _, s in ipairs(DV.SKINS) do DV.BY_ID[s.id] = s end

local function max_tier_count(t)
  local okE, Evo = pcall(require, "core.mascot3d.evolution")
  if not okE then return 0, 0 end
  local best, n = 0, 0
  for _, r in pairs(Evo.data().mascots) do
    local okD, Dex = pcall(require, "core.digipet.dex")
    local f = okD and r.form and Dex.form(r.form)
    if f then
      best = math.max(best, f.tier)
      if f.tier >= (t or 4) then n = n + 1 end
    end
    for _, fid in ipairs(r.discovered or {}) do
      local ff = okD and Dex.form(fid)
      if ff then best = math.max(best, ff.tier) end
    end
  end
  return best, n
end

function DV.unlocked(s)
  if type(s) == "string" then s = DV.BY_ID[s] end
  if not s then return false end
  if s.card then
    local okA, A = pcall(require, "core.achievements")
    return okA and A.unlocked(s.card) ~= nil
  end
  if s.tier then return (max_tier_count()) >= s.tier end
  if s.lines4 then return select(2, max_tier_count(4)) >= s.lines4 end
  return true
end

function DV.current()
  local M = require("core.mascot")
  local s = DV.BY_ID[M.get("device") or "classic"]
  if not s or not DV.unlocked(s) then s = DV.SKINS[1] end
  return s
end

--- medidor em blocos de pixel (n blocos, v 0..100)
function DV.meter(x, y, n, v, c, ink)
  local full = math.floor((v or 0) / 100 * n + 0.5)
  for i = 0, n - 1 do
    local on = i < full
    lg.setColor((on and c or ink)[1], (on and c or ink)[2], (on and c or ink)[3], on and 1 or 0.25)
    lg.rectangle("fill", x + i * 7, y, 5, 8)
  end
end

--- icones de pixel 7x7 (coracao, raio, cruz, estrela)
local ICONS = {
  heart = { "0110110", "1111111", "1111111", "0111110", "0011100", "0001000", "0000000" },
  bolt = { "0001100", "0011000", "0111110", "0001100", "0011000", "0110000", "0000000" },
  cross = { "0011100", "0011100", "1111111", "1111111", "0011100", "0011100", "0000000" },
  star = { "0001000", "0011100", "1111111", "0111110", "0110110", "1000001", "0000000" },
  food = { "0011100", "0111110", "1111111", "1111111", "0111110", "0001000", "0001000" },
  note = { "0001111", "0001001", "0001001", "0001001", "0111001", "1111111", "0110110" },
  z = { "1111100", "0001000", "0010000", "0100000", "1111100", "0000000", "0000000" },
}
function DV.icon(name, x, y, c, k)
  local m = ICONS[name]
  if not m then return end
  k = k or 1
  lg.setColor(c[1], c[2], c[3], c[4] or 1)
  for r, row in ipairs(m) do
    for col = 1, #row do
      if row:sub(col, col) == "1" then lg.rectangle("fill", x + (col - 1) * k, y + (r - 1) * k, k, k) end
    end
  end
end

--- desenha o aparelho; devolve o retangulo da tela LCD
--  o = { skin, color (cor da carcaca), press (botao 1..3 aceso), t }
function DV.draw(x, y, w, h, o)
  o = o or {}
  local s = o.skin or DV.current()
  local shell = o.color or s.shell
  local t = o.t or 0
  -- sombra + carcaca + borda
  lg.setColor(0, 0, 0, 0.35)
  lg.rectangle("fill", x + 4, y + 6, w, h, 34, 34)
  lg.setColor(s.edge[1], s.edge[2], s.edge[3], 1)
  lg.rectangle("fill", x, y, w, h, 34, 34)
  lg.setColor(shell[1], shell[2], shell[3], 1)
  lg.rectangle("fill", x + 4, y + 4, w - 8, h - 8, 30, 30)
  -- brilho na carcaca
  lg.setColor(1, 1, 1, 0.18)
  lg.rectangle("fill", x + 14, y + 10, w - 28, 10, 5, 5)
  -- nome do aparelho
  G.text(T.f.pix8, "BITPOCKET", x, y + 14, s.edge, "center", w)
  -- moldura da tela
  local lx, ly, lw, lh = x + 22, y + 32, w - 44, math.floor(h * 0.56)
  lg.setColor(0.08, 0.08, 0.1, 1)
  lg.rectangle("fill", lx - 8, ly - 8, lw + 16, lh + 16, 10, 10)
  lg.setColor(s.lcd[1], s.lcd[2], s.lcd[3], 1)
  lg.rectangle("fill", lx, ly, lw, lh)
  -- grade de pixels e linhas de varredura (cara de LCD)
  lg.setColor(s.lcd2[1], s.lcd2[2], s.lcd2[3], 0.55)
  for gy = ly, ly + lh - 1, 3 do lg.rectangle("fill", lx, gy, lw, 1) end
  -- LED de energia
  local blink = (math.floor(t * 2) % 2 == 0)
  lg.setColor(s.accent[1], s.accent[2], s.accent[3], blink and 1 or 0.45)
  lg.circle("fill", x + 16, y + 20, 3)
  -- botoes (A, B, C) e alto-falante
  local by = ly + lh + 30
  local bx = { x + w * 0.28, x + w * 0.5, x + w * 0.72 }
  for i, cx in ipairs(bx) do
    local on = o.press == i
    lg.setColor(0, 0, 0, 0.3)
    lg.circle("fill", cx + 2, by + (on and 1 or 3), 14)
    lg.setColor(s.accent[1] * (on and 1.2 or 1), s.accent[2] * (on and 1.2 or 1), s.accent[3] * (on and 1.2 or 1), 1)
    lg.circle("fill", cx, by + (on and 2 or 0), 13)
    lg.setColor(1, 1, 1, 0.35)
    lg.circle("fill", cx - 4, by - 4 + (on and 2 or 0), 4)
    G.text(T.f.pix8, ({ "A", "B", "C" })[i], cx - 20, by + 18, s.edge, "center", 40)
  end
  for k = 0, 3 do
    lg.setColor(s.edge[1], s.edge[2], s.edge[3], 0.6)
    lg.rectangle("fill", x + w * 0.5 - 24, by + 46 + k * 6, 48, 2, 1, 1)
  end
  return lx, ly, lw, lh
end

return DV
