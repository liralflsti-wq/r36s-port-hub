-- =============================================================================
--  Meu perfil > Mascote: ver, cuidar e personalizar o mascote
--  Bloqueado ate a conquista final da temporada (silhueta + enigma).
--  Liberado: o mascote grande no palco; a direita, as categorias (mascote,
--  cor, acessorio, aura, efeito). Cada item mostra a carta que o libera.
--    cima/baixo: categoria | esquerda/direita: item | A: carinho
--    X: renomear | Y: curiosidade | SELECT: dancar | R1: onde aparece
--    B: voltar
-- =============================================================================
local L = require("lib.i18n").L
local I18N = require("lib.i18n")
local T = require("ui.theme")
local G = require("ui.gfx")
local Icons = require("ui.icons")
local M = require("core.mascot")
local MV = require("ui.mascot_view")
local A = require("core.achievements")
local lg = love.graphics

local S = {}

function S:enter()
  self.slot = 1
  self.idx = {}
  for i, slot in ipairs(M.SLOTS) do
    self.idx[i] = 1
    local cur = M.load()[slot]
    for k, it in ipairs(M.ITEMS[slot]) do if it.id == cur then self.idx[i] = k end end
  end
end

local function card_name(id)
  local d = A.BY_ID[id]
  return d and I18N.tr(d.name) or id
end

local function draw_locked()
  G.header(L("Mascote"), L("Bloqueado"))
  local cx, by = 190, 330
  -- silhueta
  lg.setColor(0, 0, 0, 0.6)
  lg.ellipse("fill", cx, by - 52, 64, 52)
  lg.rectangle("fill", cx - 64, by - 52, 128, 48)
  G.text(T.f.h1 or T.f.h2, "?", cx - 10, by - 80, { 0.6, 0.6, 0.7 })
  G.panel(360, 70, T.W - 372, 300, { r = 10 })
  G.text(T.f.h2, I18N.tr(L("Um companheiro te espera...")), 376, 86, T.c.text)
  local got, total = A.count(1)
  local txt = I18N.tr(L("Complete o álbum da Temporada 1 para despertar o seu mascote. Ele vive no canto da tela, reage ao seu dia a dia e ganha visuais novos com cada carta."))
  local f, ls = G.fit_lines(T.f.small, txt, T.W - 404, 120, true)
  for i, l in ipairs(ls) do G.text(f, l, 376, 124 + (i - 1) * G.step(f, 16), T.c.dim) end
  G.text(T.f.small, string.format(I18N.tr(L("%d de %d cartas")), got, total), 376, 300, T.c.faint)
  G.progress(376, 322, T.W - 404, 8, total > 0 and got / total or 0, T.c.yellow)
  G.hints({ { "b", L("Voltar") } })
end

function S:draw()
  if not M.unlocked() then return draw_locked() end
  local st = M.load()
  G.header(L("Personalizar"), st.name or "Bit")
  -- palco
  G.panel(12, 50, 330, 384, { r = 12 })
  lg.setColor(1, 1, 1, 0.04)
  lg.ellipse("fill", 177, 360, 120, 18)
  MV.draw(177, 352, 2.6, { key = "stage", yaw = -0.3 })
  if M.bubble then MV.bubble(M.bubble.text, 177 + 30, 168) end
  G.text(T.f.h2, st.name or "Bit", 12, 62, T.c.text, "center", 330)
  -- personalidade do mascote (MascotRegistry)
  local r = require("core.mascot3d.registry").get(M.current("species").id)
  if r.personality then
    local f, ls = G.fit_lines(T.f.small, I18N.tr(L(r.personality)), 300, 36, true)
    for i, l in ipairs(ls) do G.text(f, l, 27, 88 + (i - 1) * G.step(f, 16), T.c.dim, "center", 300) end
    -- (fica no topo; o balao de fala nasce mais embaixo, perto da cabeca)
  end
  local lv = M.level()
  G.text(T.f.small, string.format(I18N.tr(L("Nível %d")), lv), 30, 400, T.c.yellow)
  G.progress(100, 406, 222, 7, M.level_progress(), T.c.yellow)
  -- categorias
  local x0, y0 = 352, 50
  local w = T.W - x0 - 12
  for i, slot in ipairs(M.SLOTS) do
    local y = y0 + (i - 1) * 62
    local on = i == self.slot
    G.rect(x0, y, w, 56, on and T.c.bg3 or T.c.bg1, 8)
    if on then G.frame(x0, y, w, 56, T.c.accent, 8, 2) end
    local items = M.ITEMS[slot]
    local it = items[self.idx[i]]
    local ok = M.item_unlocked(it)
    G.text(T.f.pix8, string.upper(I18N.tr(M.SLOT_NAMES[slot])), x0 + 12, y + 8, T.c.faint)
    local label = ok and I18N.tr(it.name) or "???"
    G.text_fit(T.f.bodyb, (on and "‹ " or "") .. label .. (on and " ›" or ""), x0 + 12, y + 22, w - 120, ok and T.c.text or T.c.faint)
    local cnt = 0
    for _, x in ipairs(items) do if M.item_unlocked(x) then cnt = cnt + 1 end end
    G.text(T.f.small, string.format("%d/%d", cnt, #items), x0 + w - 50, y + 8, T.c.dim)
    if not ok then
      Icons.draw("lock", x0 + w - 34, y + 26, T.c.faint, 0.8)
      G.text_fit(T.f.pix8, I18N.tr(L("Carta: ")) .. card_name(it.card), x0 + 12, y + 42, w - 60, T.c.faint)
    elseif slot == "color" and it.rgb then
      lg.setColor(it.rgb[1], it.rgb[2], it.rgb[3], 1)
      lg.circle("fill", x0 + w - 26, y + 34, 9)
    end
  end
  local where = M.get("where") or "all"
  G.text_fit(T.f.small, I18N.tr(L("Aparece: ")) .. I18N.tr(M.WHERE_NAMES[where]), x0, y0 + 5 * 62 + 4, w, T.c.dim)
  G.hints({ { "a", L("Carinho") }, { "select", L("Dançar") }, { "y", L("Dica") },
    { "x", L("Nome") }, { "r1", L("Onde aparece") }, { "b", L("Voltar") } })
end

local function apply(self)
  local slot = M.SLOTS[self.slot]
  local it = M.ITEMS[slot][self.idx[self.slot]]
  if M.item_unlocked(it) then M.set(slot, it.id) end
end

function S:action(act)
  if act == "b" then App.pop(); return end
  if not M.unlocked() then return end
  local n = #M.SLOTS
  if act == "up" then self.slot = (self.slot - 2) % n + 1
  elseif act == "down" then self.slot = self.slot % n + 1
  elseif act == "left" or act == "right" then
    local items = M.ITEMS[M.SLOTS[self.slot]]
    self.idx[self.slot] = (self.idx[self.slot] + (act == "left" and -2 or 0)) % #items + 1
    apply(self)
  elseif act == "a" then M.pet()
  elseif act == "select" then M.dance()
  elseif act == "y" then M.tip()
  elseif act == "x" then
    App.push("textinput", { title = L("Nome do mascote"), label = L("Como o mascote vai se chamar?"),
      value = M.get("name") or "Bit", mode = "full", max = 12,
      validate = function(v) if require("lib.util").trim(v or "") == "" then return false, L("Digite pelo menos uma letra.") end return true end,
      on_ok = function(v) M.set("name", require("lib.util").trim(v)); M.say(string.format(I18N.tr(L("Gostei do nome %s!")), M.get("name")), "happy", 3) end })
  elseif act == "r1" then
    local w = M.get("where") or "all"
    local k = 1
    for i, x in ipairs(M.WHERE) do if x == w then k = i end end
    M.set("where", M.WHERE[k % #M.WHERE + 1])
  end
end

return S
