-- =============================================================================
--  Meu perfil > Mascote: o aparelho BITPOCKET com a criatura digital
--  Esquerda: o aparelho (tela LCD com a criatura animada em pixel art,
--  medidores de energia/felicidade/saude). Direita: ficha (forma, estagio,
--  raridade, elemento, nivel, XP, atributos) e o menu de acoes.
--    cima/baixo: escolher | esquerda/direita: opcao da linha (treino,
--    minigame, aparelho) | A: fazer | SELECT: dancar | Y: dica | B: voltar
--  Evolucao: quando a criatura pode evoluir, aparece "Evoluir!"; A toca a cena
--  de transformacao na tela do aparelho (B pula a cena; a evolucao vale igual).
-- =============================================================================
local L = require("lib.i18n").L
local I18N = require("lib.i18n")
local T = require("ui.theme")
local G = require("ui.gfx")
local Icons = require("ui.icons")
local M = require("core.mascot")
local Evo = require("core.mascot3d.evolution")
local Dex = require("core.digipet.dex")
local Care = require("core.digipet.care")
local SP = require("ui.digipet.sprite")
local DV = require("ui.digipet.device")
local A = require("core.achievements")
local lg = love.graphics

local S = {}
local TRAIN = { "pow", "def", "spd", "wis" }
local GAMES = { { id = "reflex", name = L("Reflexo"), attr = "pow" }, { id = "memory", name = L("Memória"), attr = "wis" } }

local function line_id() return M.current("species").id end

function S:enter()
  self.sel = 1
  self.train = 1
  self.game = 1
  self.lcd = nil          -- animacao avulsa na tela { name, t0, dur }
  self.parts = {}         -- particulas na tela do aparelho
  self.floats = {}        -- textos subindo (+25)
  self.press = nil
  self.evo = nil
  local skins = DV.SKINS
  self.skin = 1
  for i, s in ipairs(skins) do if s.id == (M.get("device") or "classic") then self.skin = i end end
  Care.tick(line_id())
end

function S:resume() Care.tick(line_id()) end

local function items(self)
  local id = line_id()
  local c = Care.get(id)
  local ready = M.unlocked() and Evo.can_evolve(id)
  local list = {
    { id = "feed", label = L("Alimentar"), icon = "food" },
    { id = "play", label = L("Brincar"), icon = "note" },
    { id = "train", label = L("Treinar"), opt = I18N.tr(Dex.ATTR_NAMES[TRAIN[self.train]]) },
    { id = "rest", label = c.sleeping and L("Acordar") or L("Descansar") },
    { id = "pet", label = L("Carinho"), icon = "heart" },
    { id = "game", label = L("Minigame"), opt = I18N.tr(GAMES[self.game].name) },
    { id = "evo", label = ready and L("Evoluir!") or L("Evolução"), hot = ready and true or false },
    { id = "dex", label = L("Enciclopédia") },
    { id = "skin", label = L("Aparelho"), opt = I18N.tr(DV.SKINS[self.skin].name), locked = not DV.unlocked(DV.SKINS[self.skin]) },
    { id = "custom", label = L("Personalizar") },
  }
  return list
end

-- ------------------------------------------------------------------ efeitos
local function burst(self, kind, n, c)
  for i = 1, n or 6 do
    self.parts[#self.parts + 1] = { kind = kind, x = (math.random() - 0.5) * 60, y = -20 - math.random() * 40,
      vx = (math.random() - 0.5) * 50, vy = -30 - math.random() * 40, t = 0, life = 1 + math.random() * 0.6, c = c }
  end
end

local function float(self, txt, c)
  self.floats[#self.floats + 1] = { txt = txt, t = 0, c = c or { 1, 1, 1 } }
end

local function play_lcd(self, name, dur)
  self.lcd = { name = name, t0 = App.t, dur = dur or 1.6 }
end

-- ------------------------------------------------------------------ desenho
local RCOL = function(rar) return (A.RARITY[rar] or A.RARITY.common).color end

local function draw_lcd(self, lx, ly, lw, lh, skin)
  local id = line_id()
  local c = Care.tick(id)
  local f = Evo.get_form(id)
  local ink = skin.ink
  -- topo: medidores
  DV.icon("bolt", lx + 6, ly + 6, ink)
  DV.meter(lx + 16, ly + 6, 5, c.energy, { 1, 0.8, 0.2 }, ink)
  DV.icon("heart", lx + 58, ly + 6, ink)
  DV.meter(lx + 68, ly + 6, 5, c.happiness, { 1, 0.4, 0.55 }, ink)
  DV.icon("cross", lx + 110, ly + 6, ink)
  DV.meter(lx + 120, ly + 6, 5, c.health, { 0.35, 0.85, 0.45 }, ink)
  G.text(T.f.pix8, "LV" .. Evo.get_level(id), lx + lw - 44, ly + 5, ink)
  -- chao do LCD
  local feet = ly + lh - 26
  lg.setColor(ink[1], ink[2], ink[3], 0.18)
  for gx = lx + 8, lx + lw - 12, 8 do lg.rectangle("fill", gx, feet + 2, 4, 2) end
  -- criatura
  local cx = lx + lw / 2
  if self.evo then
    G.clip(lx, ly, lw, lh)
    S.draw_evo(self, cx, feet, lx, ly, lw, lh, ink)
    G.unclip()
  elseif f then
    local an, t0 = nil, nil
    if self.lcd then
      if App.t - self.lcd.t0 < self.lcd.dur then an, t0 = self.lcd.name, self.lcd.t0 else self.lcd = nil end
    end
    if not an then
      local mood = Care.mood(id)
      an = (M.mood ~= "idle" and require("ui.mascot_view").pick_anim(M.mood))
        or (mood == "sleep" and "sleep") or ((mood == "sad" or mood == "tired") and "sad") or "idle"
      t0 = 0
    end
    local ok = SP.draw(f.id, an, App.t - t0, cx, feet, 2, { hat = M.current("hat").id })
    if not ok then require("ui.mascot_view").draw(cx, feet, 2.2, { force2d = true }) end
    if c.sleeping then
      for i = 0, 2 do
        local k = ((App.t * 0.5) + i / 3) % 1
        DV.icon("z", cx + 30 + k * 20, feet - 90 - k * 30, { ink[1], ink[2], ink[3], 1 - k }, 2)
      end
    end
  end
  -- particulas e textos
  for _, p in ipairs(self.parts) do
    local a = 1 - p.t / p.life
    local col = p.c or ink
    if p.kind == "heart" then DV.icon("heart", cx + p.x, feet - 60 + p.y, { 1, 0.4, 0.55, a }, 2)
    elseif p.kind == "food" then DV.icon("food", cx + p.x, feet - 40 + p.y, { 1, 0.7, 0.3, a }, 2)
    elseif p.kind == "note" then DV.icon("note", cx + p.x, feet - 60 + p.y, { ink[1], ink[2], ink[3], a }, 2)
    elseif p.kind == "star" then DV.icon("star", cx + p.x, feet - 60 + p.y, { col[1], col[2], col[3], a }, 2)
    else lg.setColor(col[1], col[2], col[3], a); lg.rectangle("fill", cx + p.x, feet - 50 + p.y, 4, 4) end
  end
  for _, fl in ipairs(self.floats) do
    local a = 1 - fl.t / 1.4
    G.text(T.f.pix8, fl.txt, cx - 60, feet - 110 - fl.t * 30, { fl.c[1], fl.c[2], fl.c[3], a }, "center", 120)
  end
  -- rodape: nome da forma
  G.text(T.f.pix8, f and I18N.upper(f.name) or "?", lx, ly + lh - 14, ink, "center", lw)
end

function S:draw()
  if not M.unlocked() then
    return require("ui.screens.mascot").draw(self)
  end
  local id = line_id()
  local f = Evo.get_form(id)
  local skin = DV.SKINS[self.skin]
  if not DV.unlocked(skin) then skin = DV.current() end
  G.header(L("Mascote"), M.get("name") or "Bit")
  -- aparelho
  local col = M.current("color")
  local shell = (col.rgb and not col.signature) and col.rgb or nil
  local lx, ly, lw, lh = DV.draw(14, 50, 300, 384, { skin = skin, color = shell, press = self.press and self.press.b, t = App.t })
  draw_lcd(self, lx, ly, lw, lh, skin)
  if M.bubble and not self.evo then require("ui.mascot_view").bubble(M.bubble.text, lx + lw / 2 + 30, ly + 30) end
  -- ficha
  local px, pw = 326, T.W - 338
  G.panel(px, 50, pw, 152, { r = 10 })
  if f then
    G.text_fit(T.f.h2, f.name, px + 10, 56, pw - 20, T.c.text)
    local x = px + 10
    x = x + G.tag(I18N.upper(I18N.tr(Dex.TIER_NAMES[f.tier] or "")), x, 84, T.c.accent2, T.c.bg0, T.f.pix8) + 4
    local R = A.RARITY[f.rarity] or A.RARITY.common
    x = x + G.tag(I18N.upper(I18N.tr(R.name)), x, 84, R.color, T.c.bg0, T.f.pix8) + 4
    G.tag(I18N.upper(I18N.tr(L(f.element))), x, 84, T.c.bg3, T.c.text, T.f.pix8)
    local lv = Evo.get_level(id)
    local cur, need, frac = Evo.get_progress(id)
    G.text(T.f.small, string.format(I18N.tr(L("Nível %d")), lv), px + 10, 104, T.c.yellow)
    G.text(T.f.small, need > 0 and string.format("%d / %d XP", cur, need) or "MAX", px + pw - 110, 104, T.c.dim, "right", 100)
    G.progress(px + 10, 122, pw - 20, 6, frac, T.c.yellow)
    local at = Care.attrs(id, f)
    for i, a in ipairs(TRAIN) do
      local ax = px + 10 + (i - 1) * ((pw - 20) / 4)
      G.text(T.f.pix8, Care.abbr(I18N.tr(Dex.ATTR_NAMES[a]), 3), ax, 136, T.c.faint)
      G.text(T.f.bodyb, tostring(at[a]), ax, 148, T.c.text)
    end
    local c = Care.get(id)
    local nums = string.format("%s %d   %s %d   %s %d", Care.label("energy"), math.floor(c.energy),
      Care.label("happiness"), math.floor(c.happiness), Care.label("health"), math.floor(c.health))
    G.text_fit(T.f.pix8, nums, px + 10, 182, pw - 20, T.c.dim)
  end
  -- menu
  local list = items(self)
  local my, rh = 208, 22
  for i, it in ipairs(list) do
    local y = my + (i - 1) * rh
    local on = i == self.sel and not self.evo
    G.rect(px, y, pw, rh - 2, on and T.c.bg3 or T.c.bg1, 6)
    if on then G.frame(px, y, pw, rh - 2, T.c.accent, 6, 2) end
    local cc = it.hot and T.c.yellow or (it.locked and T.c.faint or T.c.text)
    G.text(T.f.small, I18N.tr(it.label), px + 10, y + 3, cc)
    if it.opt then
      G.text(T.f.small, (on and "‹ " or "") .. it.opt .. (on and " ›" or ""), px + pw - 160, y + 3,
        it.locked and T.c.faint or T.c.dim, "right", 150)
    end
    if it.hot then
      local k = 0.5 + 0.5 * math.sin(App.t * 6)
      lg.setColor(1, 0.85, 0.2, 0.6 * k)
      lg.rectangle("line", px + 1, y + 1, pw - 2, rh - 4, 6, 6)
    end
  end
  local cur = list[self.sel]
  if self.evo then
    G.hints({ { "b", L("Pular") } })
  else
    local hints = { { "dpad", L("Escolher") }, { "a", L("Fazer") }, { "select", L("Dançar") }, { "y", L("Dica") }, { "b", L("Voltar") } }
    if cur and cur.id == "skin" and cur.locked then hints[2] = { "a", L("Bloqueado") } end
    if App.admin then hints = { { "a", L("Fazer") }, { "l1", "+1 LV" }, { "r1", "MAX" }, { "b", L("Voltar") } } end
    G.hints(hints)
    if cur and cur.id == "skin" and cur.locked then
      G.text_fit(T.f.pix8, I18N.tr(DV.SKINS[self.skin].need), 14, 438, 300, T.c.faint)
    end
  end
end

-- ------------------------------------------------------------------ evolucao
local STYLE = {   -- particulas proprias de cada linha
  slime = "bubble", robot = "spark", cat = "star", ghost = "wisp", skull = "shadow",
  dragon = "flame", knight = "shard", owl = "feather",
}

function S.start_evo(self)
  local id = line_id()
  local to = Evo.can_evolve(id)
  if not to then return end
  self.evo = { t0 = App.t, from = Evo.get_form(id), to = to, line = id, done = false, style = STYLE[id] or "star" }
  self.parts = {}
  pcall(function() require("core.sfx").achievement(to.rarity) end)
end

local function finish_evo(self)
  local e = self.evo
  if not e.done then
    e.done = true
    local ok = pcall(Evo.evolve, e.line, e.to.id)
    if not ok then Evo.evolve(e.line) end
  end
end

-- fases: 0-1.2 preparo (gira) | 1.2-2.6 energia e clarao piscando entre as
-- formas | 2.6 troca | 2.6-3.4 explosao | 3.4-6 pose nova + nome
function S.draw_evo(self, cx, feet, lx, ly, lw, lh, ink)
  local e = self.evo
  local t = App.t - e.t0
  local tint = e.to.tint or { 1, 1, 1 }
  -- fundo escurecendo e raios
  local dark = math.min(1, t / 1.2) * (t < 3.4 and 1 or math.max(0, 1 - (t - 3.4)))
  lg.setColor(0.02, 0.02, 0.06, 0.55 * dark)
  lg.rectangle("fill", lx, ly, lw, lh)
  if t > 0.6 and t < 3.4 then
    for i = 1, 12 do
      local a = i / 12 * math.pi * 2 + t * 1.5
      local r = 140
      lg.setColor(tint[1], tint[2], tint[3], 0.25 * dark)
      lg.polygon("fill", cx, feet - 50, cx + math.cos(a) * r, feet - 50 + math.sin(a) * r,
        cx + math.cos(a + 0.12) * r, feet - 50 + math.sin(a + 0.12) * r)
    end
  end
  -- particulas convergindo (estilo da linha)
  if t < 2.6 then
    for i = 1, 16 do
      local a = i / 16 * math.pi * 2 + t * 2
      local k = 1 - ((t * 0.8 + i / 16) % 1)
      local px, py = cx + math.cos(a) * 110 * k, feet - 50 + math.sin(a) * 80 * k
      lg.setColor(tint[1], tint[2], tint[3], 0.9)
      if e.style == "flame" or e.style == "shard" then lg.polygon("fill", px, py - 6, px - 3, py + 3, px + 3, py + 3)
      elseif e.style == "spark" then lg.rectangle("fill", px - 3, py, 6, 2); lg.rectangle("fill", px, py - 3, 2, 6)
      elseif e.style == "star" or e.style == "feather" then DV.icon("star", px - 3, py - 3, { tint[1], tint[2], tint[3], 0.9 }, 1)
      elseif e.style == "shadow" then lg.setColor(0.4, 0.2, 0.6, 0.9); lg.circle("fill", px, py, 4)
      else lg.circle("line", px, py, 4) end
    end
  end
  -- criatura: preparo -> piscando -> nova
  if t < 1.2 then
    SP.draw(e.from.id, "evolution", t, cx, feet, 2, { white = t / 1.2 * 0.6 })
  elseif t < 2.6 then
    local rate = 4 + (t - 1.2) * 10
    local which = math.floor(t * rate) % 2 == 0 and e.from or e.to
    SP.draw(which.id, "evolution", t, cx, feet, 2, { white = 1 })
  else
    finish_evo(self)
    local w = math.max(0, 1 - (t - 2.6) / 0.8)
    local an = t < 3.4 and "evolution" or "victory"
    SP.draw(e.to.id, an, t - 2.6, cx, feet, 2, { white = w })
    if t < 3.4 then
      for i = 1, 20 do
        local a = i / 20 * math.pi * 2
        local r = (t - 2.6) * 160
        lg.setColor(1, 1, 1, 1 - (t - 2.6) / 0.8)
        lg.rectangle("fill", cx + math.cos(a) * r, feet - 50 + math.sin(a) * r, 4, 4)
      end
    end
  end
  -- clarao na troca
  if t > 2.5 and t < 2.9 then
    lg.setColor(1, 1, 1, 1 - math.abs(t - 2.7) / 0.2)
    lg.rectangle("fill", lx, ly, lw, lh)
  end
  -- nome da nova forma
  if t > 3.4 then
    local R = A.RARITY[e.to.rarity] or A.RARITY.common
    local a = math.min(1, (t - 3.4) / 0.4)
    lg.setColor(0, 0, 0, 0.6 * a)
    lg.rectangle("fill", lx, ly + 22, lw, 40)
    G.text(T.f.pix8, I18N.tr(L("EVOLUIU PARA")), lx, ly + 26, { 1, 1, 1, a }, "center", lw)
    G.text(T.f.bodyb, I18N.upper(e.to.name), lx, ly + 40, { R.color[1], R.color[2], R.color[3], a }, "center", lw)
  end
  if t > 6 then
    self.evo = nil
    M.say(string.format(I18N.tr(L("Eu virei %s!")), e.to.name), "dance", 4)
  end
end

-- ------------------------------------------------------------------ logica
function S:update(dt)
  for i = #self.parts, 1, -1 do
    local p = self.parts[i]
    p.t = p.t + dt
    p.x, p.y = p.x + p.vx * dt, p.y + p.vy * dt
    p.vy = p.vy + 40 * dt
    if p.t > p.life then table.remove(self.parts, i) end
  end
  for i = #self.floats, 1, -1 do
    local f = self.floats[i]
    f.t = f.t + dt
    if f.t > 1.4 then table.remove(self.floats, i) end
  end
  if self.press and App.t - self.press.t > 0.2 then self.press = nil end
end

local function result(self, ok, msg, an, xp, kind)
  if an then play_lcd(self, an, an == "attack" and 0.8 or 1.6) end
  if msg then M.say(msg, ok and "happy" or "sad", 2.5) end
  if ok and kind then burst(self, kind, 6) end
  if xp and xp > 0 then float(self, "+" .. xp .. " XP", { 1, 0.9, 0.3 }) end
end

function S:action(act)
  if not M.unlocked() then
    if act == "b" then App.pop() end
    return
  end
  if self.evo then
    if act == "b" then finish_evo(self); self.evo.t0 = App.t - 3.4 end
    return
  end
  local list = items(self)
  local n = #list
  local id = line_id()
  local it = list[self.sel]
  if act == "b" then App.pop(); return end
  if act == "up" then self.sel = (self.sel - 2) % n + 1
  elseif act == "down" then self.sel = self.sel % n + 1
  elseif act == "left" or act == "right" then
    local d = act == "left" and -1 or 1
    if it.id == "train" then self.train = (self.train - 1 + d) % #TRAIN + 1
    elseif it.id == "game" then self.game = (self.game - 1 + d) % #GAMES + 1
    elseif it.id == "skin" then
      self.skin = (self.skin - 1 + d) % #DV.SKINS + 1
      if DV.unlocked(DV.SKINS[self.skin]) then M.set("device", DV.SKINS[self.skin].id) end
    end
  elseif App.admin and act == "l1" then App.admin.level_up(id); float(self, "+1 LV", { 1, 0.9, 0.3 })
  elseif App.admin and act == "r1" then App.admin.fill(id); float(self, "MAX", { 0.4, 1, 0.5 })
  elseif act == "select" then M.dance(); play_lcd(self, "victory", 2); burst(self, "note", 5)
  elseif act == "y" then M.tip()
  elseif act == "a" then
    self.press = { b = (self.sel % 3) + 1, t = App.t }
    if it.id == "feed" then local ok, msg, an, xp = Care.feed(id); result(self, ok, msg, an, xp, "food")
    elseif it.id == "play" then local ok, msg, an, xp = Care.play(id); result(self, ok, msg, an, xp, "note")
    elseif it.id == "train" then local ok, msg, an, xp = Care.train(id, TRAIN[self.train]); result(self, ok, msg, an, xp, "star")
    elseif it.id == "rest" then local ok, msg, an, xp = Care.rest(id); result(self, ok, msg, an, xp)
    elseif it.id == "pet" then Care.pet(id); M.pet(); play_lcd(self, "happy", 1.6); burst(self, "heart", 5)
    elseif it.id == "game" then
      local c = Care.tick(id)
      if c.sleeping then M.say(I18N.tr(L("Zzz... está dormindo.")), "sleep", 2)
      elseif c.energy < 10 then M.say(I18N.tr(L("Estou sem energia...")), "sad", 2)
      else App.push("digigame", { game = GAMES[self.game].id, attr = GAMES[self.game].attr }) end
    elseif it.id == "evo" then
      if Evo.can_evolve(id) then S.start_evo(self) else App.push("digievo") end
    elseif it.id == "dex" then App.push("digidex")
    elseif it.id == "skin" then
      if DV.unlocked(DV.SKINS[self.skin]) then M.set("device", DV.SKINS[self.skin].id) end
    elseif it.id == "custom" then App.push("mascot")
    end
  end
end

return S
