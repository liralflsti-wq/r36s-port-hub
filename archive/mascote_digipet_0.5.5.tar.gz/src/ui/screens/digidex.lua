-- =============================================================================
--  Enciclopedia das criaturas (BITPOCKET > Enciclopedia)
--  Esquerda: as 8 linhas (bloqueadas = carta ainda nao conquistada) com o
--  progresso de formas descobertas. Direita: as 6 formas da linha (silhueta
--  enquanto nao descobertas, moldura na cor da raridade) e a ficha completa:
--  estagio, raridade, elemento, habilidade, atributos, descricao, historia e
--  como chegar nela. Secretas: so o enigma ate serem descobertas.
--    cima/baixo: linha | esquerda/direita: forma | B: voltar
-- =============================================================================
local L = require("lib.i18n").L
local I18N = require("lib.i18n")
local T = require("ui.theme")
local G = require("ui.gfx")
local Icons = require("ui.icons")
local M = require("core.mascot")
local Evo = require("core.mascot3d.evolution")
local Dex = require("core.digipet.dex")
local SP = require("ui.digipet.sprite")
local Care = require("core.digipet.care")
local A = require("core.achievements")
local lg = love.graphics

local S = {}

function S:enter()
  self.li, self.fi = 1, 1
  for i, ln in ipairs(Dex.lines()) do if ln.id == M.current("species").id then self.li = i end end
end

local function line_open(ln)
  local it = M.item("species", ln.id)
  return it and it.id == ln.id and M.item_unlocked(it)
end

local function found(ln)
  local n = 0
  for _, f in ipairs(ln.forms) do if Evo.discovered(ln.id, f.id) then n = n + 1 end end
  return n
end

--- de onde vem a forma (requisito na forma anterior)
local function origin(ln, f)
  for _, prev in ipairs(ln.forms) do
    for _, e in ipairs(prev.evolves or {}) do
      if e.to == f.id then return prev, e end
    end
  end
  return nil
end

function S:draw()
  local lines = Dex.lines()
  local total, seen = Dex.count(), 0
  for _, ln in ipairs(lines) do seen = seen + found(ln) end
  G.header(L("Enciclopédia"), string.format(I18N.tr(L("%d de %d formas")), seen, total))
  -- linhas
  for i, ln in ipairs(lines) do
    local y = 50 + (i - 1) * 47
    local on = i == self.li
    local open = line_open(ln)
    G.rect(12, y, 190, 43, on and T.c.bg3 or T.c.bg1, 8)
    if on then G.frame(12, y, 190, 43, T.c.accent, 8, 2) end
    G.clip(14, y + 2, 40, 39)
    SP.draw(ln.forms[1].id, "idle", 0, 34, y + 42, 0.5, { black = (not open) and 1 or nil })
    G.unclip()
    G.text_fit(T.f.bodyb, open and ln.forms[1].name or "???", 58, y + 5, 140, open and T.c.text or T.c.faint)
    G.text(T.f.small, open and string.format("%d / %d  ·  %s", found(ln), #ln.forms, I18N.tr(L(ln.element))) or I18N.tr(L("Bloqueada")),
      58, y + 23, T.c.dim)
  end
  local ln = lines[self.li]
  if not ln then return end
  local open = line_open(ln)
  -- formas
  local cx0 = 212
  for i, f in ipairs(ln.forms) do
    local x = cx0 + (i - 1) * 70
    local on = i == self.fi
    local known = open and Evo.discovered(ln.id, f.id)
    local R = A.RARITY[f.rarity] or A.RARITY.common
    G.rect(x, 50, 66, 78, on and T.c.bg3 or T.c.bg1, 6)
    G.frame(x, 50, 66, 78, known and R.color or T.c.bg3, 6, on and 3 or 1)
    G.clip(x + 2, 52, 62, 74)
    SP.draw(f.id, "idle", known and App.t or 0, x + 33, 124, 0.8, { black = (not known) and 1 or nil })
    G.unclip()
  end
  -- ficha
  local f = ln.forms[self.fi]
  local known = open and Evo.discovered(ln.id, f.id)
  local px, py, pw = 212, 136, T.W - 224
  G.panel(px, py, pw, 296, { r = 10 })
  local R = A.RARITY[f.rarity] or A.RARITY.common
  if not open then
    Icons.draw("lock", px + 16, py + 16, T.c.faint, 1)
    local d = A.BY_ID[ln.card]
    G.text_fit(T.f.small, I18N.tr(L("Linha bloqueada. Conquiste a carta: ")) .. (d and I18N.tr(d.name) or "?"), px + 40, py + 16, pw - 52, T.c.dim)
  else
    local secret = f.branch == "secret" and not known
    G.text(T.f.h2, known and f.name or "???", px + 12, py + 8, known and R.color or T.c.faint)
    local x = px + 12
    x = x + G.tag(I18N.upper(I18N.tr(Dex.TIER_NAMES[f.tier] or "")), x, py + 38, T.c.accent2, T.c.bg0, T.f.pix8) + 4
    x = x + G.tag(I18N.upper(I18N.tr(R.name)), x, py + 38, R.color, T.c.bg0, T.f.pix8) + 4
    if known then G.tag(I18N.upper(I18N.tr(L(f.element))), x, py + 38, T.c.bg3, T.c.text, T.f.pix8) end
    local y = py + 60
    if known then
      G.text(T.f.small, I18N.tr(L("Habilidade: ")) .. I18N.tr(L(f.skill)), px + 12, y, T.c.yellow); y = y + 20
      for i, a in ipairs(Dex.ATTRS) do
        local ax = px + 12 + (i - 1) * ((pw - 24) / 4)
        G.text(T.f.pix8, Care.abbr(I18N.tr(Dex.ATTR_NAMES[a]), 3), ax, y, T.c.faint)
        G.text(T.f.bodyb, tostring(f.stats[a] or 0), ax + 30, y - 3, T.c.text)
      end
      y = y + 20
      local txt = I18N.tr(L(f.desc)) .. "\n" .. I18N.tr(L(f.story))
      local f2, ls = G.fit_lines(T.f.small, txt, pw - 24, 90, false)
      for _, l in ipairs(ls) do G.text(f2, l, px + 12, y, T.c.dim); y = y + G.step(f2, 15) end
    else
      G.text_fit(T.f.small, I18N.tr(L("Ainda não descoberta.")), px + 12, y, pw - 24, T.c.dim); y = y + 20
    end
    -- como obter
    y = math.max(y + 6, py + 196)
    G.text(T.f.pix8, I18N.tr(L("COMO OBTER")), px + 12, y, T.c.faint); y = y + 14
    local prev, e = origin(ln, f)
    local how
    if not prev then how = I18N.tr(L("Forma inicial: chega com a criatura."))
    elseif secret then how = I18N.tr(L("Enigma: ")) .. I18N.tr(L(e.hint or ""))
    else
      local parts = {}
      for k, v in pairs(e.req or {}) do
        if k == "level" then parts[#parts + 1] = string.format(I18N.tr(L("nível %d")), v)
        elseif k == "attr" then for a, n in pairs(v) do parts[#parts + 1] = I18N.tr(Dex.ATTR_NAMES[a]) .. " " .. n end
        else
          local nm = require("ui.screens.digievo").REQ_NAMES[k]
          parts[#parts + 1] = (nm and I18N.tr(nm) or k) .. (type(v) == "number" and (" " .. v) or "")
        end
      end
      table.sort(parts)
      how = string.format(I18N.tr(L("Evolui de %s com: %s")), known and prev.name or (Evo.discovered(ln.id, prev.id) and prev.name or "???"), table.concat(parts, ", "))
    end
    local f3, ls3 = G.fit_lines(T.f.small, how, pw - 24, 60, true)
    for _, l in ipairs(ls3) do G.text(f3, l, px + 12, y, T.c.dim); y = y + G.step(f3, 15) end
  end
  G.hints({ { "dpad", L("Navegar") }, { "b", L("Voltar") } })
end

function S:action(act)
  local lines = Dex.lines()
  if act == "b" then App.pop(); return end
  if act == "up" then self.li = math.max(1, self.li - 1)
  elseif act == "down" then self.li = math.min(#lines, self.li + 1)
  elseif act == "left" then self.fi = math.max(1, self.fi - 1)
  elseif act == "right" then self.fi = math.min(#(lines[self.li].forms), self.fi + 1) end
end

return S
