-- =============================================================================
--  Painel de evolucao da criatura atual (BITPOCKET > Evolucao)
--  Esquerda: a forma escolhida na galeria (descobertas em cores; as futuras em
--  silhueta). Direita: nivel, XP, estagio, proximos destinos com a lista de
--  requisitos (cumpridos em verde) e o historico de evolucoes.
--  Formas secretas mostram so um enigma ate serem descobertas.
--    esquerda/direita: galeria | B: voltar
-- =============================================================================
local L = require("lib.i18n").L
local I18N = require("lib.i18n")
local T = require("ui.theme")
local G = require("ui.gfx")
local M = require("core.mascot")
local Evo = require("core.mascot3d.evolution")
local Dex = require("core.digipet.dex")
local SP = require("ui.digipet.sprite")
local DV = require("ui.digipet.device")
local A = require("core.achievements")
local lg = love.graphics

local S = {}

S.REQ_NAMES = {
  level = L("Nível"), happiness = L("Felicidade"), health = L("Saúde"), trainings = L("Treinos"),
  feeds = L("Refeições"), plays = L("Brincadeiras"), pets = L("Carinhos"), minigames = L("Minigames vencidos"),
  care = L("Cuidados (carinho, brincar, comer)"), attr_pow = L("Força"), attr_def = L("Defesa"),
  attr_spd = L("Velocidade"), attr_wis = L("Sabedoria"), attr_sum = L("Soma dos atributos"),
  lines = L("Criaturas na forma Suprema"), screens = L("Telas do hub descobertas"), album = L("Álbum completo"),
  night = L("Evoluir de madrugada (0h às 4h)"),
}
S.PATH_NAMES = { treino = L("Ramo do treino"), cuidado = L("Ramo do cuidado"), padrao = L("Caminho natural") }

local function line() return M.current("species").id end

function S:enter()
  local ln = Dex.line(line())
  self.sel = 1
  local cur = Evo.get_form(line())
  for i, f in ipairs(ln and ln.forms or {}) do if cur and f.id == cur.id then self.sel = i end end
end

function S.req_lines(id, cand)
  local out = {}
  for _, r in ipairs(cand.list) do
    local name = (r.key == "health") and require("core.digipet.care").label("health") or I18N.tr(S.REQ_NAMES[r.key] or r.key)
    local txt
    if r.key == "album" or r.key == "night" then txt = name
    else txt = string.format("%s %d  (%d)", name, r.need, r.have) end
    out[#out + 1] = { txt = txt, ok = r.ok }
  end
  return out
end

function S:draw()
  local id = line()
  local ln = Dex.line(id)
  local cur = Evo.get_form(id)
  G.header(L("Evolução"), cur and cur.name or "")
  if not ln or not cur then return end
  local skin = DV.current()
  -- vitrine
  G.panel(12, 50, 236, 250, { r = 10 })
  local f = ln.forms[self.sel]
  local seen = Evo.discovered(id, f.id)
  lg.setColor(skin.lcd[1], skin.lcd[2], skin.lcd[3], 1)
  lg.rectangle("fill", 22, 60, 216, 190, 6, 6)
  lg.setColor(skin.lcd2[1], skin.lcd2[2], skin.lcd2[3], 0.5)
  for gy = 60, 249, 3 do lg.rectangle("fill", 22, gy, 216, 1) end
  SP.draw(f.id, seen and "idle" or "idle", seen and App.t or 0, 130, 238, 2, { black = (not seen) and 1 or nil })
  local R = A.RARITY[f.rarity] or A.RARITY.common
  G.text_fit(T.f.bodyb, seen and f.name or "???", 22, 256, 216, seen and R.color or T.c.faint)
  local sub = I18N.tr(Dex.TIER_NAMES[f.tier] or "")
  if f.branch == "alt" then sub = sub .. " · " .. I18N.tr(L("Alternativa")) end
  G.text_fit(T.f.small, sub, 22, 276, 216, T.c.dim)
  -- galeria
  local gx, gy = 12, 308
  for i, fm in ipairs(ln.forms) do
    local x = gx + (i - 1) * 40
    local on = i == self.sel
    G.rect(x, gy, 36, 46, on and T.c.bg3 or T.c.bg1, 5)
    if on then G.frame(x, gy, 36, 46, T.c.accent, 5, 2) end
    local sn = Evo.discovered(id, fm.id)
    G.clip(x + 1, gy + 1, 34, 44)
    SP.draw(fm.id, "idle", 0, x + 18, gy + 42, 0.5, { black = (not sn) and 1 or nil })
    G.unclip()
  end
  -- ficha
  local px, pw = 260, T.W - 272
  G.panel(px, 50, pw, 380, { r = 10 })
  local lv = Evo.get_level(id)
  local c, need, frac = Evo.get_progress(id)
  G.text(T.f.h2, cur.name, px + 12, 58, T.c.text)
  G.text(T.f.small, string.format(I18N.tr(L("Nível %d")), lv) .. "  ·  " .. I18N.tr(Dex.TIER_NAMES[cur.tier] or ""), px + 12, 86, T.c.yellow)
  G.text(T.f.small, need > 0 and string.format(I18N.tr(L("%d de %d XP para o próximo nível")), c, need) or "MAX", px + 12, 104, T.c.dim)
  G.progress(px + 12, 124, pw - 24, 7, frac, T.c.yellow)
  local y = 140
  G.text(T.f.pix8, I18N.tr(L("PRÓXIMA EVOLUÇÃO")), px + 12, y, T.c.faint)
  y = y + 14
  local cands = Evo.candidates(id)
  if #cands == 0 then
    G.text_fit(T.f.small, I18N.tr(L("Forma final: não evolui mais.")), px + 12, y, pw - 24, T.c.green)
    y = y + 20
  end
  local shown = {}
  for _, cnd in ipairs(cands) do
    if cnd.to and not shown[cnd.to.id .. tostring(cnd.entry.path)] then
      shown[cnd.to.id .. tostring(cnd.entry.path)] = true
      local known = Evo.discovered(id, cnd.to.id)
      local secret = cnd.entry.secret and not known
      local title = (secret and "???" or cnd.to.name)
      if cnd.entry.path then title = title .. "  ·  " .. I18N.tr(S.PATH_NAMES[cnd.entry.path] or "") end
      G.text_fit(T.f.bodyb, title, px + 12, y, pw - 24, cnd.ok and T.c.green or T.c.text)
      y = y + 20
      if secret then
        local f2, ls = G.fit_lines(T.f.small, I18N.tr(L("Enigma: ")) .. I18N.tr(L(cnd.entry.hint or "")), pw - 24, 36, true)
        for _, l in ipairs(ls) do G.text(f2, l, px + 18, y, T.c.dim); y = y + G.step(f2, 15) end
      else
        for _, rl in ipairs(S.req_lines(id, cnd)) do
          G.text_fit(T.f.small, (rl.ok and "[x] " or "[ ] ") .. rl.txt, px + 18, y, pw - 30, rl.ok and T.c.green or T.c.dim)
          y = y + 16
        end
      end
      y = y + 4
      if y > 360 then break end
    end
  end
  -- historico
  local hist = Evo.history(id)
  if #hist > 0 and y < 380 then
    G.text(T.f.pix8, I18N.tr(L("HISTÓRICO")), px + 12, math.max(y, 368), T.c.faint)
    local h = hist[#hist]
    local a, b = Dex.form(h.from_form or ""), Dex.form(h.to_form or "")
    G.text_fit(T.f.small, string.format("%s > %s  (%s)", a and a.name or "?", b and b.name or "?", os.date("%d/%m/%Y", h.t or 0)),
      px + 12, math.max(y, 368) + 14, pw - 24, T.c.dim)
  end
  G.hints({ { "dpad", L("Galeria") }, { "b", L("Voltar") } })
end

function S:action(act)
  local ln = Dex.line(line())
  if act == "b" then App.pop(); return end
  if not ln then return end
  if act == "left" then self.sel = math.max(1, self.sel - 1)
  elseif act == "right" then self.sel = math.min(#ln.forms, self.sel + 1) end
end

return S
