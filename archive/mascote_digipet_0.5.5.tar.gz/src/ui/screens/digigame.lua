-- =============================================================================
--  Minigames do BITPOCKET (treino com consequencia real nos atributos)
--    reflex: um marcador corre na barra; A quando estiver na zona verde.
--            5 rodadas, a zona encolhe. 3 acertos ou mais = vitoria (Forca +2)
--    memory: a tela mostra uma sequencia de setas; repita no direcional.
--            4 rodadas (3, 4, 5 e 6 setas). 3 ou mais = vitoria (Sabedoria +2)
--  Cada partida gasta energia; vencer da XP (limite por dia) e felicidade.
--    B: sair (conta como derrota se a partida comecou)
-- =============================================================================
local L = require("lib.i18n").L
local I18N = require("lib.i18n")
local T = require("ui.theme")
local G = require("ui.gfx")
local M = require("core.mascot")
local Evo = require("core.mascot3d.evolution")
local Care = require("core.digipet.care")
local Dex = require("core.digipet.dex")
local SP = require("ui.digipet.sprite")
local DV = require("ui.digipet.device")
local lg = love.graphics

local S = {}
local ARROWS = { "up", "right", "down", "left" }
local GLYPH = { up = "^", down = "v", left = "<", right = ">" }

function S:enter(p)
  self.game = p.game or "reflex"
  self.attr = p.attr or (self.game == "reflex" and "pow" or "wis")
  self.round, self.hits, self.over = 1, 0, false
  self.anim, self.anim_t0 = "idle", App.t
  self.msg = nil
  if self.game == "reflex" then self:new_bar() else self:new_seq() end
end

function S:new_bar()
  self.pos, self.dir = 0, 1
  self.speed = 0.9 + self.round * 0.25
  self.zone_w = math.max(0.1, 0.28 - self.round * 0.035)
  self.zone = 0.15 + math.random() * (0.7 - self.zone_w)
  self.wait = 0
end

function S:new_seq()
  local n = 2 + self.round
  self.seq = {}
  for i = 1, n do self.seq[i] = ARROWS[math.random(#ARROWS)] end
  self.show_t = App.t
  self.input = {}
  self.phase = "show"
end

local function set_anim(self, a) self.anim, self.anim_t0 = a, App.t end

local function finish(self)
  self.over = true
  local won = self.hits >= 3
  local xp = Care.minigame(M.current("species").id, self.attr, won)
  self.won = won
  set_anim(self, won and "victory" or "sad")
  local an = I18N.tr(Dex.ATTR_NAMES[self.attr])
  self.msg = won and string.format(I18N.tr(L("Vitória! %s +2")), an) .. (xp > 0 and ("  +" .. xp .. " XP") or "")
    or I18N.tr(L("Não foi dessa vez..."))
end

local function next_round(self, hit)
  if hit then self.hits = self.hits + 1; set_anim(self, "attack") else set_anim(self, "hurt") end
  if self.round >= (self.game == "reflex" and 5 or 4) then return finish(self) end
  self.round = self.round + 1
  if self.game == "reflex" then self:new_bar() else self:new_seq() end
end

function S:update(dt)
  if self.over then return end
  if self.game == "reflex" then
    if self.wait > 0 then self.wait = self.wait - dt; return end
    self.pos = self.pos + self.dir * self.speed * dt
    if self.pos > 1 then self.pos, self.dir = 1, -1 elseif self.pos < 0 then self.pos, self.dir = 0, 1 end
  else
    if self.phase == "show" and App.t - self.show_t > #self.seq * 0.7 + 0.4 then self.phase = "input" end
  end
end

function S:draw()
  local id = M.current("species").id
  local f = Evo.get_form(id)
  G.header(L("Minigame"), I18N.tr(self.game == "reflex" and L("Reflexo") or L("Memória")))
  local skin = DV.current()
  local col = M.current("color")
  local lx, ly, lw, lh = DV.draw(170, 50, 300, 384, { skin = skin, color = (col.rgb and not col.signature) and col.rgb or nil, t = App.t })
  local ink = skin.ink
  G.text(T.f.pix8, string.format("%s %d   %s %d", I18N.tr(L("RODADA")), self.round, I18N.tr(L("ACERTOS")), self.hits), lx + 6, ly + 6, ink)
  local feet = ly + lh - 26
  if f then SP.draw(f.id, self.anim, App.t - self.anim_t0, lx + lw / 2, feet, 2) end
  if self.game == "reflex" and not self.over then
    local bx, by, bw = lx + 14, ly + 26, lw - 28
    lg.setColor(ink[1], ink[2], ink[3], 0.3); lg.rectangle("fill", bx, by, bw, 12)
    lg.setColor(0.3, 0.85, 0.4, 1); lg.rectangle("fill", bx + self.zone * bw, by, self.zone_w * bw, 12)
    lg.setColor(ink[1], ink[2], ink[3], 1); lg.rectangle("fill", bx + self.pos * bw - 2, by - 3, 4, 18)
  elseif self.game == "memory" and not self.over then
    local s = ""
    if self.phase == "show" then
      local k = math.floor((App.t - self.show_t) / 0.7) + 1
      if self.seq[k] and ((App.t - self.show_t) % 0.7) < 0.5 then s = GLYPH[self.seq[k]] end
      G.text(T.f.h1 or T.f.h2, s, lx, ly + 26, ink, "center", lw)
    else
      for i = 1, #self.seq do s = s .. (self.input[i] and GLYPH[self.input[i]] or "_") .. " " end
      G.text(T.f.h2, s, lx, ly + 30, ink, "center", lw)
    end
  end
  if self.msg then
    lg.setColor(0, 0, 0, 0.55)
    lg.rectangle("fill", lx, ly + 50, lw, 30)
    G.text_fit(T.f.small, self.msg, lx + 6, ly + 56, lw - 12, { 1, 1, 1 })
  end
  local tip = self.game == "reflex" and L("Aperte A quando o marcador estiver na zona verde.")
    or L("Decore as setas e repita no direcional.")
  local f2, ls = G.fit_lines(T.f.small, I18N.tr(tip), 140, 200, true)
  for i, l in ipairs(ls) do G.text(f2, l, 16, 70 + (i - 1) * G.step(f2, 16), T.c.dim) end
  local an = I18N.tr(Dex.ATTR_NAMES[self.attr])
  G.text_fit(T.f.small, string.format(I18N.tr(L("Treina: %s")), an), 488, 70, 140, T.c.yellow)
  if self.over then G.hints({ { "a", L("Jogar de novo") }, { "b", L("Voltar") } })
  elseif self.game == "reflex" then G.hints({ { "a", L("Agora!") }, { "b", L("Sair") } })
  else G.hints({ { "dpad", L("Repetir") }, { "b", L("Sair") } }) end
end

function S:action(act)
  if act == "b" then
    if not self.over and (self.round > 1 or self.hits > 0) then finish(self) end
    App.pop(); return
  end
  if self.over then
    if act == "a" then
      if Care.get(M.current("species").id).energy < 10 then
        self.msg = I18N.tr(L("Estou sem energia..."))
      else S.enter(self, { game = self.game, attr = self.attr }) end
    end
    return
  end
  if self.game == "reflex" then
    if act == "a" and self.wait <= 0 then
      local hit = self.pos >= self.zone and self.pos <= self.zone + self.zone_w
      self.wait = 0.5
      next_round(self, hit)
    end
  elseif self.phase == "input" and GLYPH[act] then
    self.input[#self.input + 1] = act
    local i = #self.input
    if self.input[i] ~= self.seq[i] then next_round(self, false)
    elseif i == #self.seq then next_round(self, true) end
  end
end

return S
