-- =============================================================================
--  Desenho do mascote (arte original, feita em codigo: nenhuma imagem)
--    MV.draw(cx, by, sc, o)  desenha o mascote com os pes em (cx, by), no
--                            tamanho sc (1 = ~34 px); o = { species, color,
--                            hat, aura, fx, mood, t, jump } (opcional: usa o
--                            estado salvo em core/mascot.lua)
--    MV.draw_corner()        o mascote no canto da tela (todas as telas ou so
--                            na inicial, conforme a escolha), com balao de fala
--  MascotWidget (0.5.5): desenha a CRIATURA DIGITAL em pixel art (sprites
--  gerados dos modelos 3D por tools/bake_sprites.sh), animada quadro a quadro
--  conforme o humor (ui/digipet/sprite.lua). Sem sprite, ou com o estilo
--  "Desenho simples", usa o desenho 2D abaixo (reserva).
--  Especies 2D: slime, robo, gatinho, fantasminha, caveira das sombras,
--  dragaozinho, cavaleiro dragao e corujinha, com volume pintado em camadas.
--  Expressoes: idle, happy, sleep, sad, scared, love, dance, worried.
-- =============================================================================
local T = require("ui.theme")
local G = require("ui.gfx")
local M = require("core.mascot")
local Reg = require("core.mascot3d.registry")
local lg = love.graphics

local MV = {}

local function anim() return App and App.animations and App.animations() end

local function hsv(h, s, v)
  h = (h % 1) * 6
  local i = math.floor(h)
  local f = h - i
  local p, q, t = v * (1 - s), v * (1 - s * f), v * (1 - s * (1 - f))
  if i == 0 then return v, t, p elseif i == 1 then return q, v, p elseif i == 2 then return p, v, t
  elseif i == 3 then return p, q, v elseif i == 4 then return t, p, v else return v, p, q end
end

local function body_color(color, t, species)
  local it = M.item("color", color)
  if it.rainbow then local r, g, b = hsv(t * 0.15, 0.55, 1); return { r, g, b } end
  if it.signature then return Reg.get(species).color or { 1, 0.55, 0.2 } end
  return it.rgb or { 1, 0.55, 0.2 }
end

local function shade(c, k) return { c[1] * k, c[2] * k, c[3] * k } end

local function heart(x, y, r, a)
  lg.setColor(1, 0.35, 0.5, a)
  lg.circle("fill", x - r * 0.5, y, r * 0.55)
  lg.circle("fill", x + r * 0.5, y, r * 0.55)
  lg.polygon("fill", x - r * 1.05, y + r * 0.15, x + r * 1.05, y + r * 0.15, x, y + r * 1.25)
end

local function star(x, y, r, a, c)
  c = c or { 1, 0.95, 0.6 }
  lg.setColor(c[1], c[2], c[3], a)
  lg.polygon("fill", x, y - r, x + r * 0.25, y - r * 0.25, x + r, y, x + r * 0.25, y + r * 0.25,
    x, y + r, x - r * 0.25, y + r * 0.25, x - r, y, x - r * 0.25, y - r * 0.25)
end

-- olhos e boca conforme o humor (rosto centrado em fx, fy; tamanho u)
local function face(fx, fy, u, mood, t, ink)
  ink = ink or { 0.12, 0.08, 0.10 }
  local blink = anim() and ((t * 0.37) % 1 > 0.96)
  local look = anim() and math.sin(t * 0.7) * u * 0.06 or 0
  local ex = u * 0.22
  lg.setColor(ink[1], ink[2], ink[3], 1)
  lg.setLineWidth(math.max(1, u * 0.05))
  local function eye(x)
    if mood == "sleep" or blink then
      lg.line(x - u * 0.07, fy, x + u * 0.07, fy)
    elseif mood == "happy" or mood == "dance" then
      lg.arc("line", "open", x, fy + u * 0.03, u * 0.07, math.pi, 2 * math.pi)
    elseif mood == "love" then
      heart(x, fy - u * 0.04, u * 0.08, 1)
      lg.setColor(ink[1], ink[2], ink[3], 1)
    elseif mood == "scared" then
      lg.setColor(1, 1, 1, 1); lg.circle("fill", x, fy, u * 0.09)
      lg.setColor(ink[1], ink[2], ink[3], 1); lg.circle("fill", x, fy, u * 0.035)
    elseif mood == "sad" or mood == "worried" then
      lg.circle("fill", x + look, fy + u * 0.02, u * 0.05)
      lg.line(x - u * 0.09, fy - u * 0.1 + (x < fx and u * 0.04 or 0), x + u * 0.09, fy - u * 0.1 + (x < fx and 0 or u * 0.04))
    else
      lg.circle("fill", x + look, fy, u * 0.055)
      lg.setColor(1, 1, 1, 0.9); lg.circle("fill", x + look + u * 0.02, fy - u * 0.02, u * 0.018)
      lg.setColor(ink[1], ink[2], ink[3], 1)
    end
  end
  eye(fx - ex); eye(fx + ex)
  -- boca
  local my = fy + u * 0.16
  if mood == "happy" or mood == "love" or mood == "dance" then
    lg.arc("fill", "pie", fx, my - u * 0.02, u * 0.08, 0, math.pi)
  elseif mood == "sad" or mood == "worried" then
    lg.arc("line", "open", fx, my + u * 0.05, u * 0.06, math.pi * 1.15, math.pi * 1.85)
  elseif mood == "scared" then
    lg.ellipse("line", fx, my + u * 0.01, u * 0.04, u * 0.06)
  elseif mood == "sleep" then
    lg.ellipse("line", fx, my, u * 0.03, u * 0.02)
  else
    lg.arc("line", "open", fx, my - u * 0.03, u * 0.05, math.pi * 0.2, math.pi * 0.8)
  end
  -- bochechas
  if mood ~= "scared" then
    lg.setColor(1, 0.45, 0.55, 0.45)
    lg.ellipse("fill", fx - u * 0.33, fy + u * 0.1, u * 0.07, u * 0.04)
    lg.ellipse("fill", fx + u * 0.33, fy + u * 0.1, u * 0.07, u * 0.04)
  end
  lg.setLineWidth(1)
end

-- ---------------------------------------------------------------------------
-- especies: cada uma desenha o corpo e devolve o topo da cabeca (para o chapeu)
local SPECIES = {}

-- ---------------------------------------------------------------------------
-- Sombreamento "3D" (volume pintado em camadas): contorno escuro, degrade do
-- escuro (borda/baixo) para o claro (luz vindo de cima a esquerda), luz de
-- recorte na borda de baixo e brilho especular. Fica com cara de modelo 3D
-- sem pesar no console (so elipses e retangulos).
local LAYERS = 9
local function vol_ellipse(x, y, rx, ry, c, a)
  a = a or 1
  local o = shade(c, 0.35)
  lg.setColor(o[1], o[2], o[3], a)
  lg.ellipse("fill", x, y, rx + 1.6, ry + 1.6)
  for i = 0, LAYERS - 1 do
    local k = i / (LAYERS - 1)
    local m = 0.55 + 0.6 * k
    lg.setColor(math.min(1, c[1] * m + 0.12 * k * k), math.min(1, c[2] * m + 0.12 * k * k), math.min(1, c[3] * m + 0.12 * k * k), a)
    local s = 1 - k * 0.72
    lg.ellipse("fill", x - rx * 0.22 * k, y - ry * 0.25 * k, rx * s, ry * s)
  end
  -- luz de recorte (rim light) embaixo a direita
  lg.setColor(1, 1, 1, 0.18 * a)
  lg.arc("line", "open", x, y, rx - 1, ry - 1, math.pi * 0.05, math.pi * 0.55)
  -- especular
  lg.setColor(1, 1, 1, 0.75 * a)
  lg.ellipse("fill", x - rx * 0.4, y - ry * 0.5, rx * 0.16, ry * 0.1)
  lg.setColor(1, 1, 1, 0.35 * a)
  lg.circle("fill", x - rx * 0.18, y - ry * 0.62, math.max(1, rx * 0.05))
end

local function vol_rect(x, y, w, h, r, c, a)
  a = a or 1
  local o = shade(c, 0.35)
  lg.setColor(o[1], o[2], o[3], a)
  lg.rectangle("fill", x - 1.5, y - 1.5, w + 3, h + 3, r + 1, r + 1)
  for i = 0, LAYERS - 1 do
    local k = i / (LAYERS - 1)
    local m = 0.55 + 0.6 * k
    lg.setColor(math.min(1, c[1] * m + 0.1 * k * k), math.min(1, c[2] * m + 0.1 * k * k), math.min(1, c[3] * m + 0.1 * k * k), a)
    local ix, iy = w * 0.36 * k, h * 0.36 * k
    lg.rectangle("fill", x + ix * 0.4, y + iy * 0.35, w - ix, h - iy, math.max(1, r * (1 - k * 0.5)), math.max(1, r * (1 - k * 0.5)))
  end
  lg.setColor(1, 1, 1, 0.6 * a)
  lg.rectangle("fill", x + w * 0.12, y + h * 0.1, w * 0.3, h * 0.08, 2, 2)
end

function SPECIES.slime(cx, by, u, c, mood, t)
  local sq = anim() and math.sin(t * 3) * 0.04 or 0
  if mood == "dance" and anim() then sq = math.sin(t * 10) * 0.12 end
  local w, h = u * (0.6 + sq), u * (0.5 - sq)
  -- base achatada (gelatina apoiada no chao)
  local d = shade(c, 0.6)
  lg.setColor(d[1], d[2], d[3], 0.95)
  lg.ellipse("fill", cx, by - u * 0.05, w * 1.02, u * 0.1)
  vol_ellipse(cx, by - h * 0.95, w, h, c, 0.97)
  -- gotinha escorrendo
  vol_ellipse(cx + w * 0.78, by - h * 0.28, u * 0.07, u * 0.11, c, 0.95)
  face(cx, by - h * 0.95, u, mood, t)
  return by - h * 1.85
end

function SPECIES.robot(cx, by, u, c, mood, t)
  local d = shade(c, 0.7)
  local bob = anim() and math.sin(t * 2.4) * u * 0.02 or 0
  vol_rect(cx - u * 0.2, by - u * 0.13, u * 0.13, u * 0.13, 2, d)
  vol_rect(cx + u * 0.07, by - u * 0.13, u * 0.13, u * 0.13, 2, d)
  vol_rect(cx - u * 0.32, by - u * 0.44, u * 0.64, u * 0.33, u * 0.08, c)
  lg.setColor(0.3, 1, 0.8, 0.9)
  lg.circle("fill", cx, by - u * 0.27, u * 0.045)
  local hy = by - u * 1.0 + bob
  vol_rect(cx - u * 0.46, hy, u * 0.92, u * 0.6, u * 0.15, c)
  lg.setColor(0.05, 0.08, 0.12, 1)
  lg.rectangle("fill", cx - u * 0.36, hy + u * 0.09, u * 0.72, u * 0.42, u * 0.1, u * 0.1)
  lg.setColor(0.3, 1, 0.8, 0.08)
  lg.rectangle("fill", cx - u * 0.34, hy + u * 0.11, u * 0.68, u * 0.14, u * 0.08, u * 0.08)
  lg.setColor(d[1], d[2], d[3], 1)
  lg.setLineWidth(math.max(1, u * 0.04))
  lg.line(cx, hy, cx, hy - u * 0.16)
  lg.setLineWidth(1)
  local blink = anim() and (0.5 + 0.5 * math.sin(t * 4)) or 1
  vol_ellipse(cx, hy - u * 0.19, u * 0.055, u * 0.055, { 1, 0.3 + 0.2 * blink, 0.3 })
  face(cx, hy + u * 0.28, u * 0.9, mood, t, { 0.4, 1, 0.8 })
  return hy - u * 0.02
end

function SPECIES.cat(cx, by, u, c, mood, t)
  local d = shade(c, 0.75)
  local sw = anim() and math.sin(t * 2) * 0.25 or 0
  lg.setColor(d[1] * 0.6, d[2] * 0.6, d[3] * 0.6, 1)
  lg.setLineWidth(math.max(2, u * 0.12))
  lg.line(cx + u * 0.35, by - u * 0.12, cx + u * 0.6, by - u * 0.35 + sw * u * 0.3, cx + u * 0.55 + sw * u * 0.2, by - u * 0.6)
  lg.setColor(d[1], d[2], d[3], 1)
  lg.setLineWidth(math.max(2, u * 0.08))
  lg.line(cx + u * 0.35, by - u * 0.12, cx + u * 0.6, by - u * 0.35 + sw * u * 0.3, cx + u * 0.55 + sw * u * 0.2, by - u * 0.6)
  lg.setLineWidth(1)
  vol_ellipse(cx, by - u * 0.24, u * 0.4, u * 0.26, c)
  local hy = by - u * 0.7
  for s = -1, 1, 2 do
    local o = shade(c, 0.35)
    lg.setColor(o[1], o[2], o[3], 1)
    lg.polygon("fill", cx + s * u * 0.45, hy - u * 0.03, cx + s * u * 0.31, hy - u * 0.48, cx + s * u * 0.08, hy - u * 0.2)
    lg.setColor(c[1], c[2], c[3], 1)
    lg.polygon("fill", cx + s * u * 0.42, hy - u * 0.05, cx + s * u * 0.3, hy - u * 0.45, cx + s * u * 0.1, hy - u * 0.2)
    lg.setColor(1, 0.6, 0.7, 0.85)
    lg.polygon("fill", cx + s * u * 0.36, hy - u * 0.1, cx + s * u * 0.3, hy - u * 0.34, cx + s * u * 0.17, hy - u * 0.18)
  end
  vol_ellipse(cx, hy, u * 0.44, u * 0.34, c)
  vol_ellipse(cx - u * 0.17, by - u * 0.04, u * 0.1, u * 0.06, { 1, 1, 1 })
  vol_ellipse(cx + u * 0.17, by - u * 0.04, u * 0.1, u * 0.06, { 1, 1, 1 })
  face(cx, hy, u, mood, t)
  lg.setColor(0.12, 0.08, 0.1, 0.7)
  for s = -1, 1, 2 do
    lg.line(cx + s * u * 0.2, hy + u * 0.14, cx + s * u * 0.5, hy + u * 0.1)
    lg.line(cx + s * u * 0.2, hy + u * 0.18, cx + s * u * 0.5, hy + u * 0.22)
  end
  return hy - u * 0.3
end

function SPECIES.ghost(cx, by, u, c, mood, t)
  local fl = anim() and math.sin(t * 2) * u * 0.06 or 0
  local b = by - u * 0.1 + fl
  local g = { c[1] * 0.4 + 0.6, c[2] * 0.4 + 0.6, c[3] * 0.4 + 0.6 }
  lg.setColor(c[1], c[2], c[3], 0.25)
  lg.ellipse("fill", cx, by - 1, u * 0.35, u * 0.06)
  -- barra ondulada (quatro "dedinhos" balancando) e o corpo em gota por cima
  local n = 4
  for i = 0, n - 1 do
    local x0 = cx - u * 0.33 + i * (u * 0.22)
    local off = anim() and math.sin(t * 5 + i) * u * 0.04 or 0
    vol_ellipse(x0, b - u * 0.14 + off, u * 0.12, u * 0.14, g, 0.9)
  end
  vol_ellipse(cx, b - u * 0.5, u * 0.44, u * 0.46, g, 0.92)
  face(cx, b - u * 0.5, u * 0.95, mood, t)
  return b - u * 0.94
end

-- Caveira das sombras: cranio de osso com olhos acesos, envolta em labaredas
-- de sombra que sobem (a cor escolhida tinge as sombras e o brilho dos olhos)
function SPECIES.skull(cx, by, u, c, mood, t)
  local fl = anim() and math.sin(t * 1.8) * u * 0.04 or 0
  local hy = by - u * 0.62 + fl
  local sh = { 0.25 + c[1] * 0.35, 0.12 + c[2] * 0.2, 0.45 + c[3] * 0.4 }
  local tt = anim() and t or 0
  -- brilho de sombra (aura escura arroxeada pulsando)
  local pu = anim() and (0.7 + 0.3 * math.sin(t * 2.5)) or 0.85
  lg.setBlendMode("add")
  for g2 = 5, 1, -1 do
    lg.setColor(sh[1] * 0.5, sh[2] * 0.3, sh[3] * 0.7, 0.06 * pu)
    lg.ellipse("fill", cx, hy, u * (0.45 + g2 * 0.1), u * (0.5 + g2 * 0.12))
  end
  lg.setBlendMode("alpha")
  -- linguas de sombra subindo dos lados, mais altas que o cranio
  for s2 = -1, 1, 2 do
    for k = 0, 2 do
      local x0 = cx + s2 * u * (0.25 + k * 0.1)
      local hh = u * (1.25 + 0.3 * math.sin(tt * 3 + k + s2)) * (1 - k * 0.18)
      local sway = math.sin(tt * 2 + k * 1.7) * u * 0.1
      -- borda acesa (cor da sombra) e miolo escuro
      lg.setColor(sh[1], sh[2], sh[3], 0.75 - k * 0.15)
      lg.polygon("fill", x0 - u * 0.13, by - u * 0.06, x0 + u * 0.13, by - u * 0.06,
        x0 + s2 * u * 0.07 + sway, by - u * 0.06 - hh * 0.6, x0 + sway * 1.6, by - u * 0.06 - hh)
      lg.setColor(0.04, 0.01, 0.07, 0.9)
      lg.polygon("fill", x0 - u * 0.08, by - u * 0.06, x0 + u * 0.08, by - u * 0.06,
        x0 + s2 * u * 0.04 + sway * 0.8, by - u * 0.06 - hh * 0.5, x0 + sway * 1.3, by - u * 0.06 - hh * 0.82)
    end
  end
  -- labaredas de sombra atras
  for i = 1, 9 do
    local ph = (tt * 0.8 + i * 0.37) % 1
    local x = cx + math.sin(i * 2.1) * u * 0.42
    local y = by - u * 0.08 - ph * u * 1.1
    local r = u * (0.2 - ph * 0.14)
    lg.setColor(sh[1] * 0.5, sh[2] * 0.4, sh[3] * 0.6, 0.55 * (1 - ph))
    lg.circle("fill", x + math.sin(tt * 3 + i) * u * 0.05, y, r)
  end
  lg.setColor(0.05, 0.02, 0.08, 0.85)
  lg.ellipse("fill", cx, by - u * 0.12, u * 0.48, u * 0.14)
  for i = 0, 6 do
    local x = cx - u * 0.42 + i * u * 0.14
    local hgt = u * (0.35 + 0.15 * math.sin(tt * 4 + i * 1.3))
    lg.setColor(0.08, 0.03, 0.14, 0.9)
    lg.polygon("fill", x - u * 0.08, by - u * 0.1, x + u * 0.08, by - u * 0.1, x + math.sin(tt * 3 + i) * u * 0.05, by - u * 0.1 - hgt)
  end
  -- cranio
  local bone = { 0.93, 0.9, 0.84 }
  vol_rect(cx - u * 0.22, hy + u * 0.18, u * 0.44, u * 0.22, u * 0.06, bone)
  vol_ellipse(cx, hy, u * 0.4, u * 0.36, bone)
  -- dentes
  lg.setColor(0.25, 0.22, 0.2, 1)
  for k = -2, 2 do lg.line(cx + k * u * 0.08, hy + u * 0.24, cx + k * u * 0.08, hy + u * 0.38) end
  lg.line(cx - u * 0.2, hy + u * 0.3, cx + u * 0.2, hy + u * 0.3)
  -- orbitas e olhos acesos
  local glow = { math.min(1, sh[1] + 0.35), math.min(1, sh[2] + 0.25), 1 }
  for s = -1, 1, 2 do
    lg.setColor(0.05, 0.03, 0.08, 1)
    lg.ellipse("fill", cx + s * u * 0.16, hy + u * 0.02, u * 0.11, u * 0.1)
    local p = anim() and (0.7 + 0.3 * math.sin(t * 5 + s)) or 1
    if mood == "sleep" then
      lg.setColor(glow[1], glow[2], glow[3], 0.6)
      lg.rectangle("fill", cx + s * u * 0.16 - u * 0.06, hy + u * 0.02, u * 0.12, u * 0.02)
    elseif mood == "love" then
      heart(cx + s * u * 0.16, hy, u * 0.06, 1)
    else
      lg.setBlendMode("add")
      lg.setColor(glow[1], glow[2], glow[3], 0.35 * p)
      lg.circle("fill", cx + s * u * 0.16, hy + u * 0.02, u * 0.1)
      lg.setBlendMode("alpha")
      local r = (mood == "scared") and u * 0.025 or (mood == "happy" or mood == "dance") and u * 0.05 or u * 0.04
      lg.setColor(1, 1, 1, p)
      lg.circle("fill", cx + s * u * 0.16, hy + u * 0.02, r)
    end
  end
  lg.setColor(0.2, 0.15, 0.15, 1)
  lg.polygon("fill", cx, hy + u * 0.1, cx - u * 0.04, hy + u * 0.18, cx + u * 0.04, hy + u * 0.18)
  -- sombras na frente (enrolando o cranio)
  for i = 0, 2 do
    local a0 = tt * 1.5 + i * 2.1
    lg.setColor(sh[1] * 0.4, sh[2] * 0.3, sh[3] * 0.5, 0.55)
    lg.setLineWidth(math.max(2, u * 0.06))
    lg.arc("line", "open", cx, hy + u * 0.1, u * 0.5, a0, a0 + 1.0)
  end
  lg.setLineWidth(1)
  return hy - u * 0.34
end

-- Dragaozinho: corpo gordinho, chifres, asas batendo, barriga clara e rabo;
-- solta uma baforada de fogo quando esta feliz
function SPECIES.dragon(cx, by, u, c, mood, t)
  local d = shade(c, 0.7)
  local flap = anim() and math.sin(t * (mood == "dance" and 12 or 4)) or 0
  -- rabo
  lg.setColor(d[1], d[2], d[3], 1)
  lg.setLineWidth(math.max(2, u * 0.12))
  lg.line(cx - u * 0.3, by - u * 0.12, cx - u * 0.6, by - u * 0.1, cx - u * 0.72, by - u * 0.32)
  lg.setLineWidth(1)
  lg.polygon("fill", cx - u * 0.72, by - u * 0.32, cx - u * 0.82, by - u * 0.46, cx - u * 0.62, by - u * 0.4)
  -- asas
  for s = -1, 1, 2 do
    local wy = by - u * 0.6 - flap * u * 0.12
    local o = shade(c, 0.45)
    lg.setColor(o[1], o[2], o[3], 1)
    lg.polygon("fill", cx + s * u * 0.25, by - u * 0.5, cx + s * u * 0.78, wy - u * 0.25, cx + s * u * 0.7, wy + u * 0.05,
      cx + s * u * 0.55, wy - u * 0.02, cx + s * u * 0.45, wy + u * 0.12)
    lg.setColor(d[1], d[2], d[3], 1)
    lg.setLineWidth(math.max(1, u * 0.03))
    lg.line(cx + s * u * 0.25, by - u * 0.5, cx + s * u * 0.78, wy - u * 0.25)
    lg.setLineWidth(1)
  end
  -- corpo e barriga
  vol_ellipse(cx, by - u * 0.28, u * 0.36, u * 0.3, c)
  vol_ellipse(cx, by - u * 0.22, u * 0.2, u * 0.2, { 1, 0.9, 0.65 })
  -- pes
  vol_ellipse(cx - u * 0.18, by - u * 0.04, u * 0.1, u * 0.06, d)
  vol_ellipse(cx + u * 0.18, by - u * 0.04, u * 0.1, u * 0.06, d)
  -- cabeca, focinho e chifres
  local hy = by - u * 0.78
  for s = -1, 1, 2 do
    lg.setColor(1, 0.92, 0.7, 1)
    lg.polygon("fill", cx + s * u * 0.18, hy - u * 0.22, cx + s * u * 0.3, hy - u * 0.5, cx + s * u * 0.08, hy - u * 0.28)
  end
  vol_ellipse(cx, hy, u * 0.4, u * 0.32, c)
  vol_ellipse(cx, hy + u * 0.16, u * 0.22, u * 0.13, shade(c, 0.85))
  lg.setColor(0.12, 0.08, 0.1, 0.8)
  lg.circle("fill", cx - u * 0.06, hy + u * 0.14, u * 0.02)
  lg.circle("fill", cx + u * 0.06, hy + u * 0.14, u * 0.02)
  -- espinhos nas costas
  for k = 0, 2 do
    lg.setColor(1, 0.85, 0.5, 1)
    local yy = hy + u * 0.3 + k * u * 0.13
    lg.polygon("fill", cx + u * 0.3, yy, cx + u * 0.42, yy + u * 0.04, cx + u * 0.32, yy + u * 0.1)
  end
  face(cx, hy - u * 0.04, u * 0.95, mood, t)
  -- baforada de fogo quando feliz
  if (mood == "happy" or mood == "dance") and anim() then
    for i = 1, 5 do
      local ph = (t * 2 + i * 0.2) % 1
      lg.setColor(1, 0.6 - ph * 0.4, 0.15, 0.85 * (1 - ph))
      lg.circle("fill", cx + u * (0.3 + ph * 0.5), hy + u * 0.16 - ph * u * 0.1, u * (0.05 + ph * 0.07))
    end
  end
  return hy - u * 0.3
end

-- chapeus e acessorios (top = topo da cabeca)
local HATS = {}
function SPECIES.knight(cx, by, u, c, mood, t)
  local steel, dark = { 0.74, 0.78, 0.84 }, { 0.3, 0.32, 0.38 }
  local bob = anim() and math.sin(t * 2.2) * u * 0.015 or 0
  vol_rect(cx - u * 0.2, by - u * 0.16, u * 0.14, u * 0.16, 2, dark)
  vol_rect(cx + u * 0.06, by - u * 0.16, u * 0.14, u * 0.16, 2, dark)
  vol_rect(cx - u * 0.3, by - u * 0.5, u * 0.6, u * 0.36, u * 0.06, steel)
  vol_rect(cx - u * 0.16, by - u * 0.46, u * 0.32, u * 0.3, 2, c)
  -- escudo e espada
  vol_ellipse(cx - u * 0.38, by - u * 0.32, u * 0.15, u * 0.18, c)
  lg.setColor(0.9, 0.93, 1, 1)
  lg.rectangle("fill", cx + u * 0.34, by - u * 0.8, u * 0.05, u * 0.5)
  lg.setColor(1, 0.8, 0.25, 1)
  lg.rectangle("fill", cx + u * 0.28, by - u * 0.32, u * 0.17, u * 0.05)
  local hy = by - u * 1.0 + bob
  vol_rect(cx - u * 0.3, hy, u * 0.6, u * 0.52, u * 0.14, steel)
  lg.setColor(0.08, 0.06, 0.1, 1)
  lg.rectangle("fill", cx - u * 0.2, hy + u * 0.2, u * 0.4, u * 0.06)
  lg.rectangle("fill", cx - u * 0.025, hy + u * 0.2, u * 0.05, u * 0.18)
  lg.setColor(c[1], c[2], c[3], 1)
  lg.polygon("fill", cx - u * 0.06, hy, cx + u * 0.06, hy, cx, hy - u * 0.2)
  return hy - u * 0.05
end

function SPECIES.owl(cx, by, u, c, mood, t)
  local d = shade(c, 0.75)
  lg.setColor(d[1], d[2], d[3], 1)
  lg.polygon("fill", cx - u * 0.36, by - u * 1.0, cx - u * 0.18, by - u * 0.92, cx - u * 0.3, by - u * 1.2)
  lg.polygon("fill", cx + u * 0.36, by - u * 1.0, cx + u * 0.18, by - u * 0.92, cx + u * 0.3, by - u * 1.2)
  vol_ellipse(cx, by - u * 0.55, u * 0.42, u * 0.55, c)
  vol_ellipse(cx - u * 0.38, by - u * 0.5, u * 0.1, u * 0.26, d)
  vol_ellipse(cx + u * 0.38, by - u * 0.5, u * 0.1, u * 0.26, d)
  lg.setColor(1, 0.93, 0.78, 1)
  lg.ellipse("fill", cx, by - u * 0.35, u * 0.24, u * 0.26)
  for sx = -1, 1, 2 do
    lg.setColor(1, 0.93, 0.78, 1); lg.circle("fill", cx + sx * u * 0.15, by - u * 0.78, u * 0.15)
    lg.setColor(1, 1, 1, 1); lg.circle("fill", cx + sx * u * 0.15, by - u * 0.78, u * 0.1)
  end
  face(cx, by - u * 0.78, u * 1.3, mood, t)
  lg.setColor(1, 0.7, 0.2, 1)
  lg.polygon("fill", cx - u * 0.05, by - u * 0.7, cx + u * 0.05, by - u * 0.7, cx, by - u * 0.58)
  lg.setColor(1, 0.62, 0.2, 1)
  lg.rectangle("fill", cx - u * 0.16, by - u * 0.04, u * 0.1, u * 0.05)
  lg.rectangle("fill", cx + u * 0.06, by - u * 0.04, u * 0.1, u * 0.05)
  return by - u * 1.08
end

function HATS.nightcap(cx, top, u)
  lg.setColor(0.35, 0.45, 0.95, 1)
  lg.polygon("fill", cx - u * 0.32, top + u * 0.08, cx + u * 0.3, top + u * 0.08, cx + u * 0.5, top - u * 0.3)
  lg.setColor(1, 1, 1, 1)
  lg.rectangle("fill", cx - u * 0.34, top + u * 0.04, u * 0.66, u * 0.08, 3, 3)
  lg.circle("fill", cx + u * 0.52, top - u * 0.32, u * 0.07)
end
function HATS.beret(cx, top, u)
  lg.setColor(0.85, 0.15, 0.25, 1)
  lg.ellipse("fill", cx - u * 0.05, top + u * 0.02, u * 0.36, u * 0.12)
  lg.rectangle("fill", cx - u * 0.02, top - u * 0.12, u * 0.04, u * 0.06)
end
function HATS.headset(cx, top, u)
  lg.setColor(0.12, 0.12, 0.14, 1)
  lg.setLineWidth(math.max(2, u * 0.06))
  lg.arc("line", "open", cx, top + u * 0.3, u * 0.45, math.pi * 1.1, math.pi * 1.9)
  lg.setLineWidth(1)
  lg.setColor(0.2, 1, 0.6, 1)
  lg.rectangle("fill", cx - u * 0.52, top + u * 0.25, u * 0.14, u * 0.22, 3, 3)
  lg.rectangle("fill", cx + u * 0.38, top + u * 0.25, u * 0.14, u * 0.22, 3, 3)
end
function HATS.cap(cx, top, u)
  lg.setColor(0.2, 0.55, 1, 1)
  lg.arc("fill", "pie", cx, top + u * 0.12, u * 0.32, math.pi, 2 * math.pi)
  lg.rectangle("fill", cx, top + u * 0.06, u * 0.48, u * 0.08, 3, 3)
  lg.setColor(1, 1, 1, 1)
  lg.circle("fill", cx, top - u * 0.18, u * 0.04)
end
function HATS.antenna(cx, top, u)
  lg.setColor(0.7, 0.72, 0.78, 1)
  lg.setLineWidth(math.max(1, u * 0.04))
  lg.line(cx - u * 0.12, top + u * 0.05, cx - u * 0.24, top - u * 0.3)
  lg.line(cx + u * 0.12, top + u * 0.05, cx + u * 0.24, top - u * 0.3)
  lg.setLineWidth(1)
  local p = anim() and (0.5 + 0.5 * math.sin(App.t * 6)) or 1
  lg.setColor(0.3, 0.9, 1, 0.5 + 0.5 * p)
  lg.circle("fill", cx - u * 0.25, top - u * 0.32, u * 0.06)
  lg.circle("fill", cx + u * 0.25, top - u * 0.32, u * 0.06)
end
function HATS.bandana(cx, top, u)
  lg.setColor(0.95, 0.2, 0.2, 1)
  lg.rectangle("fill", cx - u * 0.4, top + u * 0.1, u * 0.8, u * 0.1, 3, 3)
  lg.polygon("fill", cx + u * 0.38, top + u * 0.15, cx + u * 0.6, top + u * 0.05, cx + u * 0.58, top + u * 0.28)
  lg.setColor(1, 1, 1, 0.8)
  lg.circle("fill", cx - u * 0.2, top + u * 0.15, u * 0.02)
  lg.circle("fill", cx + u * 0.05, top + u * 0.15, u * 0.02)
end
function HATS.tophat(cx, top, u)
  lg.setColor(0.08, 0.08, 0.1, 1)
  lg.rectangle("fill", cx - u * 0.36, top + u * 0.04, u * 0.72, u * 0.08, 2, 2)
  lg.rectangle("fill", cx - u * 0.22, top - u * 0.36, u * 0.44, u * 0.42, 3, 3)
  lg.setColor(0.9, 0.2, 0.3, 1)
  lg.rectangle("fill", cx - u * 0.22, top - u * 0.04, u * 0.44, u * 0.07)
end
function HATS.crown(cx, top, u)
  lg.setColor(1, 0.82, 0.2, 1)
  lg.polygon("fill", cx - u * 0.3, top + u * 0.1, cx + u * 0.3, top + u * 0.1, cx + u * 0.32, top - u * 0.22,
    cx + u * 0.15, top - u * 0.06, cx, top - u * 0.28, cx - u * 0.15, top - u * 0.06, cx - u * 0.32, top - u * 0.22)
  lg.setColor(1, 0.3, 0.4, 1)
  lg.circle("fill", cx, top - u * 0.02, u * 0.05)
end

-- ---------------------------------------------------------------------------
-- Pixel art (MascotWidget)
local SP = require("ui.digipet.sprite")
local MOOD_ANIM = { idle = "idle", happy = "happy", love = "happy", dance = "victory", scared = "hurt",
  sad = "sad", worried = "sad", sleep = "sleep" }
local anim_t0, anim_cur = 0, nil

--- o estilo pixel art esta valendo? (escolha em Meu perfil + sprite existe)
function MV.uses_pixel()
  if (M.load().quality or "pixel") == "2d" then return false end
  local okE, Evo = pcall(require, "core.mascot3d.evolution")
  if not okE then return false end
  local f = Evo.get_form(M.current("species").id)
  return f ~= nil and SP.exists(f.id)
end
MV.uses_3d = MV.uses_pixel   -- compatibilidade

--- forma atual da linha (id da forma) e a animacao conforme humor e cuidados
function MV.current_form(species)
  local Evo = require("core.mascot3d.evolution")
  local f = Evo.get_form(species or M.current("species").id)
  return f and f.id
end

function MV.pick_anim(mood)
  local c = M.anim
  if M.jump_t then return "happy" end
  if c and c.state == "walk" then return "walk" end
  if mood == "idle" then
    local okC, Care = pcall(require, "core.digipet.care")
    if okC then
      local cm = Care.mood(M.current("species").id)
      if cm == "sleep" then return "sleep" elseif cm == "sad" or cm == "tired" then return "sad" end
    end
  end
  return MOOD_ANIM[mood] or "idle"
end

--- desenha a criatura em pixel art com os pes em (cx, by)
function MV.draw_pixel(cx, by, scale, species, hat, o)
  local fid = o.form or MV.current_form(species)
  if not fid then return false end
  local an = o.anim or MV.pick_anim(o.mood or M.mood)
  if an ~= anim_cur then anim_cur, anim_t0 = an, (App and App.t) or 0 end
  local t = ((App and App.t) or 0) - (o.t0 or anim_t0)
  if not (anim() and M.anim_on()) and not o.anim then t = 0 end
  return SP.draw(fid, an, t, cx, by, scale, { flip = o.flip, hat = hat, white = o.white, black = o.black, alpha = o.alpha })
end

--- desenha o mascote com os pes em (cx, by)
function MV.draw(cx, by, sc, o)
  o = o or {}
  local st = M.load()
  local t = o.t or (App and App.t) or 0
  local species = o.species or M.current("species").id
  local color = o.color or M.current("color").id
  local hat = o.hat or M.current("hat").id
  local aura = o.aura or M.current("aura").id
  local fx = o.fx or M.current("fx").id
  local mood = o.mood or M.mood
  local u = 34 * sc
  local c = body_color(color, t, species)
  -- pulo
  local jump = o.jump or M.jump_t
  local three = not o.force2d and MV.uses_pixel()
  local pscale = o.pscale or (sc >= 1.6 and 2 or (sc >= 1.05 and 1.5 or 1))
  if jump and anim() and not three then by = by - math.sin(math.min(1, jump / 0.8) * math.pi) * u * 0.5 end
  if mood == "dance" and anim() and not three then cx = cx + math.sin(t * 8) * u * 0.12 end
  -- unidade dos efeitos em volta (aura, efeito, zzz): no 3D segue a altura
  -- real do modelo na tela; no 2D, o tamanho do desenho
  local ou = three and SP.height(MV.current_form(species) or "", pscale) or u
  -- aura
  local au = M.item("aura", aura)
  if au.rgb then
    local p = anim() and (0.6 + 0.4 * math.sin(t * 3)) or 0.8
    lg.setBlendMode("add")
    for g = 4, 1, -1 do
      lg.setColor(au.rgb[1], au.rgb[2], au.rgb[3], (three and 0.09 or 0.07) * p)
      lg.ellipse("fill", cx, by - ou * 0.5, ou * (0.5 + g * 0.11), ou * (0.55 + g * 0.1))
    end
    if three then
      -- anel no chao e faiscas subindo (energia em volta do modelo)
      lg.setColor(au.rgb[1], au.rgb[2], au.rgb[3], 0.35 * p)
      lg.setLineWidth(math.max(1, ou * 0.03))
      lg.ellipse("line", cx, by, ou * 0.62, ou * 0.12)
      lg.setLineWidth(1)
      if anim() then
        for i = 1, 8 do
          local k = ((t * 0.45) + i / 8) % 1
          local px = cx + math.sin(i * 2.4 + t) * ou * 0.55
          lg.setColor(au.rgb[1], au.rgb[2], au.rgb[3], 0.6 * (1 - k))
          lg.circle("fill", px, by - k * ou * 1.15, math.max(1, ou * 0.025))
        end
      end
    end
    lg.setBlendMode("alpha")
  end
  -- efeitos que giram em volta: metade de tras antes do modelo, a da frente depois
  local function orbit(front)
    if fx == "none" or not anim() then return end
    for i = 1, 5 do
      local a = t * 1.2 + i / 5 * math.pi * 2
      local depth = math.cos(a)            -- > 0: na frente do mascote
      if (depth >= 0) == front then
        local px, py = cx + math.sin(a) * ou * 0.72, by - ou * 0.55 + depth * ou * 0.12 + math.sin(t * 2 + i) * ou * 0.18
        local k = 0.5 + 0.5 * math.sin(t * 3 + i)
        local sz = three and (front and 1.15 or 0.75) or 1
        local al = front and 1 or 0.55
        if fx == "hearts" then heart(px, py, ou * 0.07 * sz, 0.8 * k * al)
        elseif fx == "stars" then star(px, py, ou * 0.1 * (0.6 + 0.4 * k) * sz, 0.9 * al)
        elseif fx == "coins" then
          lg.setColor(1, 0.8, 0.2, 0.95 * al); lg.ellipse("fill", px, py, ou * 0.08 * sz * math.abs(math.cos(t * 3 + i)) + 1, ou * 0.08 * sz)
        elseif fx == "flames" then
          lg.setColor(0.3, 0.7, 1, 0.7 * k * al)
          lg.polygon("fill", px - ou * 0.05 * sz, py + ou * 0.05 * sz, px + ou * 0.05 * sz, py + ou * 0.05 * sz, px, py - ou * 0.12 * (0.6 + k) * sz)
        end
      end
    end
  end
  if three then orbit(false) end
  -- sombra
  lg.setColor(0, 0, 0, 0.25)
  lg.ellipse("fill", cx, by, u * 0.42, u * 0.07)
  if three and MV.draw_pixel(cx, by, pscale, species, hat, o) then
    -- desenhado em pixel art (o pulo e a danca ja estao na animacao)
  else
    local fn = SPECIES[species] or SPECIES.slime
    local top = fn(cx, by, u, c, mood, t)
    if HATS[hat] then HATS[hat](cx, top, u) end
  end
  -- efeitos em volta (no 2D, todos na frente)
  orbit(true)
  if not three then orbit(false) end
  -- sono
  if mood == "sleep" and anim() then
    for i = 0, 2 do
      local k = ((t * 0.5) + i / 3) % 1
      G.text(T.f.pix8, "z", cx + ou * 0.4 + k * ou * 0.4, by - ou * 1.0 - k * ou * 0.6, { 1, 1, 1, 1 - k })
    end
  end
  if mood == "worried" or mood == "scared" then
    lg.setColor(0.6, 0.85, 1, 0.9)
    lg.ellipse("fill", cx + ou * 0.42, by - ou * 0.85, ou * 0.04, ou * 0.07)
  end
end

--- balao de fala acima do mascote (texto ja traduzido)
function MV.bubble(text, cx, top)
  local f = T.f.small
  local w = math.min(260, f:getWidth(text) + 16)
  local lines = select(2, f:getWrap(text, w - 14))
  local h = #lines * f:getHeight() + 10
  local x = math.max(6, math.min(T.W - w - 6, cx - w + 24))
  local y = top - h - 10
  lg.setColor(0, 0, 0, 0.35)
  lg.rectangle("fill", x + 2, y + 3, w, h, 8, 8)
  lg.setColor(1, 1, 1, 0.97)
  lg.rectangle("fill", x, y, w, h, 8, 8)
  lg.polygon("fill", cx - 6, y + h, cx + 4, y + h, cx, y + h + 8)
  for i, l in ipairs(lines) do G.text(f, l, x + 7, y + 5 + (i - 1) * f:getHeight(), { 0.12, 0.1, 0.15 }) end
end

local HIDE = { splash = true, disclaimer = true, language = true, textinput = true, padtest = true, tester = true,
  digipet = true, digigame = true, digievo = true, digidex = true }

--- mascote no canto inferior direito, em cima da barra de dicas
function MV.draw_corner()
  if not M.unlocked() or (App and App.capturing) or not M.enabled() then return end
  local where = M.get("where") or "all"
  if where == "off" then return end
  local cur = App.current and App.current()
  if not cur or HIDE[cur.name] or cur.name == "mascot" then return end
  if where == "home" and cur.name ~= "menu" then return end
  -- nao briga com a comemoracao de conquista (ela usa o mesmo canto)
  local P = package.loaded["ui.achv_popup"]
  if P and P.t0 then return end
  local k = M.SIZE_SCALE[M.get("size") or "medium"] or 1
  local cx, by = T.W - 34 * k, T.H - 34
  -- passeio: anda um pouco para a esquerda e volta (vira o sprite)
  local flip
  if M.anim and M.anim.state == "walk" then
    local tt = M.anim.t or 0
    cx = cx - math.sin(tt * 1.2) * 26
    flip = math.cos(tt * 1.2) > 0
  end
  MV.draw(cx, by, 0.85 * k, { flip = flip })
  if M.bubble then MV.bubble(M.bubble.text, cx, by - 38 * k) end
end

return MV
