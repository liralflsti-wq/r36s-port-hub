-- =============================================================================
--  Modo administrador (SO no pacote de teste: tools/build.sh --admin)
--  O build normal exclui a pasta dev/, entao a versao publica nunca tem isto.
--  Na abertura do hub: libera todas as conquistas da temporada (sem 27
--  comemoracoes seguidas), deixa a carta final "Lenda" comemorar uma vez
--  (desperta o mascote) e avisa que o modo administrador esta ativo.
--  A gravacao continua assinada com o ID deste console, como sempre.
-- =============================================================================
local Adm = {}

--- atalhos de teste no aparelho (so com este arquivo: App.admin = Adm)
--   L1: +1 nivel | R1: cumpre cuidados, treinos, interacoes e atributos
function Adm.level_up(id)
  local Evo = require("core.mascot3d.evolution")
  local lv = Evo.get_level(id)
  local t = Evo.config().total
  if t[lv + 1] then Evo.add_xp(id, t[lv + 1] - Evo.get_xp(id)) end
end

function Adm.fill(id)
  local c = require("core.digipet.care").get(id)
  c.energy, c.happiness, c.health, c.sleeping = 100, 100, 100, false
  for _, k in ipairs({ "trainings", "feeds", "plays", "pets", "minigames" }) do c.count[k] = c.count[k] + 60 end
  for _, a in ipairs({ "pow", "def", "spd", "wis" }) do c.attrs[a] = math.min(60, c.attrs[a] + 10) end
  require("core.mascot").save()
end

function Adm.run()
  App.admin = Adm
  local A = require("core.achievements")
  local missing = 0
  for _, d in ipairs(A.DEFS) do
    if not d.final and not d.id:match("^demo_") and not A.unlocked(d.id) then missing = missing + 1 end
  end
  if missing > 0 then
    local P = require("ui.achv_popup")
    local show = P.show
    P.show = function() end
    for _, d in ipairs(A.DEFS) do
      if not d.final and not d.id:match("^demo_") then A.unlock(d.id) end
    end
    P.show = show
    A.check_final()   -- "Lenda": comemora uma vez e libera o mascote
  end
  pcall(function() App.toast("Modo administrador: tudo liberado para teste", "ok") end)
end

return Adm
