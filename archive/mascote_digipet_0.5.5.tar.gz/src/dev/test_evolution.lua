-- =============================================================================
--  Testes do EvolutionManager (so no build --dev / autotest: "evotest")
--  Usa um mascot.json temporario e devolve o original no fim.
-- =============================================================================
local T = {}

function T.run()
  local M = require("core.mascot")
  local Evo = require("core.mascot3d.evolution")
  local json = require("lib.json")
  local backup = love.filesystem.read("mascot.json")
  local pass, fail = 0, 0
  local function check(name, cond)
    if cond then pass = pass + 1 else fail = fail + 1 end
    print(string.format("[evotest] %s %s", cond and "OK  " or "FALHA", name))
  end
  local function reset(data)
    love.filesystem.write("mascot.json", json.encode(data or {}))
    M.reload(); Evo._checked = nil
  end
  -- formula
  local cfg = Evo.config()
  local mono = true
  for n = 2, 60 do if Evo.xp_for(n) < Evo.xp_for(n - 1) then mono = false end end
  check("XP por nivel nunca diminui", mono)
  check("nivel 1 com 0 XP", Evo.level_for_xp(0) == 1)
  check("nivel 10 no total[10]", Evo.level_for_xp(cfg.total[10]) == 10 and Evo.level_for_xp(cfg.total[10] - 1) == 9)
  check("estagios 1/2/3/4/5 nos niveis 9/10/20/35/50",
    Evo.stage_for_level(9) == 1 and Evo.stage_for_level(10) == 2 and Evo.stage_for_level(20) == 3
    and Evo.stage_for_level(35) == 4 and Evo.stage_for_level(50) == 5 and Evo.stage_for_level(99) == 5)
  print(string.format("[evotest] XP total p/ estagios: 2=%d 3=%d 4=%d 5=%d", cfg.total[10], cfg.total[20], cfg.total[35], cfg.total[50]))
  -- ganho de XP e protecoes
  reset({ species = "slime" })
  check("XP negativo ignorado", Evo.add_xp("slime", -50) == 0 and Evo.get_xp("slime") == 0)
  check("XP zero ignorado", Evo.add_xp("slime", 0) == 0)
  check("ganha XP", Evo.add_xp("slime", 30) == 30 and Evo.get_xp("slime") == 30)
  local got = 0
  for i = 1, 10 do got = got + Evo.add_xp("slime", 2, "pet") end
  check("limite diario do carinho (5x)", got == 10)
  check("recompensa unica nao repete", Evo.add_xp("slime", 25, "achievement", "x") == 25 and Evo.add_xp("slime", 25, "achievement", "x") == 0)
  check("chave diferente paga", Evo.add_xp("slime", 25, "achievement", "y") == 25)
  check("cada mascote tem seu XP", Evo.get_xp("robot") == 0)
  -- mudanca de estagio (arvore da linha slime: gotti -> borbulho -> ...)
  local Care = require("core.digipet.care")
  Evo.add_xp("slime", cfg.total[10])
  check("nivel 10+ deixa evoluir", Evo.get_level("slime") >= 10 and Evo.can_evolve("slime") ~= false)
  check("estagio so muda na evolucao", Evo.get_stage("slime") == 1 and Evo.get_form("slime").id == "gotti")
  local ok1 = Evo.evolve("slime")
  local ok2 = Evo.evolve("slime")
  check("evolui para a forma 2 (Borbulho)", ok1 and Evo.get_form("slime").id == "borbulho" and Evo.get_stage("slime") == 2)
  check("nao evolui duas vezes", not ok2 and Evo.get_stage("slime") == 2)
  check("historico registrado", #Evo.history("slime") == 1 and Evo.history("slime")[1].to_form == "borbulho")
  check("forma descoberta", Evo.discovered("slime", "borbulho") and not Evo.discovered("slime", "cristalgo"))
  -- ramificacao no nivel 20: sem requisitos nao evolui antes do 25
  Evo.add_xp("slime", cfg.total[20] - Evo.get_xp("slime"))
  local c = Care.get("slime")
  c.happiness, c.count.pets, c.count.plays, c.count.feeds, c.count.trainings = 30, 0, 0, 0, 0
  check("nivel 20 sem treino/cuidado: espera", Evo.can_evolve("slime") == false)
  c.happiness, c.count.pets = 80, 60
  local tgt = Evo.can_evolve("slime")
  check("ramo do cuidado -> Lamaroth", tgt and tgt.id == "lamaroth")
  c.happiness, c.count.pets, c.count.trainings = 30, 0, 15
  tgt = Evo.can_evolve("slime")
  check("ramo do treino -> Cristalgo", tgt and tgt.id == "cristalgo")
  c.count.trainings = 0
  Evo.add_xp("slime", cfg.total[25] - Evo.get_xp("slime"))
  tgt = Evo.can_evolve("slime")
  check("nivel 25: caminho natural -> Cristalgo", tgt and tgt.id == "cristalgo")
  Evo.evolve("slime")
  -- suprema exige saude e atributo principal (defesa 15)
  Evo.add_xp("slime", cfg.total[35] - Evo.get_xp("slime"))
  c.health = 30
  check("suprema exige saude", Evo.can_evolve("slime") == false)
  c.health = 90; c.attrs.def = 0
  check("suprema exige atributo", Evo.can_evolve("slime") ~= false)   -- base do Cristalgo ja tem 15
  -- cuidados: queda lenta sem morte
  local c2 = Care.get("robot")
  c2.energy, c2.happiness, c2.health, c2.t = 50, 50, 80, os.time() - 30 * 86400
  Care.tick("robot")
  check("queda lenta: nunca abaixo dos minimos", c2.energy >= 10 and c2.happiness >= 10 and c2.health >= 30)
  local okf = Care.feed("robot")
  check("alimentar sobe energia", okf and c2.energy >= 35 and c2.count.feeds == 1)
  local before = c2.attrs.pow
  Care.train("robot", "pow")
  check("treinar sobe o atributo", c2.attrs.pow == before + 1 and c2.count.trainings == 1)
  Care.minigame("robot", "wis", true)
  check("minigame vencido: sabedoria +2", c2.attrs.wis == 2 and c2.count.minigames == 1)
  -- salvamento e recuperacao
  M.reload(); Evo._checked = nil
  check("progresso salvo apos reabrir", Evo.get_form("slime").id == "cristalgo" and Evo.get_level("slime") >= 25
    and require("core.digipet.care").get("robot").count.feeds == 1)
  M.set("species", "robot")
  check("trocar de mascote preserva o outro", Evo.get_stage("slime") == 3 and Evo.get_stage("robot") == 1)
  -- sprites: todas as formas tem folha e sao diferentes entre si
  local Dex = require("core.digipet.dex")
  local SP = require("ui.digipet.sprite")
  local all, sizes, dup = true, {}, false
  for _, ln in ipairs(Dex.lines()) do
    for _, f in ipairs(ln.forms) do
      if not SP.exists(f.id) then all = false; print("[evotest] sem sprite:", f.id) end
      local sz = love.filesystem.getInfo(SP.DIR .. f.id .. ".png")
      sz = sz and sz.size or 0
      if sizes[sz] then dup = true end
      sizes[sz] = true
    end
  end
  check("as 48 formas tem sprite", all and Dex.count() == 48)
  check("nenhuma folha de sprite repetida", not dup)
  -- migracao do nivel antigo (0.5.5 antes da evolucao)
  reset({ species = "cat", xp = 90 })   -- nivel antigo 4
  check("migracao mantem o nivel antigo", Evo.get_level("cat") == 4)
  -- dados corrompidos
  reset({ species = "owl", evo = { version = 1, mascots = { owl = { xp = -9, stage = 99, unlocked = "x", history = 3 }, [5] = 1 } } })
  check("dados corrompidos corrigidos", Evo.get_xp("owl") == 0 and Evo.get_form("owl") ~= nil and type(Evo.history("owl")) == "table")
  -- devolve o arquivo original
  if backup then love.filesystem.write("mascot.json", backup) else love.filesystem.remove("mascot.json") end
  M.reload(); Evo._checked = nil
  print(string.format("[evotest] RESULTADO: %d ok, %d falhas", pass, fail))
  return fail == 0
end

return T
