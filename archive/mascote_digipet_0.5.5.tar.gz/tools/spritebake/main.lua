-- =============================================================================
--  Gerador de sprites pixel art das criaturas (roda no PC, nao vai pro console)
--  Le assets/digipets/creatures.json + os modelos .glb (tools/mascot_src) e
--  "fotografa" cada forma em 80x80 com camera ortografica, quadro a quadro,
--  em 10 animacoes. Depois: paleta retro limitada + contorno de 1 pixel.
--  Saida (pasta de dados do LOVE): sprites/<forma>.png + .json, hats/<id>.png
--  Uso: tools/bake_sprites.sh
-- =============================================================================
local Loader = require("core.mascot3d.loader")
local R = require("core.mascot3d.render")
local json = require("lib.json")

local S = 80                 -- tamanho do quadro
local ORTHO = 1.2            -- meia altura visivel (unidades): ~33 px por unidade
local FOOT = 0.18            -- margem abaixo dos pes (unidades)
local YAW = -0.5
local tau = math.pi * 2

-- paleta original de 32 cores (LCD colorido de portatil retro)
local HEX = { "141020", "2b1d3a", "4a2c5e", "7a3c7a", "b5487a", "e6667a", "ff9a6b", "ffd26b",
  "fff4c2", "c7f07a", "6fcf5a", "2f9e5a", "1f6b5e", "1d3f5c", "2a5ea8", "3f8fe6",
  "6ec6ff", "b8f1ff", "ffffff", "c9ccd6", "8a8fa3", "565a70", "33364a", "7a4a2e",
  "b8743c", "e8b06a", "f5d6a0", "a3202f", "e83a3a", "ff7ab8", "9d6bff", "5a3ad0" }
local PAL = {}
for _, h in ipairs(HEX) do
  PAL[#PAL + 1] = { tonumber(h:sub(1, 2), 16) / 255, tonumber(h:sub(3, 4), 16) / 255, tonumber(h:sub(5, 6), 16) / 255 }
end
local cache = {}
local function nearest(r, g, b)
  local k = math.floor(r * 31) * 1024 + math.floor(g * 31) * 32 + math.floor(b * 31)
  if cache[k] then return cache[k] end
  local best, bd = PAL[1], 1e9
  for _, c in ipairs(PAL) do
    local dr, dg, db = c[1] - r, c[2] - g, c[3] - b
    local rm = (c[1] + r) / 2
    local d = (2 + rm) * dr * dr + 4 * dg * dg + (3 - rm) * db * db
    if d < bd then bd, best = d, c end
  end
  cache[k] = best
  return best
end

-- --------------------------------------------------------------- poses (ciclicas)
local sin, cos, abs, pi = math.sin, math.cos, math.abs, math.pi
local function q(P, n) P[n] = P[n] or {}; return P[n] end
local function add(P, n, k, v) local x = q(P, n); x[k] = (x[k] or 0) + v end
local function mul(P, n, k, v) local x = q(P, n); x[k] = (x[k] or 1) * v end

local function base(P, p, cfg, breathe)
  local b = sin(tau * p)
  mul(P, "body", "sy", 1 + (breathe or 0.03) * b)
  mul(P, "body", "sx", 1 - 0.012 * b)
  for i = 1, 80 do
    add(P, "orbit_" .. i, "ry", tau * p + i * 0.3)
    add(P, "spin_" .. i, "ry", tau * p)
    mul(P, "pulse_" .. i, "s", 1 + 0.12 * sin(tau * p * 2 + i))
    mul(P, "smoke_" .. i, "s", 1)
    add(P, "smoke_" .. i, "ry", tau * p + i)
  end
  if cfg.float then add(P, "root", "ty", 0.06 + 0.035 * sin(tau * p)) end
  -- olhos e boca maiores: o rosto precisa ler bem em poucos pixels
  for _, e in ipairs({ "eye_l", "eye_r" }) do mul(P, e, "sx", 1.55); mul(P, e, "sy", 1.55); mul(P, e, "sz", 1.3) end
  mul(P, "mouth", "s", 1.4)
end

local function eyes_closed(P) for _, e in ipairs({ "eye_l", "eye_r" }) do mul(P, e, "sy", 0.15) end end
local function eyes_happy(P) for _, e in ipairs({ "eye_l", "eye_r" }) do mul(P, e, "sy", 0.4); add(P, e, "ty", 0.01) end end

local function hop(P, p, h)
  local up = sin(math.max(0, math.min(1, (p - 0.15) / 0.7)) * pi)
  local sq = p < 0.15 and p / 0.15 or (p > 0.85 and (1 - p) / 0.15 or 0)
  add(P, "root", "ty", up * h)
  mul(P, "root", "sy", 1 - sq * 0.12 + up * 0.05)
  mul(P, "root", "sx", 1 + sq * 0.07)
  return up
end

local ANIMS = {
  { "idle", 8, 6, true, function(P, p, cfg)
    base(P, p, cfg)
    add(P, "head", "rz", sin(tau * p) * 0.05)
    add(P, "arm_l", "rz", -0.06 * sin(tau * p)); add(P, "arm_r", "rz", 0.06 * sin(tau * p))
    for _, t in ipairs({ "tail", "tail2", "tail3" }) do add(P, t, "ry", sin(tau * p) * 0.35) end
    add(P, "wing_l", "ry", sin(tau * p) * 0.12); add(P, "wing_r", "ry", -sin(tau * p) * 0.12)
    add(P, "cape", "rx", -0.05 - sin(tau * p) * 0.05)
    if p >= 0.74 and p < 0.87 then eyes_closed(P) end
  end },
  { "walk", 8, 10, true, function(P, p, cfg)
    base(P, p, cfg)
    local w = tau * p
    add(P, "root", "ty", abs(sin(w)) * 0.04); add(P, "root", "rz", sin(w) * 0.06)
    add(P, "leg_l", "rx", sin(w) * 0.6); add(P, "leg_r", "rx", -sin(w) * 0.6)
    add(P, "arm_l", "rx", -sin(w) * 0.6); add(P, "arm_r", "rx", sin(w) * 0.6)
    add(P, "tail", "ry", sin(w) * 0.4)
    if cfg.blob then mul(P, "body", "sy", 1 + sin(w * 2) * 0.06) end
  end },
  { "happy", 6, 9, true, function(P, p, cfg)
    base(P, p, cfg)
    local up = hop(P, p, 0.2)
    add(P, "arm_l", "rz", -1.8 * up - 0.4); add(P, "arm_r", "rz", 1.8 * up + 0.4)
    add(P, "wing_l", "ry", 0.5 * up); add(P, "wing_r", "ry", -0.5 * up)
    eyes_happy(P)
  end },
  { "sad", 6, 5, true, function(P, p, cfg)
    base(P, p, cfg, 0.015)
    add(P, "head", "rx", 0.32); add(P, "head", "rz", sin(tau * p) * 0.03)
    add(P, "arm_l", "rz", 0.15); add(P, "arm_r", "rz", -0.15)
    add(P, "ear_l", "rz", 0.4); add(P, "ear_r", "rz", -0.4)
    add(P, "wing_l", "rz", 0.25); add(P, "wing_r", "rz", -0.25)
    for _, e in ipairs({ "eye_l", "eye_r" }) do mul(P, e, "sy", 0.65); add(P, e, "ty", -0.012) end
  end },
  { "sleep", 6, 4, true, function(P, p, cfg)
    base(P, p, cfg, 0.05)
    add(P, "head", "rx", 0.35); add(P, "head", "rz", 0.14); add(P, "root", "rz", 0.05)
    add(P, "arm_l", "rz", 0.15); add(P, "arm_r", "rz", -0.15)
    add(P, "tail", "ry", 0.6)
    eyes_closed(P)
  end },
  { "eat", 6, 9, true, function(P, p, cfg)
    base(P, p, cfg)
    local k = abs(sin(tau * p))
    add(P, "head", "rx", 0.4 * k); add(P, "root", "rx", 0.08 * k)
    mul(P, "mouth", "sy", 1 + 2.5 * k)
    if k > 0.7 then eyes_happy(P) end
  end },
  { "attack", 6, 10, false, function(P, p, cfg)
    base(P, p, cfg)
    local wind = p < 0.35 and p / 0.35 or 0
    local hit = p >= 0.35 and sin(math.min(1, (p - 0.35) / 0.5) * pi) or 0
    add(P, "root", "tz", -0.08 * wind + 0.28 * hit)
    add(P, "root", "rx", 0.12 * wind - 0.25 * hit)
    add(P, "arm_r", "rz", 1.2 * wind - 0.4 * hit); add(P, "arm_r", "rx", -1.4 * hit)
    add(P, "wing_l", "ry", 0.6 * hit); add(P, "wing_r", "ry", -0.6 * hit)
    add(P, "tail", "ry", 0.8 * hit)
  end },
  { "hurt", 4, 10, false, function(P, p, cfg)
    base(P, p, cfg)
    local k = sin(math.min(1, p / 0.6) * pi)
    add(P, "root", "tz", -0.15 * k); add(P, "root", "rx", 0.25 * k); add(P, "root", "rz", 0.12 * k)
    add(P, "arm_l", "rz", -0.8 * k); add(P, "arm_r", "rz", 0.8 * k)
    eyes_closed(P)
  end },
  { "evolution", 8, 12, true, function(P, p, cfg)
    base(P, p, cfg)
    add(P, "root", "ry", tau * p)
    add(P, "root", "ty", 0.08 + 0.05 * sin(tau * p))
    add(P, "arm_l", "rz", -2.2); add(P, "arm_r", "rz", 2.2)
    add(P, "wing_l", "ry", 0.5); add(P, "wing_r", "ry", -0.5)
    eyes_closed(P)
  end },
  { "victory", 8, 10, true, function(P, p, cfg)
    base(P, p, cfg)
    local up = hop(P, (p * 2) % 1, 0.16)
    add(P, "root", "ry", sin(tau * p) * 0.5)
    add(P, "arm_r", "rz", 2.4 + sin(tau * p * 4) * 0.25); add(P, "arm_l", "rz", -0.6 - up)
    add(P, "wing_l", "ry", sin(tau * p * 4) * 0.5); add(P, "wing_r", "ry", -sin(tau * p * 4) * 0.5)
    eyes_happy(P)
  end },
}

-- --------------------------------------------------------------- render + pixel
local function cam(aspect)
  return { ortho = S / 2 / (S / (2 * ORTHO)), aspect = 1, yaw = YAW, pitch = 0.18,
    target_y = ORTHO - FOOT, dist = 6 }
end

local function snap(model, pose, tint)
  local o = cam()
  o.ortho = ORTHO
  local c = R.render("snap", S, S, 4, function(w, h)
    R.draw(model, pose, { tint = tint, yaw = YAW, aspect = 1, ortho = ORTHO, dist = o.dist, target_y = o.target_y,
      pitch = o.pitch, outline = false })
  end)
  -- 4x supersample -> media por bloco -> paleta -> contorno
  local big = c:newImageData()
  local out = love.image.newImageData(S, S)
  for y = 0, S - 1 do
    for x = 0, S - 1 do
      local r, g, b, a, n = 0, 0, 0, 0, 0
      for yy = 0, 3 do
        for xx = 0, 3 do
          local pr, pg, pb, pa = big:getPixel(x * 4 + xx, y * 4 + yy)
          if pa > 0.4 then r, g, b, n = r + pr, g + pg, b + pb, n + 1 end
        end
      end
      if n >= 6 then
        local p = nearest(r / n, g / n, b / n)
        out:setPixel(x, y, p[1], p[2], p[3], 1)
      end
    end
  end
  local ink = PAL[1]
  local res = love.image.newImageData(S, S)
  for y = 0, S - 1 do
    for x = 0, S - 1 do
      local _, _, _, a = out:getPixel(x, y)
      if a > 0 then res:setPixel(x, y, out:getPixel(x, y))
      else
        for _, d in ipairs({ { 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 } }) do
          local nx, ny = x + d[1], y + d[2]
          if nx >= 0 and ny >= 0 and nx < S and ny < S and select(4, out:getPixel(nx, ny)) > 0 then
            res:setPixel(x, y, ink[1], ink[2], ink[3], 1); break
          end
        end
      end
    end
  end
  local hx, hy = R.locate(model, pose, { yaw = YAW, aspect = 1, ortho = ORTHO, dist = o.dist, target_y = o.target_y, pitch = o.pitch },
    "hat_anchor", S, S)
  return res, hx and math.floor(hx + 0.5) or nil, hy and math.floor(hy + 0.5) or nil
end

local function bake_form(fm, line)
  local model, err = Loader.load("models/" .. fm.model .. ".glb")
  if not model then print("ERRO", fm.id, err); return end
  local cfg = { float = (line.id == "ghost" or line.id == "skull"), blob = (line.id == "slime") }
  local cols = 8
  local sheet = love.image.newImageData(S * cols, S * #ANIMS)
  local meta = { size = S, anims = {}, hat = {} }
  for row, a in ipairs(ANIMS) do
    local name, n, fps, loop, fn = a[1], a[2], a[3], a[4], a[5]
    meta.anims[name] = { row = row - 1, frames = n, fps = fps, loop = loop }
    meta.hat[name] = {}
    for i = 0, n - 1 do
      local P = {}
      fn(P, i / n, cfg)
      local img, hx, hy = snap(model, P, fm.tint)
      sheet:paste(img, i * S, (row - 1) * S, 0, 0, S, S)
      meta.hat[name][i + 1] = { hx or S / 2, hy or 10 }
    end
  end
  love.filesystem.createDirectory("sprites")
  sheet:encode("png", "sprites/" .. fm.id .. ".png")
  love.filesystem.write("sprites/" .. fm.id .. ".json", json.encode(meta))
  Loader.unload("models/" .. fm.model .. ".glb")
  print("ok", fm.id)
end

local function bake_hats()
  local model = Loader.load("models/hats.glb")
  love.filesystem.createDirectory("hats")
  for _, p in ipairs(model.parts) do
    if p.mesh then
      local single = { parts = {}, by_name = {} }
      local root = { name = "root", t = { 0, 0, 0 }, extras = {} }
      local part = { name = p.name, parent = root, t = { 0, 0, 0 }, mesh = p.mesh, extras = {} }
      single.parts = { root, part }
      single.by_name = { root = root, [p.name] = part, hat_anchor = root }
      -- chapeu centrado: pivo (base) no meio do quadro de 40x40
      local SZ = 40
      local c = R.render("hat", SZ, SZ, 4, function()
        R.draw(single, { root = { s = 0.85 } }, { yaw = YAW, aspect = 1, ortho = 0.6, dist = 6, target_y = 0.12, pitch = 0.18 })
      end)
      local big = c:newImageData()
      local out = love.image.newImageData(SZ, SZ)
      for y = 0, SZ - 1 do for x = 0, SZ - 1 do
        local r, g, b, n = 0, 0, 0, 0
        for yy = 0, 3 do for xx = 0, 3 do
          local pr, pg, pb, pa = big:getPixel(x * 4 + xx, y * 4 + yy)
          if pa > 0.4 then r, g, b, n = r + pr, g + pg, b + pb, n + 1 end
        end end
        if n >= 6 then local q2 = nearest(r / n, g / n, b / n); out:setPixel(x, y, q2[1], q2[2], q2[3], 1) end
      end end
      out:encode("png", "hats/" .. p.name .. ".png")
    end
  end
  print("ok chapeus")
end

function love.load()
  local data = json.decode(love.filesystem.read("creatures.json"))
  local only = os.getenv("BAKE_ONLY")
  if only == "" then only = nil end
  for _, line in ipairs(data.lines) do
    for _, fm in ipairs(line.forms) do
      if not only or only:find(fm.id, 1, true) or only == line.id then bake_form(fm, line) end
    end
  end
  if not only then bake_hats() end
  love.event.quit()
end
