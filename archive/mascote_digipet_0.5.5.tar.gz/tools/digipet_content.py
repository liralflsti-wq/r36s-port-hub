#!/usr/bin/env python3
# =============================================================================
#  Conteudo das criaturas digitais do R36S PORT HUB (arte e nomes originais)
#  Gera: src/assets/digipets/creatures.json
#  Cada LINHA (as 8 especies do mascote) tem 6 formas:
#    tier 1 Inicial -> 2 Intermediaria -> 3 Avancada (ramo treino)
#                                      -> 3 Alternativa (ramo cuidado)
#    -> 4 Suprema (de qualquer avancada) -> 5 Secreta (requisito especial)
#  Raridade e independente do estagio (comum, incomum, epica, lendaria, unica).
#  Textos em portugues; as traducoes ficam em i18n/en.lua e ru.lua
#  (tools/digipet_i18n.py). Uso: python3 tools/digipet_content.py
# =============================================================================
import json, os

ATTRS = ["pow", "def", "spd", "wis"]

def form(fid, name, tier, branch, rarity, element, model, tint, skill, desc, story, stats):
    return {"id": fid, "name": name, "tier": tier, "branch": branch, "rarity": rarity, "element": element,
            "model": model, "tint": tint, "skill": skill, "desc": desc, "story": story,
            "stats": dict(zip(ATTRS, stats))}

def line(lid, name, element, card, main_attr, special, special_hint, forms):
    f = forms
    # arvore: 1 -> 2 -> (3 treino | alt cuidado) -> 4 -> secreta
    f[0]["evolves"] = [{"to": f[1]["id"], "req": {"level": 10}}]
    f[1]["evolves"] = [
        {"to": f[2]["id"], "req": {"level": 20, "trainings": 15}, "path": "treino"},
        {"to": f[3]["id"], "req": {"level": 20, "happiness": 70, "care": 60}, "path": "cuidado"},
        {"to": f[2]["id"], "req": {"level": 25}, "path": "padrao"},
    ]
    sup = {"to": f[4]["id"], "req": {"level": 35, "health": 60, "attr": {main_attr: 15}}}
    f[2]["evolves"] = [sup]
    f[3]["evolves"] = [dict(sup)]
    sec = {"level": 50, "happiness": 90, "attr_sum": 100}
    sec.update(special)
    f[4]["evolves"] = [{"to": f[5]["id"], "req": sec, "secret": True, "hint": special_hint}]
    f[5]["evolves"] = []
    return {"id": lid, "name": name, "element": element, "card": card, "main_attr": main_attr, "forms": f}

R = {"c": "common", "u": "uncommon", "e": "epic", "l": "legendary", "x": "unique"}

LINES = [
  line("slime", "Linha Gotti", "Água", "legend", "def", {"feeds": 150},
       "Quem nunca recusa um petisco descobre o céu.", [
    form("gotti", "Gotti", 1, "main", R["c"], "Água", "slime/stage-1", [1.0, 0.55, 0.20], "Pulo Gelatinoso",
         "Uma gotinha de gelatina que quica de alegria.", "Nasceu de uma gota de orvalho que caiu num cartão SD esquecido.", [3, 6, 2, 3]),
    form("borbulho", "Borbulho", 2, "main", R["c"], "Água", "slime/stage-2", [1.0, 0.45, 0.55], "Rajada de Bolhas",
         "Solta bolhas quando fica animado.", "Aprendeu a borbulhar ouvindo o som dos downloads.", [5, 9, 4, 5]),
    form("cristalgo", "Cristalgo", 3, "main", R["u"], "Água", "slime/stage-3", [0.45, 0.8, 1.0], "Prisma Refletor",
         "Tem um núcleo de cristal que guarda luz.", "O treino endureceu seu coração em cristal puro.", [9, 15, 6, 9]),
    form("lamaroth", "Lamaroth", 3, "alt", R["e"], "Terra", "slime/alt", [0.55, 0.45, 0.3], "Esporos Calmantes",
         "Vive tranquilo, cultivando cogumelos nas costas.", "De tanto carinho, criou raízes num pântano macio.", [7, 13, 4, 12]),
    form("rei_gelatus", "Rei Gelatus", 4, "main", R["e"], "Água", "slime/stage-4", [0.95, 0.45, 0.25], "Decreto Real",
         "Governa com coroa, capa e um cetro de joia.", "Foi coroado por todas as gotinhas do reino.", [13, 22, 9, 14]),
    form("celestgota", "Celestgota", 5, "secret", R["x"], "Luz", "slime/stage-5", [0.7, 0.9, 1.0], "Chuva Estelar",
         "Asas de cristal e uma auréola dourada.", "Dizem que uma gota subiu ao céu e voltou como estrela.", [18, 30, 14, 22]),
  ]),
  line("robot", "Linha Bipo", "Elétrico", "ftp_transfer", "pow", {"minigames": 40},
       "Vencer jogos aquece os circuitos certos.", [
    form("bipo", "Bipo", 1, "main", R["c"], "Elétrico", "robot/stage-1", [0.3, 0.62, 1.0], "Choque Bip",
         "Um robozinho curioso que pisca a antena.", "Foi montado com peças de um console antigo.", [5, 5, 3, 3]),
    form("parafusao", "Parafusão", 2, "main", R["u"], "Metal", "robot/stage-2", [0.25, 0.75, 0.68], "Chave Giratória",
         "Conserta tudo com a sua chave inglesa.", "Ganhou ferramentas ajudando a instalar ports.", [8, 9, 4, 6]),
    form("jatobot", "Jatobot", 3, "main", R["u"], "Elétrico", "robot/stage-3", [0.92, 0.92, 0.96], "Turbo Jato",
         "Voa curtinho com a mochila a jato.", "O treino de velocidade fundiu propulsores nas costas.", [13, 12, 11, 7]),
    form("engrenix", "Engrenix", 3, "alt", R["e"], "Terra", "robot/alt", [1.0, 0.75, 0.15], "Broca Tremor",
         "Cava túneis com broca e anda de esteira.", "Cuidado e paciência o tornaram um construtor.", [12, 16, 5, 9]),
    form("mechaguarda", "Mechaguarda", 4, "main", R["e"], "Metal", "robot/stage-4", [0.38, 0.42, 0.58], "Canhão Guardião",
         "Blindagem pesada e um canhão de energia.", "Protege o cartão SD de qualquer arquivo corrompido.", [22, 20, 10, 11]),
    form("titanucleo", "Titanúcleo", 5, "secret", R["x"], "Luz", "robot/stage-5", [0.35, 0.75, 1.0], "Núcleo Supremo",
         "Um núcleo de energia pulsa no peito.", "Despertou depois de vencer quarenta desafios.", [32, 26, 18, 20]),
  ]),
  line("cat", "Linha Miauzi", "Natureza", "favorite", "spd", {"pets": 200},
       "Um gato só revela a lua para quem afaga sem cansar.", [
    form("miauzi", "Miauzi", 1, "main", R["c"], "Natureza", "cat/stage-1", [0.78, 0.55, 0.35], "Arranhão Fofo",
         "Preguiçoso e carinhoso, adora um cafuné.", "Apareceu dormindo em cima da pasta de ports.", [4, 3, 6, 3]),
    form("andarilho", "Andarilho", 2, "main", R["c"], "Natureza", "cat/stage-2", [0.62, 0.64, 0.7], "Corrida Ágil",
         "Explora tudo com o seu lenço vermelho.", "Saiu de casa para conhecer cada menu do hub.", [7, 5, 10, 5]),
    form("bicaudo", "Bicaudo", 3, "main", R["u"], "Fogo", "cat/stage-3", [0.6, 0.45, 0.75], "Chama Gêmea",
         "Duas caudas com chamas azuis nas pontas.", "O treino acendeu um fogo frio em suas caudas.", [11, 8, 16, 9]),
    form("folhagato", "Folhagato", 3, "alt", R["u"], "Natureza", "cat/alt", [0.55, 0.75, 0.4], "Pólen Sonolento",
         "Coroa de flores e cauda de cipó.", "Tanto carinho fez florescer um jardim nele.", [8, 9, 12, 12]),
    form("guardigato", "Guardigato", 4, "main", R["e"], "Metal", "cat/stage-4", [0.98, 0.78, 0.35], "Garras de Aço",
         "Peitoral, tiara e três caudas.", "Jurou proteger quem lhe dá carinho.", [16, 14, 24, 13]),
    form("lunarix", "Lunarix", 5, "secret", R["x"], "Luz", "cat/stage-5", [0.85, 0.8, 1.0], "Eclipse Lunar",
         "Uma lua crescente brilha atrás da cabeça.", "Só aparece para quem fez duzentos afagos.", [22, 18, 34, 22]),
  ]),
  line("ghost", "Linha Bubu", "Espírito", "first_error", "wis", {"night": True},
       "Quando o relógio dorme, os espíritos acordam.", [
    form("bubu", "Bubu", 1, "main", R["u"], "Espírito", "ghost/stage-1", [0.9, 0.88, 1.0], "Susto Leve",
         "Tímido: assusta e logo pede desculpas.", "Nasceu do primeiro erro do sistema e ficou para ajudar.", [3, 3, 4, 6]),
    form("lanterninha", "Lanterninha", 2, "main", R["u"], "Espírito", "ghost/stage-2", [1.0, 0.95, 0.72], "Luz Guia",
         "Carrega uma lanterna para não se perder.", "Achou a lanterna num menu escuro de configurações.", [5, 5, 6, 10]),
    form("fatuel", "Fatuel", 3, "main", R["e"], "Fogo", "ghost/stage-3", [0.62, 0.8, 1.0], "Fogo-Fátuo",
         "Chamas azuis giram à sua volta.", "O treino transformou medo em fogo azul.", [9, 7, 9, 16]),
    form("travessombra", "Travessombra", 3, "alt", R["e"], "Sombra", "ghost/alt", [0.95, 0.85, 1.0], "Truque de Máscara",
         "Usa máscara e chapéu de bufão.", "Ficou tão feliz que virou o palhaço da meia-noite.", [7, 6, 13, 14]),
    form("espectrei", "Espectrei", 4, "main", R["l"], "Sombra", "ghost/stage-4", [0.8, 0.75, 1.0], "Corrente Real",
         "Coroa de chifres e correntes que tilintam.", "Reina sobre todos os fantasmas do cartão SD.", [14, 12, 14, 24]),
    form("aurorin", "Aurorin", 5, "secret", R["x"], "Luz", "ghost/stage-5", [0.75, 1.0, 0.95], "Véu da Aurora",
         "Asas etéreas que mudam de cor.", "Surgiu numa madrugada silenciosa, junto da aurora.", [20, 18, 22, 34]),
  ]),
  line("skull", "Linha Ossinho", "Sombra", "restore", "wis", {"album": True},
       "Só quem completou o álbum encara o soberano.", [
    form("ossinho", "Ossinho", 1, "main", R["e"], "Sombra", "skull/stage-1", [0.62, 0.35, 1.0], "Olhar Sombrio",
         "Calmo e misterioso, envolto em sombras.", "Despertou quando um backup foi restaurado.", [4, 5, 3, 6]),
    form("foicinho", "Foicinho", 2, "main", R["e"], "Sombra", "skull/stage-2", [0.6, 0.35, 0.95], "Corte Lunar",
         "Carrega uma foice maior do que ele.", "Encontrou a foice num arquivo apagado.", [8, 7, 5, 10]),
    form("lordumbra", "Lordumbra", 3, "main", R["e"], "Sombra", "skull/stage-3", [0.65, 0.3, 1.0], "Runa Sombria",
         "Coroa de chifres e runas brilhantes.", "O treino o fez senhor das sombras do menu.", [13, 10, 7, 16]),
    form("necrolume", "Necrolume", 3, "alt", R["l"], "Espírito", "skull/alt", [0.4, 0.95, 0.55], "Lanterna Verde-Alma",
         "Leva uma lanterna de osso com chama verde.", "O cuidado acendeu uma luz dentro das costelas.", [9, 12, 8, 16]),
    form("monarca_umbral", "Monarca Umbral", 4, "main", R["l"], "Sombra", "skull/stage-4", [0.6, 0.28, 0.95], "Lâminas Flutuantes",
         "Quatro lâminas orbitam ao seu redor.", "Comanda um exército de sombras silenciosas.", [20, 15, 12, 25]),
    form("eternox", "Eternox", 5, "secret", R["x"], "Sombra", "skull/stage-5", [0.7, 0.35, 1.0], "Noite Eterna",
         "Asas de sombra e uma gema no peito.", "Acordou quando o último álbum foi completado.", [28, 22, 18, 36]),
  ]),
  line("dragon", "Linha Faíscon", "Fogo", "collector", "pow", {"trainings": 150},
       "Cento e cinquenta treinos forjam o sol.", [
    form("faiscon", "Faíscon", 1, "main", R["u"], "Fogo", "dragon/stage-1", [1.0, 0.4, 0.3], "Brasa Pequena",
         "Corajoso, protege o seu tesouro de ports.", "Chocou de um ovo guardado entre jogos antigos.", [6, 4, 4, 3]),
    form("brasinho", "Brasinho", 2, "main", R["u"], "Fogo", "dragon/stage-2", [1.0, 0.62, 0.2], "Sopro Quente",
         "Asas maiores e espinhos na cauda.", "Treinou voo pulando de menu em menu.", [10, 6, 7, 5]),
    form("alavento", "Alavento", 3, "main", R["e"], "Vento", "dragon/stage-3", [1.0, 0.45, 0.25], "Rasante",
         "Asas enormes que levantam ventania.", "O treino deu força às asas para voar alto.", [16, 9, 12, 7]),
    form("maridrago", "Marídrago", 3, "alt", R["l"], "Água", "dragon/alt", [0.3, 0.65, 0.95], "Maré Alta",
         "Barbatanas no lugar das asas e bolhas em volta.", "O carinho o levou a nadar no mar de dados.", [12, 11, 12, 10]),
    form("ancianix", "Ancianix", 4, "main", R["l"], "Fogo", "dragon/stage-4", [0.9, 0.35, 0.25], "Rugido Ancestral",
         "Placas douradas e quatro chifres.", "Viveu tanto que conhece todos os ports do catálogo.", [26, 16, 15, 12]),
    form("solarion", "Solarion", 5, "secret", R["x"], "Fogo", "dragon/stage-5", [1.0, 0.55, 0.25], "Explosão Solar",
         "Chifres de cristal e asas com veias de fogo.", "Nasceu de cento e cinquenta treinos sem descanso.", [38, 22, 22, 16]),
  ]),
  line("knight", "Linha Escudim", "Metal", "hub_update", "def", {"lines": 3},
       "Quando três reinos alcançam o topo, a luz escolhe seu cavaleiro.", [
    form("escudim", "Escudim", 1, "main", R["u"], "Metal", "knight/stage-1", [0.85, 0.2, 0.25], "Escudo Firme",
         "Leal e cerimonioso, trata você como realeza.", "Jurou lealdade ao primeiro hub atualizado.", [4, 7, 3, 4]),
    form("pratagon", "Pratagon", 2, "main", R["e"], "Metal", "knight/stage-2", [0.25, 0.4, 0.88], "Investida Prata",
         "Ombreiras de prata e penacho no elmo.", "Ganhou a armadura defendendo o catálogo.", [7, 11, 5, 6]),
    form("paladrako", "Paladrako", 3, "main", R["e"], "Luz", "knight/stage-3", [0.9, 0.5, 0.15], "Lâmina Dracônica",
         "Elmo com asas de dragão e espada brilhante.", "O treino uniu sua alma à de um dragão.", [12, 16, 8, 9]),
    form("flechart", "Flechart", 3, "alt", R["e"], "Vento", "knight/alt", [0.3, 0.6, 0.35], "Flecha Certeira",
         "Arqueiro de capuz, rápido e atento.", "O cuidado o ensinou a proteger de longe.", [11, 10, 14, 9]),
    form("regaldo", "Regaldo", 4, "main", R["l"], "Metal", "knight/stage-4", [0.75, 0.15, 0.2], "Muralha Real",
         "Escudo-torre e capa longa.", "Guardião oficial do castelo do hub.", [18, 26, 11, 14]),
    form("aureleon", "Auréleon", 5, "secret", R["x"], "Luz", "knight/stage-5", [1.0, 0.8, 0.3], "Juízo Dourado",
         "Armadura dourada, asas de luz e auréola.", "Escolhido quando três reinos chegaram ao topo.", [28, 36, 18, 20]),
  ]),
  line("owl", "Linha Pipio", "Vento", "speedtest", "wis", {"screens": 40},
       "Quem visita quarenta cantos do hub ganha as estrelas.", [
    form("pipio", "Pipio", 1, "main", R["c"], "Vento", "owl/stage-1", [0.7, 0.5, 0.35], "Pio Agudo",
         "Sábia e curiosa, sempre com uma dica.", "Pousou no hub durante um teste de velocidade.", [3, 3, 4, 7]),
    form("lunetta", "Lunetta", 2, "main", R["u"], "Vento", "owl/stage-2", [0.9, 0.75, 0.52], "Olhar Atento",
         "Usa óculos redondos e cachecol azul.", "Leu todas as dicas do hub em uma noite.", [5, 5, 6, 11]),
    form("arcanuja", "Arcanuja", 3, "main", R["u"], "Espírito", "owl/stage-3", [0.6, 0.45, 0.7], "Página Arcana",
         "Um livro flutua e runas giram em volta.", "O estudo despertou magia nas suas penas.", [8, 8, 9, 17]),
    form("tempestuja", "Tempestuja", 3, "alt", R["e"], "Elétrico", "owl/alt", [0.5, 0.55, 0.75], "Trovão Plumado",
         "Nuvem de tempestade e raios nas asas.", "Ficou tão animada que criou a própria tempestade.", [12, 7, 13, 12]),
    form("magistrix", "Magistrix", 4, "main", R["l"], "Espírito", "owl/stage-4", [0.3, 0.36, 0.78], "Cajado Estelar",
         "Asas abertas, manto e cajado brilhante.", "Ensina segredos do hub a quem pergunta.", [12, 14, 14, 26]),
    form("estelunia", "Estelúnia", 5, "secret", R["x"], "Luz", "owl/stage-5", [0.65, 0.55, 0.85], "Constelação",
         "Estrelas giram em volta e os olhos brilham.", "Mapeou quarenta cantos do hub e virou constelação.", [18, 20, 20, 38]),
  ]),
]

if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__))
    out = os.path.join(here, "..", "src", "assets", "digipets")
    os.makedirs(out, exist_ok=True)
    data = {"version": 1, "attrs": ATTRS, "lines": LINES}
    with open(os.path.join(out, "creatures.json"), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    n = sum(len(l["forms"]) for l in LINES)
    names = [fm["name"] for l in LINES for fm in l["forms"]]
    assert len(set(names)) == n, "nomes repetidos"
    print("linhas:", len(LINES), "formas:", n)
