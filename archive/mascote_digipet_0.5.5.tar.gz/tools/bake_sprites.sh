#!/bin/sh
# Gera os sprites pixel art das criaturas a partir dos modelos 3D.
# Uso: tools/bake_sprites.sh [ids]   (BAKE_ONLY=gotti,bipo para so algumas)
# Precisa do LOVE 11 (AppRun ou love) e de xvfb-run.
set -e
ROOT=$(cd "$(dirname "$0")/.." && pwd)
W=$(mktemp -d)
mkdir -p "$W/core/mascot3d"
cp -r "$ROOT/src/lib" "$W/"
cp "$ROOT/src/core/mascot3d/loader.lua" "$ROOT/src/core/mascot3d/render.lua" "$W/core/mascot3d/"
cp -r "$ROOT/tools/mascot_src/models" "$W/models"
cp "$ROOT/src/assets/digipets/creatures.json" "$ROOT/tools/spritebake/main.lua" "$W/"
echo 'function love.conf(t) t.identity="spritebake" t.window.width=320 t.window.height=240 end' > "$W/conf.lua"
LOVE=${LOVE:-/tmp/squashfs-root/AppRun}
OUT="$W/xdg"
BAKE_ONLY="$1" XDG_DATA_HOME="$OUT" xvfb-run -a -s "-screen 0 640x480x24" "$LOVE" "$W" 2>&1 | grep -v "ALSA\|ALSOFT\|Could not open" || true
mkdir -p "$ROOT/src/assets/digipets/sprites" "$ROOT/src/assets/digipets/hats"
cp "$OUT/love/spritebake/sprites/"* "$ROOT/src/assets/digipets/sprites/"
[ -d "$OUT/love/spritebake/hats" ] && cp "$OUT/love/spritebake/hats/"* "$ROOT/src/assets/digipets/hats/"
rm -rf "$W"
echo "sprites em src/assets/digipets/sprites"
